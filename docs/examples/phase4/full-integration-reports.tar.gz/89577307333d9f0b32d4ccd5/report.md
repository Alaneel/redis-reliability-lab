# Redis Reliability Lab — primary-failure

Run: `89577307333d9f0b32d4ccd5`  
Outcome: **failed**  
Started: 2026-10-11T20:03:04.8442+08:00  
Finished: 2026-10-11T20:03:33.094201+08:00

## Recovery

| Condition | Observed |
|---|---|
| Original six-node topology recovered | false |
| Post-validation diagnostic service sustained | false |
| Topology and diagnostic service jointly sustained | false |
| Frozen acknowledged writes verified | false |
| All managed processes restarted | false |
| Original replication redundancy restored | false |
| Restoration deadline expired | true |
| Diagnostic deadline expired | false |
| Cleanup verified | true |


## Frozen-ledger process restart

Configured persistence mode: `aof-everysec`. Failure model: `sequential SIGKILL of all six Redis processes, same-container restart; host and storage remain running`.

Workload traffic stops and drains before the sequential SIGKILL actions. No workload requests are offered during fault or restart observation; these phases do not measure zero availability or recovery throughput. Read-only frozen-ledger validation precedes separate diagnostic writes.

Frozen acknowledged SETs: 434. Frozen ambiguous SET outcomes: 0.

Restoration deadline expired: true.

| Evidence anchor | Observed time |
|---|---|
| Traffic fully drained | 2026-10-11T20:03:27.506641+08:00 |
| Immutable ledger frozen | 2026-10-11T20:03:27.506855+08:00 |
| All six stopped verified before restart | 2026-10-11T20:03:29.820223+08:00 |
| First restart requested | 2026-10-11T20:03:30.821779+08:00 |
| Restart sequence completed | unobserved |
| Frozen-ledger validation completed | unobserved |
| Post-validation diagnostics requested | unobserved |

Drain to first kill request: 0.257 ms (runtime monotonic clock).

Drain to last kill completion: 1559.223 ms (runtime monotonic clock).

All-stopped barrier to first restart request: 1001.548 ms (runtime monotonic clock).

| Restart observation | Since fault orchestration began, ms |
|---|---:|
| Original six-node replication ready | unobserved |
| Original topology sustained | unobserved |
| Replication redundancy sustained | unobserved |
| Post-validation diagnostic service sustained | unobserved |
| AOF frozen-value recovery observed | unobserved |

AOF frozen-value recovery observed: unobserved. This criterion requires actual loading/configuration evidence and complete frozen-value preservation; restart or topology readiness alone cannot establish it.

Frozen-ledger validation unobserved; 434 acknowledged values remain unchecked.

### Kill action order

| Order | Managed node | Requested | Completed | Error |
|---:|---|---|---|---|
| 1 | node-4 | 2026-10-11T20:03:27.506898+08:00 | 2026-10-11T20:03:27.756017+08:00 |  |
| 2 | node-5 | 2026-10-11T20:03:27.756032+08:00 | 2026-10-11T20:03:28.02262+08:00 |  |
| 3 | node-6 | 2026-10-11T20:03:28.022638+08:00 | 2026-10-11T20:03:28.287302+08:00 |  |
| 4 | node-1 | 2026-10-11T20:03:28.28732+08:00 | 2026-10-11T20:03:28.540095+08:00 |  |
| 5 | node-2 | 2026-10-11T20:03:28.540106+08:00 | 2026-10-11T20:03:28.795718+08:00 |  |
| 6 | node-3 | 2026-10-11T20:03:28.795736+08:00 | 2026-10-11T20:03:29.065878+08:00 |  |

### Restart action order

| Order | Managed node | Requested | Completed | Error |
|---:|---|---|---|---|
| 1 | node-1 | 2026-10-11T20:03:30.821779+08:00 | unobserved | context deadline exceeded |

### Stopped administrative observations

| Managed node | Original Redis Cluster ID | Observed | Container running | Restart policy | Status/error |
|---|---|---|---|---|---|
| node-4 | 58816f56cc5ef355d163201b1dfbd804a2313388 | 2026-10-11T20:03:29.19761+08:00 | false | no | managed Redis process is stopped |
| node-5 | f69127623539e3119eefa0ff8205f1e010f1316d | 2026-10-11T20:03:29.323835+08:00 | false | no | managed Redis process is stopped |
| node-6 | 03462bc2adf04b23747a9f66ba8221cb8c11d207 | 2026-10-11T20:03:29.446645+08:00 | false | no | managed Redis process is stopped |
| node-1 | a4e49307fe01f5d45b988892b29fb72ba9b6a260 | 2026-10-11T20:03:29.570077+08:00 | false | no | managed Redis process is stopped |
| node-2 | b5f6742b0825f31be26aff33fe9dda5e4648e218 | 2026-10-11T20:03:29.695522+08:00 | false | no | managed Redis process is stopped |
| node-3 | 578f4f18cd59d3fb44e56cb63ba6233526f7773e | 2026-10-11T20:03:29.82018+08:00 | false | no | managed Redis process is stopped |

### Prepared node-1

Original Redis Cluster ID: `a4e49307fe01f5d45b988892b29fb72ba9b6a260`. Process run ID: `2af916c18ae43d0ad2b83316936df3858782b6e9`. Observed: 2026-10-11T20:03:18.023729+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `a4e49307fe01f5d45b988892b29fb72ba9b6a260`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
maxmemory-policy
noeviction
aof-use-rdb-preamble
yes
aof-load-truncated
yes
maxmemory
134217728
no-appendfsync-on-rewrite
no
appendonly
yes
appendfsync
everysec
repl-diskless-load
swapdb
repl-diskless-sync
yes
rdb-del-sync-files
yes
auto-aof-rewrite-percentage
0
save

```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720187
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:487424
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:0
aof_base_size:0
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Prepared node-2

Original Redis Cluster ID: `b5f6742b0825f31be26aff33fe9dda5e4648e218`. Process run ID: `c2324bf0d54735c79e09a77e0f0e65f10150e76d`. Observed: 2026-10-11T20:03:19.063186+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `b5f6742b0825f31be26aff33fe9dda5e4648e218`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
auto-aof-rewrite-percentage
0
rdb-del-sync-files
yes
aof-use-rdb-preamble
yes
appendfsync
everysec
repl-diskless-sync
yes
appendonly
yes
repl-diskless-load
swapdb
maxmemory-policy
noeviction
aof-load-truncated
yes
maxmemory
134217728
save

no-appendfsync-on-rewrite
no
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720188
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:466944
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:0
aof_base_size:0
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Prepared node-3

Original Redis Cluster ID: `578f4f18cd59d3fb44e56cb63ba6233526f7773e`. Process run ID: `dd1e3328bb7066c36295e3dcfe57503f6023e566`. Observed: 2026-10-11T20:03:20.12113+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `578f4f18cd59d3fb44e56cb63ba6233526f7773e`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
auto-aof-rewrite-percentage
0
maxmemory
134217728
repl-diskless-sync
yes
aof-use-rdb-preamble
yes
save

appendfsync
everysec
maxmemory-policy
noeviction
no-appendfsync-on-rewrite
no
rdb-del-sync-files
yes
appendonly
yes
aof-load-truncated
yes
repl-diskless-load
swapdb
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720188
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:573440
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:0
aof_base_size:0
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Prepared node-4

Original Redis Cluster ID: `58816f56cc5ef355d163201b1dfbd804a2313388`. Process run ID: `cb15a34531abe618bb910706dc72c1d1fcd39c2c`. Observed: 2026-10-11T20:03:21.259964+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `58816f56cc5ef355d163201b1dfbd804a2313388`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
no-appendfsync-on-rewrite
no
maxmemory-policy
noeviction
appendfsync
everysec
aof-use-rdb-preamble
yes
aof-load-truncated
yes
repl-diskless-sync
yes
repl-diskless-load
swapdb
save

rdb-del-sync-files
yes
appendonly
yes
maxmemory
134217728
auto-aof-rewrite-percentage
0
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720188
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:385024
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:108
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof

```

### Prepared node-5

Original Redis Cluster ID: `f69127623539e3119eefa0ff8205f1e010f1316d`. Process run ID: `5b5f75fefc2411e574434b2eadd8cfad2d8a6d71`. Observed: 2026-10-11T20:03:22.310176+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `f69127623539e3119eefa0ff8205f1e010f1316d`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
rdb-del-sync-files
yes
maxmemory-policy
noeviction
aof-load-truncated
yes
repl-diskless-sync
yes
maxmemory
134217728
no-appendfsync-on-rewrite
no
auto-aof-rewrite-percentage
0
aof-use-rdb-preamble
yes
save

repl-diskless-load
swapdb
appendfsync
everysec
appendonly
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720189
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:393216
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:108
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof

```

### Prepared node-6

Original Redis Cluster ID: `03462bc2adf04b23747a9f66ba8221cb8c11d207`. Process run ID: `c338d21691d71a5c1487400114368b7331b0330b`. Observed: 2026-10-11T20:03:23.340099+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `03462bc2adf04b23747a9f66ba8221cb8c11d207`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
appendonly
yes
repl-diskless-sync
yes
appendfsync
everysec
maxmemory-policy
noeviction
repl-diskless-load
swapdb
rdb-del-sync-files
yes
no-appendfsync-on-rewrite
no
aof-load-truncated
yes
save

auto-aof-rewrite-percentage
0
aof-use-rdb-preamble
yes
maxmemory
134217728
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720189
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:393216
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:108
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof

```

Post-synchronization administrative runtime observations: unobserved.

This is a sequential process crash and same-container restart with retained managed volumes. It does not remove Docker VM/host page cache or simulate power loss, storage loss, or a graceful shutdown. Draining and sequential kill/inspection time allow background fsync to progress, so everysec preservation does not establish a one-second-loss guarantee or equivalence to always.

Persistence experiment error: restart node-1: context deadline exceeded

## Timing

Milestones are first sampled observations, not Redis event timestamps. Orchestration includes ownership checks and fault execution. The action-completion column separates that overhead; neither anchor identifies the exact Redis event time. Unobserved milestones remain absent.

Fault action completed 2313.310 ms after orchestration began (measured with the monotonic runtime clock).

No primary promotion is required. Original owners and replica assignments must remain unchanged across the all-stopped barrier; frozen data and post-validation diagnostics are evaluated separately.

## Workload

| Phase | Attempts | Success rate | Errors | Throughput (ops/s) | Successful p50/p95/p99 (ms) |
|---|---:|---:|---:|---:|---|
| baseline | 830 | 100.00% | 0 | 199.94 | 0.632 / 0.847 / 0.981 |

Acknowledged writes: 434. Ambiguous SET outcomes: 0.

### Before-baseline persistence and command evidence

Persistence preparation contains 6 node observations. Raw CONFIG, INFO and data-file replies are retained in JSON; these observations are separate from frozen-ledger verification.

| Node | Original Redis Cluster ID | Observed at | Observed Redis Cluster ID | Redis PONG | Error |
|---|---|---|---|---|---|
| node-1 | a4e49307fe01f5d45b988892b29fb72ba9b6a260 | 2026-10-11T20:03:18.023729+08:00 | a4e49307fe01f5d45b988892b29fb72ba9b6a260 | true |  |
| node-2 | b5f6742b0825f31be26aff33fe9dda5e4648e218 | 2026-10-11T20:03:19.063186+08:00 | b5f6742b0825f31be26aff33fe9dda5e4648e218 | true |  |
| node-3 | 578f4f18cd59d3fb44e56cb63ba6233526f7773e | 2026-10-11T20:03:20.12113+08:00 | 578f4f18cd59d3fb44e56cb63ba6233526f7773e | true |  |
| node-4 | 58816f56cc5ef355d163201b1dfbd804a2313388 | 2026-10-11T20:03:21.259964+08:00 | 58816f56cc5ef355d163201b1dfbd804a2313388 | true |  |
| node-5 | f69127623539e3119eefa0ff8205f1e010f1316d | 2026-10-11T20:03:22.310176+08:00 | f69127623539e3119eefa0ff8205f1e010f1316d | true |  |
| node-6 | 03462bc2adf04b23747a9f66ba8221cb8c11d207 | 2026-10-11T20:03:23.340099+08:00 | 03462bc2adf04b23747a9f66ba8221cb8c11d207 | true |  |

Before-baseline `set` policy probe at 2026-10-11T20:03:23.35533+08:00; all shards successful: true.

| Original shard index | SET acknowledged |
|---|---|
| 0 | true |
| 1 | true |
| 2 | true |

Write policy: `set`. Diagnostic stage requests are excluded from logical workload counts.

| Phase | SET acknowledged | SET errors |
|---|---:|---:|
| baseline | 434 | 0 |

| Phase | Measured path | Count | p50 / p95 / p99, ms |
|---|---|---:|---|
| baseline | Logical write completion | 434 | 0.664 / 0.890 / 0.981 |
| baseline | set | 434 | 0.632 / 0.847 / 0.934 |

| Phase | Successful logical writes | Successful writes/s over phase wall time |
|---|---:|---:|
| baseline | 434 | 104.549 |

Global pacing: offered 830; started 830; completed 830; dropped 0. These counts include all workload phases and exclude validation and probes.

Offered requests are ideal period slots from workload Start until the dispatcher observes Stop or parent cancellation; the first slot occurs after one period. The period is one second divided by the configured aggregate rate, truncated to whole nanoseconds. A central dispatcher offers only the latest due slot over an unbuffered channel; missed slots, busy workers, stopped tokens, and tokens with no eligible operation are dropped, without catch-up requests. Started requests count actual logical workload GET or write executions; a SET+WAIT/WAITAOF write counts once. Completed requests count their terminal logical metrics attempts. After Stop, offered = started + dropped and started = completed. Validation and ordinary/acknowledgement-policy probes are excluded. These global counters are not attributed to phases.

Validation attempted: false; expected: 0; checked: 0; missing: 0; corrupt: 0; unreadable: 0; unverified: 0. Validation complete: false.
Validation was not attempted; 434 acknowledged writes remain unchecked.

### Terminal workload errors

| Phase | Error class | Count |
|---|---|---:|

Latencies use 512 bounded geometric histogram buckets, starting at 1 microsecond and increasing by 5%; quantiles are nearest-rank bucket upper bounds. The last bucket covers the remaining duration range. All terminal client attempts, successful attempts, and failed attempts have separate histograms. Throughput is completed attempts divided by phase wall-clock seconds. Operations are attributed to the phase in which they start. Redirect counts include only terminal MOVED/ASK errors; redirects handled by the client are not observable here.

## Errors

- restart node-1: context deadline exceeded

## Measurement methodology

- Quiet administrative process, CONFIG, persistence INFO, keyspace and bounded data-file preparation occurs before baseline traffic; it issues no SAVE, BGSAVE, BGREWRITEAOF or explicit durability barrier.
- The workload fully stops and joins in-flight acknowledgements before freezing its immutable ledger and counters. All later topology observations are read-only until every frozen acknowledged value has been checked. SET-error outcomes remain ambiguous, excluded from acknowledgement guarantees.
- Original replicas are SIGKILLed before original primaries. Every fixed owned container must produce ErrProcessStopped administrative evidence with restart policy no before any restart. Original primaries restart before replicas in the same containers and retained volumes; original Redis Cluster identities and slot ownership must survive.
- The model is sequential process SIGKILL while Docker VM, host and storage remain running, followed by same-container starts. It does not simulate power loss, host/page-cache loss or disk loss. Drain, kill and inspection intervals are reported because they permit background fsync progress.
- Topology restoration requires all six original identities, endpoints, primary slot owners and replica assignments synchronized for stable_for, without forced Redis topology commands. Physical receipts retain early raw evidence, which can be transient during full sync. Six fresh quiet administrative runtime/configuration/file observations after topology stability prove the final persistence mode on those same restarted processes, within the shared repair budget and before frozen-value validation. Samples crossing restoration or diagnostic deadlines are retained but excluded from successful milestones.
- Frozen-ledger GET validation happens exactly once before diagnostic SET/GET or configured replica-acknowledgement probes. Process/slot readiness and later diagnostic service are independent from frozen-value preservation; missing or corrupt values retain a partial data verdict even after service recovers.
- Memory mode has RDB/AOF disabled, rdb-del-sync-files=yes to remove replication-created RDB files, and observed absence of value persistence files. Its persistence-recovery event is not applicable and remains absent; its independent persistence dimension is false. AOF modes use the RDB base preamble required by the pinned image's bundled modules plus incremental AOF records. AOF recovery requires actual matching healthy runtime configuration, loading=0 and complete frozen acknowledged-value preservation; this observation establishes no loss-free or power-loss guarantee.
- No workload demand is offered after draining, so absent fault/recovery traffic does not measure zero availability or throughput. Post-validation probes are separate diagnostics and never enter workload metrics or the frozen ledger. Poll intervals follow sample completion; observations are sampled and non-atomic.
- All AOF modes and write policies use six-node quiet runtime preparation followed by exactly three all-shard policy SET/GET warmup writes before baseline starts. Warmup writes are excluded from the workload ledger and metrics; no WAITAOF compatibility command is issued after baseline to alter crash-trial durability.

The JSON report contains effective configuration, environment metadata, raw topology replies, per-operation metrics, validation samples, and lifecycle timestamps. Effective configuration SHA-256: `79160ee95fc0aad724fab7a2c6b4e9f4d1af92d59da547583ee75842d0f8ca81`.
