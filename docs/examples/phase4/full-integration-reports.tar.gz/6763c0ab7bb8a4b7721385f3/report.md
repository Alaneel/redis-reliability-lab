# Redis Reliability Lab — primary-network-isolation

Run: `6763c0ab7bb8a4b7721385f3`  
Outcome: **partial**  
Started: 2026-10-11T19:58:36.700033+08:00  
Finished: 2026-10-11T19:59:04.689992+08:00

## Recovery

| Condition | Observed |
|---|---|
| Surviving topology converged | false |
| All-shard client recovery sustained | false |
| Topology and client recovery jointly sustained | false |
| All acknowledged writes verified | true |
| Target process restarted | false |
| Original replication redundancy restored | false |
| Recovery deadline expired | false |
| Cleanup verified | true |

The primary remains running during whole-node bidirectional network isolation. Connectivity restoration, topology reconciliation and replication redundancy are evaluated separately. Redis replication is asynchronous; acknowledged SETs are not durability guarantees.

## Network restoration

| Condition | Observed |
|---|---|
| Original endpoints and process restored | true |
| Topology and clients jointly reconciled | false |
| Reconciliation deadline expired | true |

Restoration action duration: 1369.833 ms.

| Process probe time | Redis PONG | Container running | Network attached | Container PID | Redis run ID | Error |
|---|---|---|---|---:|---|---|
| 2026-10-11T19:58:52.438112+08:00 | true | true | false | 94737 | 2b5ae8bc37a490a07d689857aa1b9bf6404a0175 |  |
| 2026-10-11T19:58:54.994407+08:00 | true | true | false | 94737 | 2b5ae8bc37a490a07d689857aa1b9bf6404a0175 |  |
| 2026-10-11T19:58:57.568823+08:00 | true | true | false | 94737 | 2b5ae8bc37a490a07d689857aa1b9bf6404a0175 |  |
| 2026-10-11T19:59:00.166627+08:00 | true | true | false | 94737 | 2b5ae8bc37a490a07d689857aa1b9bf6404a0175 |  |
| 2026-10-11T19:59:02.687853+08:00 | true | true | true | 94737 | 2b5ae8bc37a490a07d689857aa1b9bf6404a0175 |  |

Network fault error: topology and client reconciliation did not stabilize within 100ms

## Timing

Milestones are first sampled observations, not Redis event timestamps. Orchestration includes ownership checks and fault execution. The action-completion column separates that overhead; neither anchor identifies the exact Redis event time. Unobserved milestones remain absent.

Fault action completed 1545.756 ms after orchestration began (measured with the monotonic runtime clock).

| Observation | Since orchestration began, ms | Since action completed, ms |
|---|---:|---:|
| Failure flagged in gossip | 2226.14 | 680.38 |
| Original replica owns failed primary slots | 3891.30 | 2345.55 |
| Full usable slot coverage | 3891.30 | 2345.55 |
| Surviving views converge | 3891.30 | 2345.55 |
| First all-shard SET/GET probe succeeds | 4021.28 | 2475.52 |
| Client probes sustain recovery | 5247.08 | 3701.33 |
| Topology and clients sustain recovery | 5247.08 | 3701.33 |

## Workload

| Phase | Attempts | Success rate | Errors | Throughput (ops/s) | Successful p50/p95/p99 (ms) |
|---|---:|---:|---:|---:|---|
| baseline | 419 | 100.00% | 0 | 199.13 | 0.573 / 1.314 / 3.845 |
| fault | 1901 | 95.48% | 86 | 163.15 | 0.632 / 1.192 / 2.360 |
| reconciliation | 162 | 100.00% | 0 | 199.12 | 0.632 / 0.890 / 1.514 |

Acknowledged writes: 1210. Ambiguous SET outcomes: 42.

Write policy: `set`. Diagnostic stage requests are excluded from logical workload counts.

| Phase | SET acknowledged | SET errors |
|---|---:|---:|
| baseline | 221 | 0 |
| fault | 907 | 42 |
| reconciliation | 82 | 0 |

| Phase | Measured path | Count | p50 / p95 / p99, ms |
|---|---|---:|---|
| baseline | Logical write completion | 221 | 0.602 / 0.981 / 2.869 |
| baseline | set | 221 | 0.573 / 0.981 / 2.732 |
| fault | Logical write completion | 949 | 0.632 / 1.252 / 2.360 |
| fault | set | 949 | 0.602 / 1.135 / 2.248 |
| reconciliation | Logical write completion | 82 | 0.664 / 0.934 / 1.466 |
| reconciliation | set | 82 | 0.602 / 0.890 / 1.194 |

| Phase | Successful logical writes | Successful writes/s over phase wall time |
|---|---:|---:|
| baseline | 221 | 105.033 |
| fault | 907 | 77.841 |
| reconciliation | 82 | 100.790 |

Global pacing: offered 2913; started 2482; completed 2482; dropped 431. These counts include all workload phases and exclude validation and probes.

Offered requests are ideal period slots from workload Start until the dispatcher observes Stop or parent cancellation; the first slot occurs after one period. The period is one second divided by the configured aggregate rate, truncated to whole nanoseconds. A central dispatcher offers only the latest due slot over an unbuffered channel; missed slots, busy workers, stopped tokens, and tokens with no eligible operation are dropped, without catch-up requests. Started requests count actual logical workload GET or write executions; a SET+WAIT/WAITAOF write counts once. Completed requests count their terminal logical metrics attempts. After Stop, offered = started + dropped and started = completed. Validation and ordinary/acknowledgement-policy probes are excluded. These global counters are not attributed to phases.

Validation attempted: true; expected: 1210; checked: 1210; missing: 0; corrupt: 0; unreadable: 0; unverified: 0. Validation complete: true.

### Terminal workload errors

| Phase | Error class | Count |
|---|---|---:|
| fault | CLUSTERDOWN | 9 |
| fault | network | 33 |
| fault | timeout | 44 |

Latencies use 512 bounded geometric histogram buckets, starting at 1 microsecond and increasing by 5%; quantiles are nearest-rank bucket upper bounds. The last bucket covers the remaining duration range. All terminal client attempts, successful attempts, and failed attempts have separate histograms. Throughput is completed attempts divided by phase wall-clock seconds. Operations are attributed to the phase in which they start. Redirect counts include only terminal MOVED/ASK errors; redirects handled by the client are not observable here.

## Errors

- experiment outcome: partial

## Measurement methodology

- Fault is a complete bidirectional Docker bridge disconnection of the deterministic primary owning the lowest initial slot. Redis remains running. All peer and published client connectivity is removed; this is not a selective or one-way partition.
- The orchestration and action-completion anchors are recorded separately using monotonic runtime durations. isolation_duration is a minimum hold from successful action completion, bounded by the recovery deadline; samples and bounded process probes can extend the hold. Actual restoration timestamps record the observed duration.
- During isolation, recovery requires the five surviving nodes to converge on healthy usable slot ownership, the original replica to own the selected primary slots, unchanged unaffected ownership, and successful all-shard SET/GET probes over stable_for. A stable milestone is retained while observation continues until restoration.
- Docker exec runs fixed Redis liveness and topology commands independent of the disconnected data plane. PONG and unchanged container PID, start time and Redis run ID prove sampled process survival, not cluster health. Isolation success requires at least one such disconnected observation.
- Restoration reconnects only the same owned node to the same owned network with its original private IP and loopback port. Process identity and endpoint identity must remain unchanged. Cancellation uses a fresh bounded restoration attempt before independent cleanup; safe cleanup can directly remove an owned detached node.
- After restoration, fresh stability tracking requires all six original identities and endpoints, three healthy primaries with synchronized replicas, the promoted replica retaining shard ownership, former-primary demotion, unchanged unaffected shards, and all-shard client probes. Service recovery, connectivity restoration and replication redundancy have separate evidence.
- Poll intervals are delays after sample completion; concurrent views are not atomic snapshots. Probes do not prove continuous availability. Workload metrics include terminal client errors separately from probe results. At most 1200 topology samples and 64 process samples are retained.
- Traffic drains before validating every successfully acknowledged immutable SET. Missing, corrupt, unreadable or unverified records prevent full recovery. Error-returning SET outcomes remain ambiguous. No client can write to the disconnected minority, so this experiment does not exercise minority-side write conflicts or establish loss-free asynchronous replication.

The JSON report contains effective configuration, environment metadata, raw topology replies, per-operation metrics, validation samples, and lifecycle timestamps. Effective configuration SHA-256: `338243c64eb160bec22299b9ec5859bb8ad156e36689964f34ae2c46e1da93bd`.
