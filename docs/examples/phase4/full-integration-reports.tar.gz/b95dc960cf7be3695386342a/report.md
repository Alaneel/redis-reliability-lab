# Redis Reliability Lab — primary-failure

Run: `b95dc960cf7be3695386342a`  
Outcome: **partial**  
Started: 2026-10-11T19:59:44.953529+08:00  
Finished: 2026-10-11T20:00:39.604443+08:00

## Recovery

| Condition | Observed |
|---|---|
| Original six-node topology recovered | true |
| Post-validation diagnostic service sustained | true |
| Topology and diagnostic service jointly sustained | true |
| Frozen acknowledged writes verified | false |
| All managed processes restarted | true |
| Original replication redundancy restored | true |
| Restoration deadline expired | false |
| Diagnostic deadline expired | false |
| Cleanup verified | true |


## Frozen-ledger process restart

Configured persistence mode: `memory`. Failure model: `sequential SIGKILL of all six Redis processes, same-container restart; host and storage remain running`.

Workload traffic stops and drains before the sequential SIGKILL actions. No workload requests are offered during fault or restart observation; these phases do not measure zero availability or recovery throughput. Read-only frozen-ledger validation precedes separate diagnostic writes.

Frozen acknowledged SETs: 433. Frozen ambiguous SET outcomes: 0.

Restoration deadline expired: false.

| Evidence anchor | Observed time |
|---|---|
| Traffic fully drained | 2026-10-11T20:00:07.642707+08:00 |
| Immutable ledger frozen | 2026-10-11T20:00:07.642875+08:00 |
| All six stopped verified before restart | 2026-10-11T20:00:10.0335+08:00 |
| First restart requested | 2026-10-11T20:00:11.034872+08:00 |
| Restart sequence completed | 2026-10-11T20:00:21.365504+08:00 |
| Frozen-ledger validation completed | 2026-10-11T20:00:32.695604+08:00 |
| Post-validation diagnostics requested | 2026-10-11T20:00:32.695893+08:00 |

Drain to first kill request: 0.243 ms (runtime monotonic clock).

Drain to last kill completion: 1599.372 ms (runtime monotonic clock).

All-stopped barrier to first restart request: 1001.363 ms (runtime monotonic clock).

| Restart observation | Since fault orchestration began, ms |
|---|---:|
| Original six-node replication ready | 16709.340 |
| Original topology sustained | 18206.318 |
| Replication redundancy sustained | 18206.318 |
| Post-validation diagnostic service sustained | 26544.931 |
| AOF frozen-value recovery observed | unobserved |

Configured memory-only control disables RDB/AOF value persistence. Persistence recovery is not applicable; restored processes and topology can coexist with lost frozen values. The independent persistence dimension is false when the disabled runtime configuration was observed, while the persistence-recovery event remains absent.

Frozen-ledger validation: expected 433; checked 433; missing 433; corrupt 0; unreadable 0; unverified 0; complete true. Completion describes verification coverage; observed loss remains a data failure.

### Kill action order

| Order | Managed node | Requested | Completed | Error |
|---:|---|---|---|---|
| 1 | node-4 | 2026-10-11T20:00:07.64295+08:00 | 2026-10-11T20:00:07.90173+08:00 |  |
| 2 | node-5 | 2026-10-11T20:00:07.901745+08:00 | 2026-10-11T20:00:08.172907+08:00 |  |
| 3 | node-6 | 2026-10-11T20:00:08.172924+08:00 | 2026-10-11T20:00:08.429578+08:00 |  |
| 4 | node-1 | 2026-10-11T20:00:08.429593+08:00 | 2026-10-11T20:00:08.703605+08:00 |  |
| 5 | node-2 | 2026-10-11T20:00:08.703613+08:00 | 2026-10-11T20:00:08.967088+08:00 |  |
| 6 | node-3 | 2026-10-11T20:00:08.967104+08:00 | 2026-10-11T20:00:09.242092+08:00 |  |

### Restart action order

| Order | Managed node | Requested | Completed | Error |
|---:|---|---|---|---|
| 1 | node-1 | 2026-10-11T20:00:11.034872+08:00 | 2026-10-11T20:00:12.789319+08:00 |  |
| 2 | node-2 | 2026-10-11T20:00:12.789324+08:00 | 2026-10-11T20:00:14.485116+08:00 |  |
| 3 | node-3 | 2026-10-11T20:00:14.485128+08:00 | 2026-10-11T20:00:16.213836+08:00 |  |
| 4 | node-4 | 2026-10-11T20:00:16.213843+08:00 | 2026-10-11T20:00:17.883847+08:00 |  |
| 5 | node-5 | 2026-10-11T20:00:17.88385+08:00 | 2026-10-11T20:00:19.581862+08:00 |  |
| 6 | node-6 | 2026-10-11T20:00:19.581871+08:00 | 2026-10-11T20:00:21.365501+08:00 |  |

### Stopped administrative observations

| Managed node | Original Redis Cluster ID | Observed | Container running | Restart policy | Status/error |
|---|---|---|---|---|---|
| node-4 | dd585bc676c265a1879cc18a7a29f2bce5c2f6ee | 2026-10-11T20:00:09.380037+08:00 | false | no | managed Redis process is stopped |
| node-5 | 631b4705a410d4286e79ed272e5499c30a434068 | 2026-10-11T20:00:09.512389+08:00 | false | no | managed Redis process is stopped |
| node-6 | 332483ae6f1da5174a58db3ccd44dfd8292bb0ba | 2026-10-11T20:00:09.643434+08:00 | false | no | managed Redis process is stopped |
| node-1 | aaf00cf746628c8332cada939aef6763f8625094 | 2026-10-11T20:00:09.773349+08:00 | false | no | managed Redis process is stopped |
| node-2 | 5c6398828e135cfa6876f23716e05727a40f3f5a | 2026-10-11T20:00:09.903991+08:00 | false | no | managed Redis process is stopped |
| node-3 | 5d99098eaec42f1626e99cdcb017895d2a5bb924 | 2026-10-11T20:00:10.033469+08:00 | false | no | managed Redis process is stopped |

### Prepared node-1

Original Redis Cluster ID: `aaf00cf746628c8332cada939aef6763f8625094`. Process run ID: `10e28803b0ac9846d00b7eac8835103582aa535c`. Observed: 2026-10-11T19:59:57.988224+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `aaf00cf746628c8332cada939aef6763f8625094`. Restart policy: `no`. `/data` usage: 8 KiB.

Observed persistence configuration:

```text
repl-diskless-sync
yes
appendonly
no
maxmemory
134217728
auto-aof-rewrite-percentage
0
no-appendfsync-on-rewrite
no
repl-diskless-load
swapdb
aof-use-rdb-preamble
no
save

aof-load-truncated
yes
maxmemory-policy
noeviction
appendfsync
everysec
rdb-del-sync-files
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791719987
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:536576
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:0
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf

```

### Prepared node-2

Original Redis Cluster ID: `5c6398828e135cfa6876f23716e05727a40f3f5a`. Process run ID: `23ca77f38c63d3cb6f34dddb69bdd0345feeaf7f`. Observed: 2026-10-11T19:59:59.075553+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `5c6398828e135cfa6876f23716e05727a40f3f5a`. Restart policy: `no`. `/data` usage: 8 KiB.

Observed persistence configuration:

```text
repl-diskless-load
swapdb
maxmemory
134217728
appendonly
no
auto-aof-rewrite-percentage
0
aof-load-truncated
yes
rdb-del-sync-files
yes
no-appendfsync-on-rewrite
no
maxmemory-policy
noeviction
aof-use-rdb-preamble
no
save

appendfsync
everysec
repl-diskless-sync
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791719988
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:466944
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:0
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf

```

### Prepared node-3

Original Redis Cluster ID: `5d99098eaec42f1626e99cdcb017895d2a5bb924`. Process run ID: `c72aba1c9739b0c5d5a09a6f506a659afb5e00df`. Observed: 2026-10-11T20:00:00.176335+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `5d99098eaec42f1626e99cdcb017895d2a5bb924`. Restart policy: `no`. `/data` usage: 8 KiB.

Observed persistence configuration:

```text
auto-aof-rewrite-percentage
0
appendfsync
everysec
rdb-del-sync-files
yes
appendonly
no
maxmemory
134217728
aof-use-rdb-preamble
no
save

repl-diskless-sync
yes
no-appendfsync-on-rewrite
no
repl-diskless-load
swapdb
aof-load-truncated
yes
maxmemory-policy
noeviction
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791719988
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:466944
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:0
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf

```

### Prepared node-4

Original Redis Cluster ID: `dd585bc676c265a1879cc18a7a29f2bce5c2f6ee`. Process run ID: `20092a28ecd369230546deb7033d53988b946d79`. Observed: 2026-10-11T20:00:01.271673+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `dd585bc676c265a1879cc18a7a29f2bce5c2f6ee`. Restart policy: `no`. `/data` usage: 8 KiB.

Observed persistence configuration:

```text
appendfsync
everysec
maxmemory-policy
noeviction
auto-aof-rewrite-percentage
0
aof-use-rdb-preamble
no
rdb-del-sync-files
yes
aof-load-truncated
yes
appendonly
no
no-appendfsync-on-rewrite
no
repl-diskless-load
swapdb
repl-diskless-sync
yes
save

maxmemory
134217728
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791719988
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:0
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf

```

### Prepared node-5

Original Redis Cluster ID: `631b4705a410d4286e79ed272e5499c30a434068`. Process run ID: `0c94781b35958c3254ae386bf7d2bd3a6cd41c90`. Observed: 2026-10-11T20:00:02.386204+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `631b4705a410d4286e79ed272e5499c30a434068`. Restart policy: `no`. `/data` usage: 8 KiB.

Observed persistence configuration:

```text
no-appendfsync-on-rewrite
no
maxmemory
134217728
save

aof-load-truncated
yes
appendonly
no
aof-use-rdb-preamble
no
rdb-del-sync-files
yes
repl-diskless-sync
yes
appendfsync
everysec
maxmemory-policy
noeviction
auto-aof-rewrite-percentage
0
repl-diskless-load
swapdb
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791719989
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:0
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf

```

### Prepared node-6

Original Redis Cluster ID: `332483ae6f1da5174a58db3ccd44dfd8292bb0ba`. Process run ID: `0856aa98eaafdf9d8a207682aa4537bd1cb64e9d`. Observed: 2026-10-11T20:00:03.488369+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `332483ae6f1da5174a58db3ccd44dfd8292bb0ba`. Restart policy: `no`. `/data` usage: 8 KiB.

Observed persistence configuration:

```text
repl-diskless-load
swapdb
aof-load-truncated
yes
maxmemory
134217728
save

no-appendfsync-on-rewrite
no
auto-aof-rewrite-percentage
0
repl-diskless-sync
yes
rdb-del-sync-files
yes
maxmemory-policy
noeviction
appendonly
no
appendfsync
everysec
aof-use-rdb-preamble
no
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791719989
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:0
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf

```

### Restart receipt 1: node-1

Original Redis Cluster ID: `aaf00cf746628c8332cada939aef6763f8625094`. Observed after restart: 2026-10-11T20:00:12.65641+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `aaf00cf746628c8332cada939aef6763f8625094`. Restart policy: `no`. `/data` usage: 8 KiB.

Observed persistence configuration:

```text
maxmemory
134217728
repl-diskless-load
swapdb
no-appendfsync-on-rewrite
no
appendfsync
everysec
appendonly
no
aof-use-rdb-preamble
no
auto-aof-rewrite-percentage
0
save

repl-diskless-sync
yes
maxmemory-policy
noeviction
aof-load-truncated
yes
rdb-del-sync-files
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720011
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:0
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf

```

### Restart receipt 2: node-2

Original Redis Cluster ID: `5c6398828e135cfa6876f23716e05727a40f3f5a`. Observed after restart: 2026-10-11T20:00:14.356158+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `5c6398828e135cfa6876f23716e05727a40f3f5a`. Restart policy: `no`. `/data` usage: 8 KiB.

Observed persistence configuration:

```text
auto-aof-rewrite-percentage
0
rdb-del-sync-files
yes
maxmemory
134217728
appendfsync
everysec
save

aof-use-rdb-preamble
no
no-appendfsync-on-rewrite
no
repl-diskless-load
swapdb
repl-diskless-sync
yes
appendonly
no
aof-load-truncated
yes
maxmemory-policy
noeviction
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720013
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:0
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf

```

### Restart receipt 3: node-3

Original Redis Cluster ID: `5d99098eaec42f1626e99cdcb017895d2a5bb924`. Observed after restart: 2026-10-11T20:00:16.083128+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `5d99098eaec42f1626e99cdcb017895d2a5bb924`. Restart policy: `no`. `/data` usage: 8 KiB.

Observed persistence configuration:

```text
rdb-del-sync-files
yes
repl-diskless-load
swapdb
maxmemory-policy
noeviction
no-appendfsync-on-rewrite
no
save

appendfsync
everysec
aof-use-rdb-preamble
no
aof-load-truncated
yes
maxmemory
134217728
auto-aof-rewrite-percentage
0
repl-diskless-sync
yes
appendonly
no
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720014
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:0
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf

```

### Restart receipt 4: node-4

Original Redis Cluster ID: `dd585bc676c265a1879cc18a7a29f2bce5c2f6ee`. Observed after restart: 2026-10-11T20:00:17.756451+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `dd585bc676c265a1879cc18a7a29f2bce5c2f6ee`. Restart policy: `no`. `/data` usage: 8 KiB.

Observed persistence configuration:

```text
auto-aof-rewrite-percentage
0
no-appendfsync-on-rewrite
no
repl-diskless-load
swapdb
repl-diskless-sync
yes
rdb-del-sync-files
yes
aof-use-rdb-preamble
no
maxmemory-policy
noeviction
aof-load-truncated
yes
save

maxmemory
134217728
appendfsync
everysec
appendonly
no
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720016
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:0
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/temp-1791720016.1.rdb

```

### Restart receipt 5: node-5

Original Redis Cluster ID: `631b4705a410d4286e79ed272e5499c30a434068`. Observed after restart: 2026-10-11T20:00:19.453298+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `631b4705a410d4286e79ed272e5499c30a434068`. Restart policy: `no`. `/data` usage: 8 KiB.

Observed persistence configuration:

```text
aof-load-truncated
yes
auto-aof-rewrite-percentage
0
repl-diskless-sync
yes
aof-use-rdb-preamble
no
maxmemory
134217728
save

no-appendfsync-on-rewrite
no
repl-diskless-load
swapdb
appendonly
no
appendfsync
everysec
rdb-del-sync-files
yes
maxmemory-policy
noeviction
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720018
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:0
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/temp-1791720018.1.rdb

```

### Restart receipt 6: node-6

Original Redis Cluster ID: `332483ae6f1da5174a58db3ccd44dfd8292bb0ba`. Observed after restart: 2026-10-11T20:00:21.209017+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `332483ae6f1da5174a58db3ccd44dfd8292bb0ba`. Restart policy: `no`. `/data` usage: 8 KiB.

Observed persistence configuration:

```text
appendfsync
everysec
repl-diskless-load
swapdb
repl-diskless-sync
yes
appendonly
no
auto-aof-rewrite-percentage
0
maxmemory
134217728
maxmemory-policy
noeviction
aof-load-truncated
yes
no-appendfsync-on-rewrite
no
rdb-del-sync-files
yes
save

aof-use-rdb-preamble
no
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720019
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:0
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/temp-1791720019.1.rdb

```

### Post-synchronization runtime evidence

These fresh read-only administrative observations follow topology stability and precede frozen-ledger validation. They establish the sampled persistence configuration, loading status and data files; the earlier physical restart receipts remain unchanged.

#### Restored node-1

Original Redis Cluster ID: `aaf00cf746628c8332cada939aef6763f8625094`. Process run ID: `5ff064aa7aaef75107a8a02927d8c61bd320882c`. Observed: 2026-10-11T20:00:27.224627+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `aaf00cf746628c8332cada939aef6763f8625094`. Restart policy: `no`. `/data` usage: 8 KiB.

Observed persistence configuration:

```text
maxmemory
134217728
repl-diskless-load
swapdb
no-appendfsync-on-rewrite
no
appendfsync
everysec
appendonly
no
aof-use-rdb-preamble
no
auto-aof-rewrite-percentage
0
save

repl-diskless-sync
yes
maxmemory-policy
noeviction
aof-load-truncated
yes
rdb-del-sync-files
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720011
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:552960
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:0
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf

```

#### Restored node-2

Original Redis Cluster ID: `5c6398828e135cfa6876f23716e05727a40f3f5a`. Process run ID: `1e94d75300ac59d54f8473ee8e71ebc49a062ef6`. Observed: 2026-10-11T20:00:28.27303+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `5c6398828e135cfa6876f23716e05727a40f3f5a`. Restart policy: `no`. `/data` usage: 8 KiB.

Observed persistence configuration:

```text
auto-aof-rewrite-percentage
0
rdb-del-sync-files
yes
maxmemory
134217728
appendfsync
everysec
save

aof-use-rdb-preamble
no
no-appendfsync-on-rewrite
no
repl-diskless-load
swapdb
repl-diskless-sync
yes
appendonly
no
aof-load-truncated
yes
maxmemory-policy
noeviction
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720013
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:462848
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:0
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf

```

#### Restored node-3

Original Redis Cluster ID: `5d99098eaec42f1626e99cdcb017895d2a5bb924`. Process run ID: `3a8425c83ed5d1dd4192fadce7e856d48f96e5a1`. Observed: 2026-10-11T20:00:29.344193+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `5d99098eaec42f1626e99cdcb017895d2a5bb924`. Restart policy: `no`. `/data` usage: 8 KiB.

Observed persistence configuration:

```text
rdb-del-sync-files
yes
repl-diskless-load
swapdb
maxmemory-policy
noeviction
no-appendfsync-on-rewrite
no
save

appendfsync
everysec
aof-use-rdb-preamble
no
aof-load-truncated
yes
maxmemory
134217728
auto-aof-rewrite-percentage
0
repl-diskless-sync
yes
appendonly
no
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720014
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:462848
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:0
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf

```

#### Restored node-4

Original Redis Cluster ID: `dd585bc676c265a1879cc18a7a29f2bce5c2f6ee`. Process run ID: `48e3b8701971945374babcf8744e7b8b840cf335`. Observed: 2026-10-11T20:00:30.39289+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `dd585bc676c265a1879cc18a7a29f2bce5c2f6ee`. Restart policy: `no`. `/data` usage: 8 KiB.

Observed persistence configuration:

```text
auto-aof-rewrite-percentage
0
no-appendfsync-on-rewrite
no
repl-diskless-load
swapdb
repl-diskless-sync
yes
rdb-del-sync-files
yes
aof-use-rdb-preamble
no
maxmemory-policy
noeviction
aof-load-truncated
yes
save

maxmemory
134217728
appendfsync
everysec
appendonly
no
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720016
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:0
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf

```

#### Restored node-5

Original Redis Cluster ID: `631b4705a410d4286e79ed272e5499c30a434068`. Process run ID: `fae76fd61fe901e5049eba10a65eece4a239329d`. Observed: 2026-10-11T20:00:31.457908+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `631b4705a410d4286e79ed272e5499c30a434068`. Restart policy: `no`. `/data` usage: 8 KiB.

Observed persistence configuration:

```text
aof-load-truncated
yes
auto-aof-rewrite-percentage
0
repl-diskless-sync
yes
aof-use-rdb-preamble
no
maxmemory
134217728
save

no-appendfsync-on-rewrite
no
repl-diskless-load
swapdb
appendonly
no
appendfsync
everysec
rdb-del-sync-files
yes
maxmemory-policy
noeviction
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720018
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:0
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf

```

#### Restored node-6

Original Redis Cluster ID: `332483ae6f1da5174a58db3ccd44dfd8292bb0ba`. Process run ID: `d976c32979c65695438dbd81c3db583410c499d1`. Observed: 2026-10-11T20:00:32.538305+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `332483ae6f1da5174a58db3ccd44dfd8292bb0ba`. Restart policy: `no`. `/data` usage: 8 KiB.

Observed persistence configuration:

```text
appendfsync
everysec
repl-diskless-load
swapdb
repl-diskless-sync
yes
appendonly
no
auto-aof-rewrite-percentage
0
maxmemory
134217728
maxmemory-policy
noeviction
aof-load-truncated
yes
no-appendfsync-on-rewrite
no
rdb-del-sync-files
yes
save

aof-use-rdb-preamble
no
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720019
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:0
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf

```

This is a sequential process crash and same-container restart with retained managed volumes. It does not remove Docker VM/host page cache or simulate power loss, storage loss, or a graceful shutdown. Draining and sequential kill/inspection time allow background fsync to progress, so everysec preservation does not establish a one-second-loss guarantee or equivalence to always.

Persistence experiment error: persistence experiment ended partial: frozen data verified=false, original redundancy stable=true, restoration deadline=false

## Independent recovery dimensions

Target observed role: `unobserved`.

| Independent condition | Observed |
|---|---|
| Target process live | true |
| Cluster membership healthy | true |
| Full usable slot coverage | true |
| All shard leaders available | true |
| Client reads available | true |
| Client writes available | true |
| Acknowledged data verified | false |
| Configured write policy available | true |
| Replication redundancy restored | true |
| Persistence recovery verified | false |

## Timing

Milestones are first sampled observations, not Redis event timestamps. Orchestration includes ownership checks and fault execution. The action-completion column separates that overhead; neither anchor identifies the exact Redis event time. Unobserved milestones remain absent.

Fault action completed 2390.558 ms after orchestration began (measured with the monotonic runtime clock).

No primary promotion is required. Original owners and replica assignments must remain unchanged across the all-stopped barrier; frozen data and post-validation diagnostics are evaluated separately.

## Workload

| Phase | Attempts | Success rate | Errors | Throughput (ops/s) | Successful p50/p95/p99 (ms) |
|---|---:|---:|---:|---:|---|
| baseline | 830 | 100.00% | 0 | 199.82 | 0.632 / 0.890 / 1.135 |

Acknowledged writes: 433. Ambiguous SET outcomes: 0.

Write policy: `set`. Diagnostic stage requests are excluded from logical workload counts.

| Phase | SET acknowledged | SET errors |
|---|---:|---:|
| baseline | 433 | 0 |

| Phase | Measured path | Count | p50 / p95 / p99, ms |
|---|---|---:|---|
| baseline | Logical write completion | 433 | 0.664 / 0.934 / 1.449 |
| baseline | set | 433 | 0.632 / 0.890 / 1.449 |

| Phase | Successful logical writes | Successful writes/s over phase wall time |
|---|---:|---:|
| baseline | 433 | 104.245 |

Global pacing: offered 830; started 830; completed 830; dropped 0. These counts include all workload phases and exclude validation and probes.

Offered requests are ideal period slots from workload Start until the dispatcher observes Stop or parent cancellation; the first slot occurs after one period. The period is one second divided by the configured aggregate rate, truncated to whole nanoseconds. A central dispatcher offers only the latest due slot over an unbuffered channel; missed slots, busy workers, stopped tokens, and tokens with no eligible operation are dropped, without catch-up requests. Started requests count actual logical workload GET or write executions; a SET+WAIT/WAITAOF write counts once. Completed requests count their terminal logical metrics attempts. After Stop, offered = started + dropped and started = completed. Validation and ordinary/acknowledgement-policy probes are excluded. These global counters are not attributed to phases.

Validation attempted: true; expected: 433; checked: 433; missing: 433; corrupt: 0; unreadable: 0; unverified: 0. Validation complete: true.

### Terminal workload errors

| Phase | Error class | Count |
|---|---|---:|

Latencies use 512 bounded geometric histogram buckets, starting at 1 microsecond and increasing by 5%; quantiles are nearest-rank bucket upper bounds. The last bucket covers the remaining duration range. All terminal client attempts, successful attempts, and failed attempts have separate histograms. Throughput is completed attempts divided by phase wall-clock seconds. Operations are attributed to the phase in which they start. Redirect counts include only terminal MOVED/ASK errors; redirects handled by the client are not observable here.

## Errors

- persistence experiment ended partial: frozen data verified=false, original redundancy stable=true, restoration deadline=false

## Measurement methodology

- Quiet administrative process, CONFIG, persistence INFO, keyspace and bounded data-file preparation occurs before baseline traffic; it issues no SAVE, BGSAVE, BGREWRITEAOF or explicit durability barrier.
- The workload fully stops and joins in-flight acknowledgements before freezing its immutable ledger and counters. All later topology observations are read-only until every frozen acknowledged value has been checked. SET-error outcomes remain ambiguous, excluded from acknowledgement guarantees.
- Original replicas are SIGKILLed before original primaries. Every fixed owned container must produce ErrProcessStopped administrative evidence with restart policy no before any restart. Original primaries restart before replicas in the same containers and retained volumes; original Redis Cluster identities and slot ownership must survive.
- The model is sequential process SIGKILL while Docker VM, host and storage remain running, followed by same-container starts. It does not simulate power loss, host/page-cache loss or disk loss. Drain, kill and inspection intervals are reported because they permit background fsync progress.
- Topology restoration requires all six original identities, endpoints, primary slot owners and replica assignments synchronized for stable_for, without forced Redis topology commands. Physical receipts retain early raw evidence, which can be transient during full sync. Six fresh quiet administrative runtime/configuration/file observations after topology stability prove the final persistence mode on those same restarted processes, within the shared repair budget and before frozen-value validation. Samples crossing restoration or diagnostic deadlines are retained but excluded from successful milestones.
- Frozen-ledger GET validation happens exactly once before diagnostic SET/GET or configured replica-acknowledgement probes. Process/slot readiness and later diagnostic service are independent from frozen-value preservation; missing or corrupt values retain a partial data verdict even after service recovers.
- Memory mode has RDB/AOF disabled, rdb-del-sync-files=yes to remove replication-created RDB files, and observed absence of value persistence files. Its persistence-recovery event is not applicable and remains absent; its independent persistence dimension is false. AOF modes use the RDB base preamble required by the pinned image's bundled modules plus incremental AOF records. AOF recovery requires actual matching healthy runtime configuration, loading=0 and complete frozen acknowledged-value preservation; this observation establishes no loss-free or power-loss guarantee.
- No workload demand is offered after draining, so absent fault/recovery traffic does not measure zero availability or throughput. Post-validation probes are separate diagnostics and never enter workload metrics or the frozen ledger. Poll intervals follow sample completion; observations are sampled and non-atomic.

The JSON report contains effective configuration, environment metadata, raw topology replies, per-operation metrics, validation samples, and lifecycle timestamps. Effective configuration SHA-256: `4d51a2946a4630a2745a809e542f14a752a84eac8b35429962bf08a41f6174d1`.
