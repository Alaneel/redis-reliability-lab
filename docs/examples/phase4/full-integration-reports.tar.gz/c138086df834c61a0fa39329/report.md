# Redis Reliability Lab — primary-failure

Run: `c138086df834c61a0fa39329`  
Outcome: **recovered**  
Started: 2026-10-11T20:00:41.015516+08:00  
Finished: 2026-10-11T20:01:36.919228+08:00

## Recovery

| Condition | Observed |
|---|---|
| Original six-node topology recovered | true |
| Post-validation diagnostic service sustained | true |
| Topology and diagnostic service jointly sustained | true |
| Frozen acknowledged writes verified | true |
| All managed processes restarted | true |
| Original replication redundancy restored | true |
| Restoration deadline expired | false |
| Diagnostic deadline expired | false |
| Cleanup verified | true |


## Frozen-ledger process restart

Configured persistence mode: `aof-everysec`. Failure model: `sequential SIGKILL of all six Redis processes, same-container restart; host and storage remain running`.

Workload traffic stops and drains before the sequential SIGKILL actions. No workload requests are offered during fault or restart observation; these phases do not measure zero availability or recovery throughput. Read-only frozen-ledger validation precedes separate diagnostic writes.

Frozen acknowledged SETs: 432. Frozen ambiguous SET outcomes: 0.

Restoration deadline expired: false.

| Evidence anchor | Observed time |
|---|---|
| Traffic fully drained | 2026-10-11T20:01:03.933703+08:00 |
| Immutable ledger frozen | 2026-10-11T20:01:03.933872+08:00 |
| All six stopped verified before restart | 2026-10-11T20:01:06.346184+08:00 |
| First restart requested | 2026-10-11T20:01:07.347127+08:00 |
| Restart sequence completed | 2026-10-11T20:01:17.733127+08:00 |
| Frozen-ledger validation completed | 2026-10-11T20:01:30.045336+08:00 |
| Post-validation diagnostics requested | 2026-10-11T20:01:30.045653+08:00 |

Drain to first kill request: 0.210 ms (runtime monotonic clock).

Drain to last kill completion: 1619.714 ms (runtime monotonic clock).

All-stopped barrier to first restart request: 1000.934 ms (runtime monotonic clock).

| Restart observation | Since fault orchestration began, ms |
|---|---:|
| Original six-node replication ready | 17738.267 |
| Original topology sustained | 19223.609 |
| Replication redundancy sustained | 19223.609 |
| Post-validation diagnostic service sustained | 27608.225 |
| AOF frozen-value recovery observed | 26111.196 |

AOF frozen-value recovery observed: true. This criterion requires actual loading/configuration evidence and complete frozen-value preservation; restart or topology readiness alone cannot establish it.

Frozen-ledger validation: expected 432; checked 432; missing 0; corrupt 0; unreadable 0; unverified 0; complete true. Completion describes verification coverage; observed loss remains a data failure.

### Kill action order

| Order | Managed node | Requested | Completed | Error |
|---:|---|---|---|---|
| 1 | node-4 | 2026-10-11T20:01:03.933913+08:00 | 2026-10-11T20:01:04.205002+08:00 |  |
| 2 | node-5 | 2026-10-11T20:01:04.205016+08:00 | 2026-10-11T20:01:04.485754+08:00 |  |
| 3 | node-6 | 2026-10-11T20:01:04.485769+08:00 | 2026-10-11T20:01:04.756292+08:00 |  |
| 4 | node-1 | 2026-10-11T20:01:04.756311+08:00 | 2026-10-11T20:01:05.014923+08:00 |  |
| 5 | node-2 | 2026-10-11T20:01:05.014932+08:00 | 2026-10-11T20:01:05.283121+08:00 |  |
| 6 | node-3 | 2026-10-11T20:01:05.283141+08:00 | 2026-10-11T20:01:05.553431+08:00 |  |

### Restart action order

| Order | Managed node | Requested | Completed | Error |
|---:|---|---|---|---|
| 1 | node-1 | 2026-10-11T20:01:07.347127+08:00 | 2026-10-11T20:01:09.08388+08:00 |  |
| 2 | node-2 | 2026-10-11T20:01:09.083885+08:00 | 2026-10-11T20:01:10.767194+08:00 |  |
| 3 | node-3 | 2026-10-11T20:01:10.767204+08:00 | 2026-10-11T20:01:12.57992+08:00 |  |
| 4 | node-4 | 2026-10-11T20:01:12.579931+08:00 | 2026-10-11T20:01:14.303332+08:00 |  |
| 5 | node-5 | 2026-10-11T20:01:14.303342+08:00 | 2026-10-11T20:01:16.015092+08:00 |  |
| 6 | node-6 | 2026-10-11T20:01:16.015104+08:00 | 2026-10-11T20:01:17.733123+08:00 |  |

### Stopped administrative observations

| Managed node | Original Redis Cluster ID | Observed | Container running | Restart policy | Status/error |
|---|---|---|---|---|---|
| node-4 | 224f4d84a5f98fc80bffd38e3c0478b636735e06 | 2026-10-11T20:01:05.691407+08:00 | false | no | managed Redis process is stopped |
| node-5 | 4985cf93431eea2b8df467c4e9453890955081d7 | 2026-10-11T20:01:05.822888+08:00 | false | no | managed Redis process is stopped |
| node-6 | 7275100efe110ab4ddbfb7402d1748eb76e4c944 | 2026-10-11T20:01:05.95666+08:00 | false | no | managed Redis process is stopped |
| node-1 | 563a921438291913d835b06caa52e3337e0ca702 | 2026-10-11T20:01:06.092119+08:00 | false | no | managed Redis process is stopped |
| node-2 | 0a8d9f4df8f0f82fb511bbb45321a7ac1f4316c5 | 2026-10-11T20:01:06.219401+08:00 | false | no | managed Redis process is stopped |
| node-3 | 120f739f756e045fefb77597143e37eebdb9eef4 | 2026-10-11T20:01:06.346147+08:00 | false | no | managed Redis process is stopped |

### Prepared node-1

Original Redis Cluster ID: `563a921438291913d835b06caa52e3337e0ca702`. Process run ID: `25fc2a511b8d86434d18113d5b1693d85a8c56bf`. Observed: 2026-10-11T20:00:54.185422+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `563a921438291913d835b06caa52e3337e0ca702`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
repl-diskless-sync
yes
appendfsync
everysec
maxmemory
134217728
rdb-del-sync-files
yes
auto-aof-rewrite-percentage
0
appendonly
yes
aof-load-truncated
yes
no-appendfsync-on-rewrite
no
save

maxmemory-policy
noeviction
aof-use-rdb-preamble
yes
repl-diskless-load
swapdb
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720043
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:528384
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:0
aof_base_size:0
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Prepared node-2

Original Redis Cluster ID: `0a8d9f4df8f0f82fb511bbb45321a7ac1f4316c5`. Process run ID: `7faa739aae1e9521e009eb3c1d24fb96785b2212`. Observed: 2026-10-11T20:00:55.299056+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `0a8d9f4df8f0f82fb511bbb45321a7ac1f4316c5`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
repl-diskless-sync
yes
appendfsync
everysec
auto-aof-rewrite-percentage
0
aof-use-rdb-preamble
yes
save

no-appendfsync-on-rewrite
no
appendonly
yes
maxmemory-policy
noeviction
rdb-del-sync-files
yes
aof-load-truncated
yes
maxmemory
134217728
repl-diskless-load
swapdb
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720044
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:471040
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:0
aof_base_size:0
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Prepared node-3

Original Redis Cluster ID: `120f739f756e045fefb77597143e37eebdb9eef4`. Process run ID: `3979ba60eb300a0715cd47d327482ffad3d199f1`. Observed: 2026-10-11T20:00:56.535064+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `120f739f756e045fefb77597143e37eebdb9eef4`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
maxmemory-policy
noeviction
repl-diskless-sync
yes
auto-aof-rewrite-percentage
0
maxmemory
134217728
appendonly
yes
no-appendfsync-on-rewrite
no
appendfsync
everysec
save

aof-use-rdb-preamble
yes
repl-diskless-load
swapdb
rdb-del-sync-files
yes
aof-load-truncated
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720044
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:479232
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:0
aof_base_size:0
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Prepared node-4

Original Redis Cluster ID: `224f4d84a5f98fc80bffd38e3c0478b636735e06`. Process run ID: `fe3a3af00fbb074c2a1eeffd9b18652b6fb7f303`. Observed: 2026-10-11T20:00:57.656951+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `224f4d84a5f98fc80bffd38e3c0478b636735e06`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
save

repl-diskless-sync
yes
appendonly
yes
aof-use-rdb-preamble
yes
maxmemory
134217728
maxmemory-policy
noeviction
auto-aof-rewrite-percentage
0
repl-diskless-load
swapdb
rdb-del-sync-files
yes
aof-load-truncated
yes
appendfsync
everysec
no-appendfsync-on-rewrite
no
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720044
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:389120
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:108
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof

```

### Prepared node-5

Original Redis Cluster ID: `4985cf93431eea2b8df467c4e9453890955081d7`. Process run ID: `0d1035be3a288101919b3f91c640590588d0b39d`. Observed: 2026-10-11T20:00:58.712221+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `4985cf93431eea2b8df467c4e9453890955081d7`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
rdb-del-sync-files
yes
aof-use-rdb-preamble
yes
no-appendfsync-on-rewrite
no
auto-aof-rewrite-percentage
0
maxmemory
134217728
maxmemory-policy
noeviction
repl-diskless-sync
yes
appendonly
yes
aof-load-truncated
yes
appendfsync
everysec
repl-diskless-load
swapdb
save

```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720045
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:393216
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:108
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof

```

### Prepared node-6

Original Redis Cluster ID: `7275100efe110ab4ddbfb7402d1748eb76e4c944`. Process run ID: `89cf87f0bd19db81e8d7c78a8d7d3d9fd09fb1c8`. Observed: 2026-10-11T20:00:59.775645+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `7275100efe110ab4ddbfb7402d1748eb76e4c944`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
save

rdb-del-sync-files
yes
no-appendfsync-on-rewrite
no
repl-diskless-sync
yes
auto-aof-rewrite-percentage
0
aof-load-truncated
yes
appendonly
yes
maxmemory-policy
noeviction
maxmemory
134217728
aof-use-rdb-preamble
yes
appendfsync
everysec
repl-diskless-load
swapdb
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720045
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:372736
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:108
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof

```

### Restart receipt 1: node-1

Original Redis Cluster ID: `563a921438291913d835b06caa52e3337e0ca702`. Observed after restart: 2026-10-11T20:01:08.956852+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `563a921438291913d835b06caa52e3337e0ca702`. Restart policy: `no`. `/data` usage: 52 KiB.

Observed persistence configuration:

```text
repl-diskless-load
swapdb
rdb-del-sync-files
yes
appendonly
yes
maxmemory
134217728
appendfsync
everysec
maxmemory-policy
noeviction
aof-use-rdb-preamble
yes
aof-load-truncated
yes
no-appendfsync-on-rewrite
no
repl-diskless-sync
yes
auto-aof-rewrite-percentage
0
save

```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720067
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31733
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Restart receipt 2: node-2

Original Redis Cluster ID: `0a8d9f4df8f0f82fb511bbb45321a7ac1f4316c5`. Observed after restart: 2026-10-11T20:01:10.638287+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `0a8d9f4df8f0f82fb511bbb45321a7ac1f4316c5`. Restart policy: `no`. `/data` usage: 52 KiB.

Observed persistence configuration:

```text
auto-aof-rewrite-percentage
0
rdb-del-sync-files
yes
no-appendfsync-on-rewrite
no
maxmemory-policy
noeviction
repl-diskless-sync
yes
repl-diskless-load
swapdb
aof-load-truncated
yes
appendfsync
everysec
aof-use-rdb-preamble
yes
save

appendonly
yes
maxmemory
134217728
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720069
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31735
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Restart receipt 3: node-3

Original Redis Cluster ID: `120f739f756e045fefb77597143e37eebdb9eef4`. Observed after restart: 2026-10-11T20:01:12.451527+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `120f739f756e045fefb77597143e37eebdb9eef4`. Restart policy: `no`. `/data` usage: 52 KiB.

Observed persistence configuration:

```text
maxmemory
134217728
appendfsync
everysec
repl-diskless-sync
yes
no-appendfsync-on-rewrite
no
repl-diskless-load
swapdb
aof-use-rdb-preamble
yes
aof-load-truncated
yes
maxmemory-policy
noeviction
appendonly
yes
auto-aof-rewrite-percentage
0
rdb-del-sync-files
yes
save

```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720071
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31735
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Restart receipt 4: node-4

Original Redis Cluster ID: `224f4d84a5f98fc80bffd38e3c0478b636735e06`. Observed after restart: 2026-10-11T20:01:14.176992+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `224f4d84a5f98fc80bffd38e3c0478b636735e06`. Restart policy: `no`. `/data` usage: 52 KiB.

Observed persistence configuration:

```text
aof-use-rdb-preamble
yes
appendfsync
everysec
auto-aof-rewrite-percentage
0
maxmemory
134217728
no-appendfsync-on-rewrite
no
aof-load-truncated
yes
save

repl-diskless-sync
yes
repl-diskless-load
swapdb
rdb-del-sync-files
yes
appendonly
yes
maxmemory-policy
noeviction
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720072
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31735
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof
/data/temp-1791720072.1.rdb

```

### Restart receipt 5: node-5

Original Redis Cluster ID: `4985cf93431eea2b8df467c4e9453890955081d7`. Observed after restart: 2026-10-11T20:01:15.880336+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `4985cf93431eea2b8df467c4e9453890955081d7`. Restart policy: `no`. `/data` usage: 52 KiB.

Observed persistence configuration:

```text
appendonly
yes
save

no-appendfsync-on-rewrite
no
maxmemory-policy
noeviction
aof-use-rdb-preamble
yes
appendfsync
everysec
maxmemory
134217728
rdb-del-sync-files
yes
aof-load-truncated
yes
auto-aof-rewrite-percentage
0
repl-diskless-sync
yes
repl-diskless-load
swapdb
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720074
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31733
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/temp-1791720074.1.rdb
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof

```

### Restart receipt 6: node-6

Original Redis Cluster ID: `7275100efe110ab4ddbfb7402d1748eb76e4c944`. Observed after restart: 2026-10-11T20:01:17.598444+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `7275100efe110ab4ddbfb7402d1748eb76e4c944`. Restart policy: `no`. `/data` usage: 56 KiB.

Observed persistence configuration:

```text
repl-diskless-load
swapdb
maxmemory-policy
noeviction
rdb-del-sync-files
yes
no-appendfsync-on-rewrite
no
save

maxmemory
134217728
repl-diskless-sync
yes
aof-use-rdb-preamble
yes
appendfsync
everysec
appendonly
yes
aof-load-truncated
yes
auto-aof-rewrite-percentage
0
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720076
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31735
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/temp-1791720076.1.rdb
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof

```

### Post-synchronization runtime evidence

These fresh read-only administrative observations follow topology stability and precede frozen-ledger validation. They establish the sampled persistence configuration, loading status and data files; the earlier physical restart receipts remain unchanged.

#### Restored node-1

Original Redis Cluster ID: `563a921438291913d835b06caa52e3337e0ca702`. Process run ID: `416be0f5b0c1631bd96006faf43ece81108edb39`. Observed: 2026-10-11T20:01:24.484817+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `563a921438291913d835b06caa52e3337e0ca702`. Restart policy: `no`. `/data` usage: 52 KiB.

Observed persistence configuration:

```text
repl-diskless-load
swapdb
rdb-del-sync-files
yes
appendonly
yes
maxmemory
134217728
appendfsync
everysec
maxmemory-policy
noeviction
aof-use-rdb-preamble
yes
aof-load-truncated
yes
no-appendfsync-on-rewrite
no
repl-diskless-sync
yes
auto-aof-rewrite-percentage
0
save

```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720067
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:925696
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31733
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

#### Restored node-2

Original Redis Cluster ID: `0a8d9f4df8f0f82fb511bbb45321a7ac1f4316c5`. Process run ID: `daf78084bd725dbc230e0cabdec57dc70d2aca41`. Observed: 2026-10-11T20:01:25.546449+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `0a8d9f4df8f0f82fb511bbb45321a7ac1f4316c5`. Restart policy: `no`. `/data` usage: 52 KiB.

Observed persistence configuration:

```text
auto-aof-rewrite-percentage
0
rdb-del-sync-files
yes
no-appendfsync-on-rewrite
no
maxmemory-policy
noeviction
repl-diskless-sync
yes
repl-diskless-load
swapdb
aof-load-truncated
yes
appendfsync
everysec
aof-use-rdb-preamble
yes
save

appendonly
yes
maxmemory
134217728
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720069
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:921600
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31735
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

#### Restored node-3

Original Redis Cluster ID: `120f739f756e045fefb77597143e37eebdb9eef4`. Process run ID: `fbd1e5085534df700055330dbcfa63d1551c909b`. Observed: 2026-10-11T20:01:26.688825+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `120f739f756e045fefb77597143e37eebdb9eef4`. Restart policy: `no`. `/data` usage: 52 KiB.

Observed persistence configuration:

```text
maxmemory
134217728
appendfsync
everysec
repl-diskless-sync
yes
no-appendfsync-on-rewrite
no
repl-diskless-load
swapdb
aof-use-rdb-preamble
yes
aof-load-truncated
yes
maxmemory-policy
noeviction
appendonly
yes
auto-aof-rewrite-percentage
0
rdb-del-sync-files
yes
save

```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720071
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:933888
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31735
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

#### Restored node-4

Original Redis Cluster ID: `224f4d84a5f98fc80bffd38e3c0478b636735e06`. Process run ID: `af9d69316d7859d7a95b8269c8a7f17e86660085`. Observed: 2026-10-11T20:01:27.758592+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `224f4d84a5f98fc80bffd38e3c0478b636735e06`. Restart policy: `no`. `/data` usage: 40 KiB.

Observed persistence configuration:

```text
aof-use-rdb-preamble
yes
appendfsync
everysec
auto-aof-rewrite-percentage
0
maxmemory
134217728
no-appendfsync-on-rewrite
no
aof-load-truncated
yes
save

repl-diskless-sync
yes
repl-diskless-load
swapdb
rdb-del-sync-files
yes
appendonly
yes
maxmemory-policy
noeviction
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720072
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:145
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:700416
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:20849
aof_base_size:20849
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.3.incr.aof
/data/appendonlydir/appendonly.aof.3.base.rdb

```

#### Restored node-5

Original Redis Cluster ID: `4985cf93431eea2b8df467c4e9453890955081d7`. Process run ID: `724d5fa78d7707d72a08a0172dfefbd4ccf95b9d`. Observed: 2026-10-11T20:01:28.81867+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `4985cf93431eea2b8df467c4e9453890955081d7`. Restart policy: `no`. `/data` usage: 40 KiB.

Observed persistence configuration:

```text
appendonly
yes
save

no-appendfsync-on-rewrite
no
maxmemory-policy
noeviction
aof-use-rdb-preamble
yes
appendfsync
everysec
maxmemory
134217728
rdb-del-sync-files
yes
aof-load-truncated
yes
auto-aof-rewrite-percentage
0
repl-diskless-sync
yes
repl-diskless-load
swapdb
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720074
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:145
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:700416
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:20855
aof_base_size:20855
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.3.incr.aof
/data/appendonlydir/appendonly.aof.3.base.rdb

```

#### Restored node-6

Original Redis Cluster ID: `7275100efe110ab4ddbfb7402d1748eb76e4c944`. Process run ID: `d322816f417f1a4db16ca06ba0333c47b83cd074`. Observed: 2026-10-11T20:01:29.894769+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `7275100efe110ab4ddbfb7402d1748eb76e4c944`. Restart policy: `no`. `/data` usage: 40 KiB.

Observed persistence configuration:

```text
repl-diskless-load
swapdb
maxmemory-policy
noeviction
rdb-del-sync-files
yes
no-appendfsync-on-rewrite
no
save

maxmemory
134217728
repl-diskless-sync
yes
aof-use-rdb-preamble
yes
appendfsync
everysec
appendonly
yes
aof-load-truncated
yes
auto-aof-rewrite-percentage
0
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720076
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:145
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:684032
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:20823
aof_base_size:20823
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.3.incr.aof
/data/appendonlydir/appendonly.aof.3.base.rdb

```

This is a sequential process crash and same-container restart with retained managed volumes. It does not remove Docker VM/host page cache or simulate power loss, storage loss, or a graceful shutdown. Draining and sequential kill/inspection time allow background fsync to progress, so everysec preservation does not establish a one-second-loss guarantee or equivalence to always.

## Independent recovery dimensions

Target observed role: `unobserved`.

| Independent condition | Observed |
|---|---|
| Target process live | true |
| Cluster membership healthy | true |
| Full usable slot coverage | true |
| All shard leaders available | true |
| Client reads available | true |
| Client writes available | true |
| Acknowledged data verified | true |
| Configured write policy available | true |
| Replication redundancy restored | true |
| Persistence recovery verified | true |

## Timing

Milestones are first sampled observations, not Redis event timestamps. Orchestration includes ownership checks and fault execution. The action-completion column separates that overhead; neither anchor identifies the exact Redis event time. Unobserved milestones remain absent.

Fault action completed 2412.255 ms after orchestration began (measured with the monotonic runtime clock).

No primary promotion is required. Original owners and replica assignments must remain unchanged across the all-stopped barrier; frozen data and post-validation diagnostics are evaluated separately.

## Workload

| Phase | Attempts | Success rate | Errors | Throughput (ops/s) | Successful p50/p95/p99 (ms) |
|---|---:|---:|---:|---:|---|
| baseline | 828 | 100.00% | 0 | 199.94 | 0.602 / 0.768 / 0.934 |

Acknowledged writes: 432. Ambiguous SET outcomes: 0.

### Before-baseline persistence and command evidence

Persistence preparation contains 6 node observations. Raw CONFIG, INFO and data-file replies are retained in JSON; these observations are separate from frozen-ledger verification.

| Node | Original Redis Cluster ID | Observed at | Observed Redis Cluster ID | Redis PONG | Error |
|---|---|---|---|---|---|
| node-1 | 563a921438291913d835b06caa52e3337e0ca702 | 2026-10-11T20:00:54.185422+08:00 | 563a921438291913d835b06caa52e3337e0ca702 | true |  |
| node-2 | 0a8d9f4df8f0f82fb511bbb45321a7ac1f4316c5 | 2026-10-11T20:00:55.299056+08:00 | 0a8d9f4df8f0f82fb511bbb45321a7ac1f4316c5 | true |  |
| node-3 | 120f739f756e045fefb77597143e37eebdb9eef4 | 2026-10-11T20:00:56.535064+08:00 | 120f739f756e045fefb77597143e37eebdb9eef4 | true |  |
| node-4 | 224f4d84a5f98fc80bffd38e3c0478b636735e06 | 2026-10-11T20:00:57.656951+08:00 | 224f4d84a5f98fc80bffd38e3c0478b636735e06 | true |  |
| node-5 | 4985cf93431eea2b8df467c4e9453890955081d7 | 2026-10-11T20:00:58.712221+08:00 | 4985cf93431eea2b8df467c4e9453890955081d7 | true |  |
| node-6 | 7275100efe110ab4ddbfb7402d1748eb76e4c944 | 2026-10-11T20:00:59.775645+08:00 | 7275100efe110ab4ddbfb7402d1748eb76e4c944 | true |  |

Before-baseline `set` policy probe at 2026-10-11T20:00:59.792233+08:00; all shards successful: true.

| Original shard index | SET acknowledged |
|---|---|
| 0 | true |
| 1 | true |
| 2 | true |

Write policy: `set`. Diagnostic stage requests are excluded from logical workload counts.

| Phase | SET acknowledged | SET errors |
|---|---:|---:|
| baseline | 432 | 0 |

| Phase | Measured path | Count | p50 / p95 / p99, ms |
|---|---|---:|---|
| baseline | Logical write completion | 432 | 0.632 / 0.807 / 0.934 |
| baseline | set | 432 | 0.602 / 0.768 / 0.890 |

| Phase | Successful logical writes | Successful writes/s over phase wall time |
|---|---:|---:|
| baseline | 432 | 104.314 |

Global pacing: offered 828; started 828; completed 828; dropped 0. These counts include all workload phases and exclude validation and probes.

Offered requests are ideal period slots from workload Start until the dispatcher observes Stop or parent cancellation; the first slot occurs after one period. The period is one second divided by the configured aggregate rate, truncated to whole nanoseconds. A central dispatcher offers only the latest due slot over an unbuffered channel; missed slots, busy workers, stopped tokens, and tokens with no eligible operation are dropped, without catch-up requests. Started requests count actual logical workload GET or write executions; a SET+WAIT/WAITAOF write counts once. Completed requests count their terminal logical metrics attempts. After Stop, offered = started + dropped and started = completed. Validation and ordinary/acknowledgement-policy probes are excluded. These global counters are not attributed to phases.

Validation attempted: true; expected: 432; checked: 432; missing: 0; corrupt: 0; unreadable: 0; unverified: 0. Validation complete: true.

### Terminal workload errors

| Phase | Error class | Count |
|---|---|---:|

Latencies use 512 bounded geometric histogram buckets, starting at 1 microsecond and increasing by 5%; quantiles are nearest-rank bucket upper bounds. The last bucket covers the remaining duration range. All terminal client attempts, successful attempts, and failed attempts have separate histograms. Throughput is completed attempts divided by phase wall-clock seconds. Operations are attributed to the phase in which they start. Redirect counts include only terminal MOVED/ASK errors; redirects handled by the client are not observable here.

## Measurement methodology

- Quiet administrative process, CONFIG, persistence INFO, keyspace and bounded data-file preparation occurs before baseline traffic; it issues no SAVE, BGSAVE, BGREWRITEAOF or explicit durability barrier.
- The workload fully stops and joins in-flight acknowledgements before freezing its immutable ledger and counters. All later topology observations are read-only until every frozen acknowledged value has been checked. SET-error outcomes remain ambiguous, excluded from acknowledgement guarantees.
- Original replicas are SIGKILLed before original primaries. Every fixed owned container must produce ErrProcessStopped administrative evidence with restart policy no before any restart. Original primaries restart before replicas in the same containers and retained volumes; original Redis Cluster identities and slot ownership must survive.
- The model is sequential process SIGKILL while Docker VM, host and storage remain running, followed by same-container starts. It does not simulate power loss, host/page-cache loss or disk loss. Drain, kill and inspection intervals are reported because they permit background fsync progress.
- Topology restoration requires all six original identities, endpoints, primary slot owners and replica assignments synchronized for stable_for, without forced Redis topology commands. Physical receipts retain early raw evidence, which can be transient during full sync. Six fresh quiet administrative runtime/configuration/file observations after topology stability prove the final persistence mode on those same restarted processes, within the shared repair budget and before frozen-value validation. Samples crossing restoration or diagnostic deadlines are retained but excluded from successful milestones.
- Frozen-ledger GET validation happens exactly once before diagnostic SET/GET or configured replica-acknowledgement probes. Process/slot readiness and later diagnostic service are independent from frozen-value preservation; missing or corrupt values retain a partial data verdict even after service recovers.
- Memory mode has RDB/AOF disabled, rdb-del-sync-files=yes to remove replication-created RDB files, and observed absence of value persistence files. Its persistence-recovery event is not applicable and remains absent; its independent persistence dimension is false. AOF modes use the RDB base preamble required by the pinned image's bundled modules plus incremental AOF records. AOF recovery requires actual matching healthy runtime configuration, loading=0 and complete frozen acknowledged-value preservation; this observation establishes no loss-free or power-loss guarantee.
- No workload demand is offered after draining, so absent fault/recovery traffic does not measure zero availability or throughput. Post-validation probes are separate diagnostics and never enter workload metrics or the frozen ledger. Poll intervals follow sample completion; observations are sampled and non-atomic.
- All AOF modes and write policies use six-node quiet runtime preparation followed by exactly three all-shard policy SET/GET warmup writes before baseline starts. Warmup writes are excluded from the workload ledger and metrics; no WAITAOF compatibility command is issued after baseline to alter crash-trial durability.

The JSON report contains effective configuration, environment metadata, raw topology replies, per-operation metrics, validation samples, and lifecycle timestamps. Effective configuration SHA-256: `c2359755c7610c20f08fd8edb3a86d616be0dad17ff5b91cf389978cf97e4009`.
