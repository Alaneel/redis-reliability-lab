# Redis Reliability Lab — primary-failure

Run: `1cafc9fe125ea28d3a8a2bcd`  
Outcome: **recovered**  
Started: 2026-10-11T19:56:10.378309+08:00  
Finished: 2026-10-11T19:56:41.326403+08:00

## Recovery

| Condition | Observed |
|---|---|
| Surviving topology converged | true |
| All-shard client recovery sustained | true |
| Topology and client recovery jointly sustained | true |
| All acknowledged writes verified | true |
| Target process restarted | true |
| Original replication redundancy restored | true |
| Recovery deadline expired | false |
| Cleanup verified | true |


## Managed node lifecycle

Target: primary `node-1` (Redis ID `7878ecaa610dfcb68c6b7ef7b5e557079e729395`). Repair: `restart`.

Repair action completed: true. Repair or synchronization deadline expired: false.
Repair action duration: 1892.463 ms.
Stable redundancy first observed 5199.771 ms after repair action completed.

A completed restart or reconnect does not establish topology or replication recovery. Link-up and completed initial synchronization are sampled readiness conditions, not zero lag or durability guarantees.

| Lifecycle observation | Since fault orchestration began, ms |
|---|---:|
| Target failure detected | 2072.439 |
| Replication interruption observed | 2930.111 |
| Target reachable after repair | 6521.181 |
| Membership rejoined | 6521.181 |
| Replica link up | 10470.434 |
| Synchronization in progress | unobserved |
| Synchronization complete | 10470.434 |
| Primary full-sync counter increased | 6521.181 |
| Primary partial-sync counter increased | unobserved |
| Replication redundancy sustained | 11712.906 |

Resynchronization evidence: `full_sync_counter_increased`; primary Redis ID `2c3acfb0aa8fde6722892a2ee71b96bf25477f21`. Counters are server-wide primary deltas, not an exact target transfer or byte-loss measurement.

## Independent recovery dimensions

Target observed role: `slave`.

| Independent condition | Observed |
|---|---|
| Target process live | true |
| Cluster membership healthy | true |
| Full usable slot coverage | true |
| All shard leaders available | true |
| Client reads available | true |
| Client writes available | true |
| Acknowledged data verified | true |
| Configured write policy available | true |
| Replication redundancy restored | true |
| Persistence recovery verified | unobserved |

## Timing

Milestones are first sampled observations, not Redis event timestamps. Orchestration includes ownership checks and fault execution. The action-completion column separates that overhead; neither anchor identifies the exact Redis event time. Unobserved milestones remain absent.

Fault action completed 340.697 ms after orchestration began (measured with the monotonic runtime clock).

| Observation | Since orchestration began, ms | Since action completed, ms |
|---|---:|---:|
| Failure flagged in gossip | 2072.44 | 1731.74 |
| Original replica owns failed primary slots | 2930.11 | 2589.41 |
| Full usable slot coverage | 2930.11 | 2589.41 |
| Surviving views converge | 2930.11 | 2589.41 |
| First all-shard SET/GET probe succeeds | 3056.32 | 2715.62 |
| Client probes sustain recovery | 4492.63 | 4151.93 |
| Topology and clients sustain recovery | 4492.63 | 4151.93 |

## Workload

| Phase | Attempts | Success rate | Errors | Throughput (ops/s) | Successful p50/p95/p99 (ms) |
|---|---:|---:|---:|---:|---|
| baseline | 420 | 100.00% | 0 | 199.87 | 0.807 / 1.521 / 5.680 |
| fault | 595 | 75.46% | 146 | 128.77 | 0.732 / 1.849 / 210.082 |
| repair | 378 | 83.86% | 61 | 199.73 | 0.934 / 3.321 / 10.711 |
| reconciliation | 1080 | 88.80% | 121 | 199.81 | 0.768 / 1.521 / 4.239 |
| post_recovery | 200 | 100.00% | 0 | 199.71 | 0.807 / 2.141 / 5.680 |

Acknowledged writes: 1299. Ambiguous SET outcomes: 59.

Write policy: `wait`. Diagnostic stage requests are excluded from logical workload counts.
Logical write latency includes SET and WAIT on the same physical connection; policy success requires the requested replica-memory acknowledgement count.

| Phase | SET acknowledged | SET errors | WAIT attempted | WAIT satisfied | WAIT short | WAIT errors | WAIT client timeouts |
|---|---:|---:|---:|---:|---:|---:|---:|
| baseline | 220 | 0 | 220 | 220 | 0 | 0 | 0 |
| fault | 235 | 59 | 235 | 183 | 52 | 0 | 0 |
| repair | 183 | 0 | 183 | 122 | 61 | 0 | 0 |
| reconciliation | 552 | 0 | 552 | 431 | 121 | 0 | 0 |
| post_recovery | 109 | 0 | 109 | 109 | 0 | 0 | 0 |

| Phase | Measured path | Count | p50 / p95 / p99, ms |
|---|---|---:|---|
| baseline | Logical write completion | 220 | 0.934 / 1.521 / 5.680 |
| baseline | set | 220 | 0.472 / 0.890 / 4.239 |
| baseline | wait | 220 | 0.428 / 0.602 / 1.761 |
| fault | Logical write completion | 294 | 1.030 / 116.982 / 135.421 |
| fault | set | 294 | 0.520 / 1.081 / 1.849 |
| fault | wait | 235 | 0.520 / 122.831 / 135.421 |
| repair | Logical write completion | 183 | 1.521 / 128.972 / 142.192 |
| repair | set | 183 | 0.664 / 2.039 / 9.253 |
| repair | wait | 183 | 0.664 / 122.831 / 135.421 |
| reconciliation | Logical write completion | 552 | 1.030 / 116.982 / 128.972 |
| reconciliation | set | 552 | 0.520 / 0.981 / 2.602 |
| reconciliation | wait | 552 | 0.495 / 116.982 / 128.972 |
| post_recovery | Logical write completion | 109 | 0.934 / 3.163 / 8.812 |
| post_recovery | set | 109 | 0.472 / 1.380 / 6.263 |
| post_recovery | wait | 109 | 0.428 / 1.849 / 2.360 |

| Phase | Successful logical writes | Successful writes/s over phase wall time |
|---|---:|---:|
| baseline | 220 | 104.692 |
| fault | 183 | 39.605 |
| repair | 122 | 64.463 |
| reconciliation | 431 | 79.739 |
| post_recovery | 109 | 108.842 |

SET acknowledgements without a subsequent WAIT attempt: 0; client timeouts among those: 0. WAIT command errors and WAIT client timeouts above count attempted WAIT client calls only.

Configured write policy recovered for the stable interval: true. This criterion is independent of ordinary SET/GET service recovery.

Global pacing: offered 3004; started 2673; completed 2673; dropped 331. These counts include all workload phases and exclude validation and probes.

Offered requests are ideal period slots from workload Start until the dispatcher observes Stop or parent cancellation; the first slot occurs after one period. The period is one second divided by the configured aggregate rate, truncated to whole nanoseconds. A central dispatcher offers only the latest due slot over an unbuffered channel; missed slots, busy workers, stopped tokens, and tokens with no eligible operation are dropped, without catch-up requests. Started requests count actual logical workload GET or write executions; a SET+WAIT/WAITAOF write counts once. Completed requests count their terminal logical metrics attempts. After Stop, offered = started + dropped and started = completed. Validation and ordinary/acknowledgement-policy probes are excluded. These global counters are not attributed to phases.

Validation attempted: true; expected: 1299; checked: 1299; missing: 0; corrupt: 0; unreadable: 0; unverified: 0. Validation complete: true.

WAIT-satisfied subset: expected 1065; checked 1065; missing 0; corrupt 0; unreadable 0; unverified 0; complete true. The main ledger also includes every successful SET followed by incomplete WAIT.

### Terminal workload errors

| Phase | Error class | Count |
|---|---|---:|
| fault | CLUSTERDOWN | 18 |
| fault | network | 41 |
| fault | timeout | 35 |
| fault | wait_short | 52 |
| reconciliation | wait_short | 121 |
| repair | wait_short | 61 |

Latencies use 512 bounded geometric histogram buckets, starting at 1 microsecond and increasing by 5%; quantiles are nearest-rank bucket upper bounds. The last bucket covers the remaining duration range. All terminal client attempts, successful attempts, and failed attempts have separate histograms. Throughput is completed attempts divided by phase wall-clock seconds. Operations are attributed to the phase in which they start. Redirect counts include only terminal MOVED/ASK errors; redirects handled by the client are not observable here.

## Measurement methodology

- Fault selection preserves the initial primary and its replica. The destructive target is the selected primary after stable five-survivor service recovery; only strictly owned local Docker resources are affected.
- Replica faults preserve all original slot owners and do not require promotion. down_duration is a minimum hold from successful fault action completion, bounded by the recovery observation budget. Client service, failure gossip and replication interruption are separately sampled.
- Replica network isolation removes its complete bidirectional Docker bridge connectivity while Redis remains running. It is not a selective replication-only partition. Restoration uses the same owned endpoint and unchanged live process identity.
- Administrative endpoint-disconnection evidence is separate from Redis INFO link or connected-replica indicators. A short disconnection can finish before TCP/link failure detection; absent interruption or synchronization-counter milestones remain unobserved and are not invented from the Docker interface state.
- Crash repair starts the same stopped owned container with its bounded disposable data volume. Redis Cluster identity must match the pre-fault identity. Restart changes the process; it does not simulate power loss, host/storage failure or persistence durability.
- The repair deadline covers the restart/reconnect action and subsequent synchronization. Redis's current membership is inspected without issuing CLUSTER REPLICATE or forcing slot ownership. Replica repair preserves original assignments; former-primary repair requires the original replica to retain promoted ownership and the old primary to rejoin as its replica.
- Fresh stability after repair requires all six original identities and endpoints, healthy equal slot maps, exactly one synchronized replica per primary, and all-shard client probes. Historical service recovery remains separate from final redundancy and configured acknowledgement-policy availability.
- Replication link-up and master_sync_in_progress=0 are sampled indicators, not exact zero lag, bytes preserved, or identification of partial versus full resynchronization. Raw replication INFO is retained for inspection; unobserved milestones remain absent.
- Traffic drains before validating every acknowledged immutable SET, including short/error WAIT/WAITAOF outcomes. Ambiguous SET errors remain separate. Cancellation skips unsupported recovery/data claims and still uses fresh bounded restoration and cleanup contexts, including managed volumes.
- Configured acknowledgement policy is a separate current condition, measured through all-three-shard SET plus WAIT/WAITAOF on one physical connection. A stable policy milestone is historical; a later unsuccessful probe resets the current condition.

The JSON report contains effective configuration, environment metadata, raw topology replies, per-operation metrics, validation samples, and lifecycle timestamps. Effective configuration SHA-256: `9183d97e3ad5f261f035470d0f336f5df2d4752edfdb6f728638e68c528f6f4b`.
