# Redis Reliability Lab — primary-failure

Run: `f26495be174028e39c741fd1`  
Outcome: **recovered**  
Started: 2026-10-11T20:01:38.35861+08:00  
Finished: 2026-10-11T20:02:33.117328+08:00

## Recovery

| Condition | Observed |
|---|---|
| Original six-node topology recovered | true |
| Post-validation diagnostic service sustained | true |
| Topology and diagnostic service jointly sustained | true |
| Frozen acknowledged writes verified | true |
| All managed processes restarted | true |
| Original replication redundancy restored | true |
| Restoration deadline expired | false |
| Diagnostic deadline expired | false |
| Cleanup verified | true |


## Frozen-ledger process restart

Configured persistence mode: `aof-always`. Failure model: `sequential SIGKILL of all six Redis processes, same-container restart; host and storage remain running`.

Workload traffic stops and drains before the sequential SIGKILL actions. No workload requests are offered during fault or restart observation; these phases do not measure zero availability or recovery throughput. Read-only frozen-ledger validation precedes separate diagnostic writes.

Frozen acknowledged SETs: 432. Frozen ambiguous SET outcomes: 0.

Restoration deadline expired: false.

| Evidence anchor | Observed time |
|---|---|
| Traffic fully drained | 2026-10-11T20:02:01.649542+08:00 |
| Immutable ledger frozen | 2026-10-11T20:02:01.649827+08:00 |
| All six stopped verified before restart | 2026-10-11T20:02:04.023482+08:00 |
| First restart requested | 2026-10-11T20:02:05.024987+08:00 |
| Restart sequence completed | 2026-10-11T20:02:15.24931+08:00 |
| Frozen-ledger validation completed | 2026-10-11T20:02:26.683415+08:00 |
| Post-validation diagnostics requested | 2026-10-11T20:02:26.683723+08:00 |

Drain to first kill request: 0.320 ms (runtime monotonic clock).

Drain to last kill completion: 1565.729 ms (runtime monotonic clock).

All-stopped barrier to first restart request: 1001.496 ms (runtime monotonic clock).

| Restart observation | Since fault orchestration began, ms |
|---|---:|
| Original six-node replication ready | 16628.892 |
| Original topology sustained | 18096.127 |
| Replication redundancy sustained | 18096.127 |
| Post-validation diagnostic service sustained | 26536.438 |
| AOF frozen-value recovery observed | 25033.336 |

AOF frozen-value recovery observed: true. This criterion requires actual loading/configuration evidence and complete frozen-value preservation; restart or topology readiness alone cannot establish it.

Frozen-ledger validation: expected 432; checked 432; missing 0; corrupt 0; unreadable 0; unverified 0; complete true. Completion describes verification coverage; observed loss remains a data failure.

### Kill action order

| Order | Managed node | Requested | Completed | Error |
|---:|---|---|---|---|
| 1 | node-4 | 2026-10-11T20:02:01.649862+08:00 | 2026-10-11T20:02:01.901729+08:00 |  |
| 2 | node-5 | 2026-10-11T20:02:01.901745+08:00 | 2026-10-11T20:02:02.173554+08:00 |  |
| 3 | node-6 | 2026-10-11T20:02:02.173575+08:00 | 2026-10-11T20:02:02.437259+08:00 |  |
| 4 | node-1 | 2026-10-11T20:02:02.437275+08:00 | 2026-10-11T20:02:02.696338+08:00 |  |
| 5 | node-2 | 2026-10-11T20:02:02.69635+08:00 | 2026-10-11T20:02:02.961308+08:00 |  |
| 6 | node-3 | 2026-10-11T20:02:02.961325+08:00 | 2026-10-11T20:02:03.215285+08:00 |  |

### Restart action order

| Order | Managed node | Requested | Completed | Error |
|---:|---|---|---|---|
| 1 | node-1 | 2026-10-11T20:02:05.024987+08:00 | 2026-10-11T20:02:06.725605+08:00 |  |
| 2 | node-2 | 2026-10-11T20:02:06.725613+08:00 | 2026-10-11T20:02:08.367387+08:00 |  |
| 3 | node-3 | 2026-10-11T20:02:08.367394+08:00 | 2026-10-11T20:02:10.058387+08:00 |  |
| 4 | node-4 | 2026-10-11T20:02:10.058396+08:00 | 2026-10-11T20:02:11.796897+08:00 |  |
| 5 | node-5 | 2026-10-11T20:02:11.796901+08:00 | 2026-10-11T20:02:13.583526+08:00 |  |
| 6 | node-6 | 2026-10-11T20:02:13.583537+08:00 | 2026-10-11T20:02:15.249306+08:00 |  |

### Stopped administrative observations

| Managed node | Original Redis Cluster ID | Observed | Container running | Restart policy | Status/error |
|---|---|---|---|---|---|
| node-4 | a4a87e8cb9be45ac2396b44bd85a634bb84972dc | 2026-10-11T20:02:03.35391+08:00 | false | no | managed Redis process is stopped |
| node-5 | e7212df5cdc1ccda9b79dc18b0f40fa89dbb888e | 2026-10-11T20:02:03.483315+08:00 | false | no | managed Redis process is stopped |
| node-6 | 201c79da66f32e6bcab3b61fc22f451dac3705e0 | 2026-10-11T20:02:03.610353+08:00 | false | no | managed Redis process is stopped |
| node-1 | 5916df9eafe137c0376dd486df77530bdd77420b | 2026-10-11T20:02:03.738267+08:00 | false | no | managed Redis process is stopped |
| node-2 | 853e5e21713a2064722581beb031d65523f67fd4 | 2026-10-11T20:02:03.867515+08:00 | false | no | managed Redis process is stopped |
| node-3 | f5406ebf3bfb71c867b7c3e7a2ffcbcba9e1adaf | 2026-10-11T20:02:04.023439+08:00 | false | no | managed Redis process is stopped |

### Prepared node-1

Original Redis Cluster ID: `5916df9eafe137c0376dd486df77530bdd77420b`. Process run ID: `184a6120ef8ce61b273dda882db0fcde37b5b52d`. Observed: 2026-10-11T20:01:52.158305+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `5916df9eafe137c0376dd486df77530bdd77420b`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
rdb-del-sync-files
yes
no-appendfsync-on-rewrite
no
aof-use-rdb-preamble
yes
repl-diskless-sync
yes
repl-diskless-load
swapdb
save

maxmemory-policy
noeviction
appendonly
yes
auto-aof-rewrite-percentage
0
appendfsync
always
maxmemory
134217728
aof-load-truncated
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720101
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:536576
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:0
aof_base_size:0
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Prepared node-2

Original Redis Cluster ID: `853e5e21713a2064722581beb031d65523f67fd4`. Process run ID: `f36f980abd2760876f669ab548fe068cf0e53836`. Observed: 2026-10-11T20:01:53.238398+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `853e5e21713a2064722581beb031d65523f67fd4`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
repl-diskless-load
swapdb
no-appendfsync-on-rewrite
no
save

repl-diskless-sync
yes
aof-use-rdb-preamble
yes
appendfsync
always
auto-aof-rewrite-percentage
0
rdb-del-sync-files
yes
aof-load-truncated
yes
appendonly
yes
maxmemory-policy
noeviction
maxmemory
134217728
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720102
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:536576
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:0
aof_base_size:0
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Prepared node-3

Original Redis Cluster ID: `f5406ebf3bfb71c867b7c3e7a2ffcbcba9e1adaf`. Process run ID: `5163a81a4dfd56977a628d1c90272f6d8c0d8aba`. Observed: 2026-10-11T20:01:54.312886+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `f5406ebf3bfb71c867b7c3e7a2ffcbcba9e1adaf`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
repl-diskless-load
swapdb
appendonly
yes
maxmemory
134217728
maxmemory-policy
noeviction
appendfsync
always
save

auto-aof-rewrite-percentage
0
repl-diskless-sync
yes
aof-load-truncated
yes
no-appendfsync-on-rewrite
no
aof-use-rdb-preamble
yes
rdb-del-sync-files
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720102
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:466944
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:0
aof_base_size:0
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Prepared node-4

Original Redis Cluster ID: `a4a87e8cb9be45ac2396b44bd85a634bb84972dc`. Process run ID: `94be9edca52e3775d40d9f22bf88f539cbc0bbf7`. Observed: 2026-10-11T20:01:55.383203+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `a4a87e8cb9be45ac2396b44bd85a634bb84972dc`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
repl-diskless-sync
yes
appendonly
yes
aof-use-rdb-preamble
yes
save

maxmemory
134217728
maxmemory-policy
noeviction
aof-load-truncated
yes
auto-aof-rewrite-percentage
0
rdb-del-sync-files
yes
no-appendfsync-on-rewrite
no
repl-diskless-load
swapdb
appendfsync
always
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720102
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:770048
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:108
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof

```

### Prepared node-5

Original Redis Cluster ID: `e7212df5cdc1ccda9b79dc18b0f40fa89dbb888e`. Process run ID: `128d0848a3ed188e8147459f4bb5d1e31bbc1883`. Observed: 2026-10-11T20:01:56.432121+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `e7212df5cdc1ccda9b79dc18b0f40fa89dbb888e`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
no-appendfsync-on-rewrite
no
save

repl-diskless-sync
yes
appendonly
yes
auto-aof-rewrite-percentage
0
rdb-del-sync-files
yes
maxmemory-policy
noeviction
appendfsync
always
aof-use-rdb-preamble
yes
repl-diskless-load
swapdb
maxmemory
134217728
aof-load-truncated
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720103
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:389120
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:108
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof

```

### Prepared node-6

Original Redis Cluster ID: `201c79da66f32e6bcab3b61fc22f451dac3705e0`. Process run ID: `b279768455c0c173ce7afcc94d02d6f8058cbd0f`. Observed: 2026-10-11T20:01:57.486234+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `201c79da66f32e6bcab3b61fc22f451dac3705e0`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
rdb-del-sync-files
yes
maxmemory
134217728
save

maxmemory-policy
noeviction
repl-diskless-sync
yes
auto-aof-rewrite-percentage
0
no-appendfsync-on-rewrite
no
aof-use-rdb-preamble
yes
aof-load-truncated
yes
appendfsync
always
repl-diskless-load
swapdb
appendonly
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720103
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:393216
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:108
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof

```

### Restart receipt 1: node-1

Original Redis Cluster ID: `5916df9eafe137c0376dd486df77530bdd77420b`. Observed after restart: 2026-10-11T20:02:06.600571+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `5916df9eafe137c0376dd486df77530bdd77420b`. Restart policy: `no`. `/data` usage: 56 KiB.

Observed persistence configuration:

```text
repl-diskless-sync
yes
auto-aof-rewrite-percentage
0
maxmemory-policy
noeviction
rdb-del-sync-files
yes
save

appendfsync
always
no-appendfsync-on-rewrite
no
appendonly
yes
aof-use-rdb-preamble
yes
repl-diskless-load
swapdb
aof-load-truncated
yes
maxmemory
134217728
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720125
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31733
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Restart receipt 2: node-2

Original Redis Cluster ID: `853e5e21713a2064722581beb031d65523f67fd4`. Observed after restart: 2026-10-11T20:02:08.240733+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `853e5e21713a2064722581beb031d65523f67fd4`. Restart policy: `no`. `/data` usage: 52 KiB.

Observed persistence configuration:

```text
rdb-del-sync-files
yes
repl-diskless-load
swapdb
appendfsync
always
maxmemory
134217728
maxmemory-policy
noeviction
no-appendfsync-on-rewrite
no
repl-diskless-sync
yes
aof-use-rdb-preamble
yes
save

auto-aof-rewrite-percentage
0
appendonly
yes
aof-load-truncated
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720127
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31735
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Restart receipt 3: node-3

Original Redis Cluster ID: `f5406ebf3bfb71c867b7c3e7a2ffcbcba9e1adaf`. Observed after restart: 2026-10-11T20:02:09.931656+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `f5406ebf3bfb71c867b7c3e7a2ffcbcba9e1adaf`. Restart policy: `no`. `/data` usage: 56 KiB.

Observed persistence configuration:

```text
repl-diskless-load
swapdb
appendfsync
always
maxmemory-policy
noeviction
aof-use-rdb-preamble
yes
repl-diskless-sync
yes
auto-aof-rewrite-percentage
0
maxmemory
134217728
aof-load-truncated
yes
rdb-del-sync-files
yes
no-appendfsync-on-rewrite
no
save

appendonly
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720128
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31735
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Restart receipt 4: node-4

Original Redis Cluster ID: `a4a87e8cb9be45ac2396b44bd85a634bb84972dc`. Observed after restart: 2026-10-11T20:02:11.66165+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `a4a87e8cb9be45ac2396b44bd85a634bb84972dc`. Restart policy: `no`. `/data` usage: 56 KiB.

Observed persistence configuration:

```text
appendfsync
always
auto-aof-rewrite-percentage
0
save

aof-use-rdb-preamble
yes
rdb-del-sync-files
yes
maxmemory
134217728
appendonly
yes
aof-load-truncated
yes
repl-diskless-load
swapdb
no-appendfsync-on-rewrite
no
repl-diskless-sync
yes
maxmemory-policy
noeviction
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720130
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31735
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof
/data/temp-1791720130.1.rdb

```

### Restart receipt 5: node-5

Original Redis Cluster ID: `e7212df5cdc1ccda9b79dc18b0f40fa89dbb888e`. Observed after restart: 2026-10-11T20:02:13.456429+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `e7212df5cdc1ccda9b79dc18b0f40fa89dbb888e`. Restart policy: `no`. `/data` usage: 52 KiB.

Observed persistence configuration:

```text
appendfsync
always
save

auto-aof-rewrite-percentage
0
maxmemory-policy
noeviction
rdb-del-sync-files
yes
repl-diskless-load
swapdb
maxmemory
134217728
aof-use-rdb-preamble
yes
aof-load-truncated
yes
appendonly
yes
no-appendfsync-on-rewrite
no
repl-diskless-sync
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720132
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31733
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof
/data/temp-1791720132.1.rdb

```

### Restart receipt 6: node-6

Original Redis Cluster ID: `201c79da66f32e6bcab3b61fc22f451dac3705e0`. Observed after restart: 2026-10-11T20:02:15.118914+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `201c79da66f32e6bcab3b61fc22f451dac3705e0`. Restart policy: `no`. `/data` usage: 52 KiB.

Observed persistence configuration:

```text
maxmemory-policy
noeviction
aof-use-rdb-preamble
yes
aof-load-truncated
yes
rdb-del-sync-files
yes
save

auto-aof-rewrite-percentage
0
no-appendfsync-on-rewrite
no
repl-diskless-sync
yes
appendonly
yes
appendfsync
always
repl-diskless-load
swapdb
maxmemory
134217728
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720133
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31735
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof
/data/temp-1791720133.1.rdb

```

### Post-synchronization runtime evidence

These fresh read-only administrative observations follow topology stability and precede frozen-ledger validation. They establish the sampled persistence configuration, loading status and data files; the earlier physical restart receipts remain unchanged.

#### Restored node-1

Original Redis Cluster ID: `5916df9eafe137c0376dd486df77530bdd77420b`. Process run ID: `a17bc3bf1a725fa6fd38fc78163ad88bf46d6f9c`. Observed: 2026-10-11T20:02:21.177395+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `5916df9eafe137c0376dd486df77530bdd77420b`. Restart policy: `no`. `/data` usage: 56 KiB.

Observed persistence configuration:

```text
repl-diskless-sync
yes
auto-aof-rewrite-percentage
0
maxmemory-policy
noeviction
rdb-del-sync-files
yes
save

appendfsync
always
no-appendfsync-on-rewrite
no
appendonly
yes
aof-use-rdb-preamble
yes
repl-diskless-load
swapdb
aof-load-truncated
yes
maxmemory
134217728
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720125
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:872448
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31733
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

#### Restored node-2

Original Redis Cluster ID: `853e5e21713a2064722581beb031d65523f67fd4`. Process run ID: `840028e4805f76915b32033c9d14745781718805`. Observed: 2026-10-11T20:02:22.277832+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `853e5e21713a2064722581beb031d65523f67fd4`. Restart policy: `no`. `/data` usage: 52 KiB.

Observed persistence configuration:

```text
rdb-del-sync-files
yes
repl-diskless-load
swapdb
appendfsync
always
maxmemory
134217728
maxmemory-policy
noeviction
no-appendfsync-on-rewrite
no
repl-diskless-sync
yes
aof-use-rdb-preamble
yes
save

auto-aof-rewrite-percentage
0
appendonly
yes
aof-load-truncated
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720127
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:946176
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31735
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

#### Restored node-3

Original Redis Cluster ID: `f5406ebf3bfb71c867b7c3e7a2ffcbcba9e1adaf`. Process run ID: `c9880f21a987f9853b739c23fdf69bfe4ff7bcf7`. Observed: 2026-10-11T20:02:23.342017+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `f5406ebf3bfb71c867b7c3e7a2ffcbcba9e1adaf`. Restart policy: `no`. `/data` usage: 56 KiB.

Observed persistence configuration:

```text
repl-diskless-load
swapdb
appendfsync
always
maxmemory-policy
noeviction
aof-use-rdb-preamble
yes
repl-diskless-sync
yes
auto-aof-rewrite-percentage
0
maxmemory
134217728
aof-load-truncated
yes
rdb-del-sync-files
yes
no-appendfsync-on-rewrite
no
save

appendonly
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720128
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:946176
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31735
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

#### Restored node-4

Original Redis Cluster ID: `a4a87e8cb9be45ac2396b44bd85a634bb84972dc`. Process run ID: `b263d2dd2689988112f7c9ddcf5190e6f93809aa`. Observed: 2026-10-11T20:02:24.392189+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `a4a87e8cb9be45ac2396b44bd85a634bb84972dc`. Restart policy: `no`. `/data` usage: 40 KiB.

Observed persistence configuration:

```text
appendfsync
always
auto-aof-rewrite-percentage
0
save

aof-use-rdb-preamble
yes
rdb-del-sync-files
yes
maxmemory
134217728
appendonly
yes
aof-load-truncated
yes
repl-diskless-load
swapdb
no-appendfsync-on-rewrite
no
repl-diskless-sync
yes
maxmemory-policy
noeviction
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720130
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:145
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:745472
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:20844
aof_base_size:20844
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.3.incr.aof
/data/appendonlydir/appendonly.aof.3.base.rdb

```

#### Restored node-5

Original Redis Cluster ID: `e7212df5cdc1ccda9b79dc18b0f40fa89dbb888e`. Process run ID: `ae1b484bb930974e88643e064751be98452579df`. Observed: 2026-10-11T20:02:25.47358+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `e7212df5cdc1ccda9b79dc18b0f40fa89dbb888e`. Restart policy: `no`. `/data` usage: 40 KiB.

Observed persistence configuration:

```text
appendfsync
always
save

auto-aof-rewrite-percentage
0
maxmemory-policy
noeviction
rdb-del-sync-files
yes
repl-diskless-load
swapdb
maxmemory
134217728
aof-use-rdb-preamble
yes
aof-load-truncated
yes
appendonly
yes
no-appendfsync-on-rewrite
no
repl-diskless-sync
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720132
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:145
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:708608
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:20852
aof_base_size:20852
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.3.incr.aof
/data/appendonlydir/appendonly.aof.3.base.rdb

```

#### Restored node-6

Original Redis Cluster ID: `201c79da66f32e6bcab3b61fc22f451dac3705e0`. Process run ID: `a1f7eb46ed37dc5187896545839ec3a876ce9288`. Observed: 2026-10-11T20:02:26.536887+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `201c79da66f32e6bcab3b61fc22f451dac3705e0`. Restart policy: `no`. `/data` usage: 40 KiB.

Observed persistence configuration:

```text
maxmemory-policy
noeviction
aof-use-rdb-preamble
yes
aof-load-truncated
yes
rdb-del-sync-files
yes
save

auto-aof-rewrite-percentage
0
no-appendfsync-on-rewrite
no
repl-diskless-sync
yes
appendonly
yes
appendfsync
always
repl-diskless-load
swapdb
maxmemory
134217728
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720133
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:145
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:688128
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:20842
aof_base_size:20842
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.3.incr.aof
/data/appendonlydir/appendonly.aof.3.base.rdb

```

This is a sequential process crash and same-container restart with retained managed volumes. It does not remove Docker VM/host page cache or simulate power loss, storage loss, or a graceful shutdown. Draining and sequential kill/inspection time allow background fsync to progress, so everysec preservation does not establish a one-second-loss guarantee or equivalence to always.

## Independent recovery dimensions

Target observed role: `unobserved`.

| Independent condition | Observed |
|---|---|
| Target process live | true |
| Cluster membership healthy | true |
| Full usable slot coverage | true |
| All shard leaders available | true |
| Client reads available | true |
| Client writes available | true |
| Acknowledged data verified | true |
| Configured write policy available | true |
| Replication redundancy restored | true |
| Persistence recovery verified | true |

## Timing

Milestones are first sampled observations, not Redis event timestamps. Orchestration includes ownership checks and fault execution. The action-completion column separates that overhead; neither anchor identifies the exact Redis event time. Unobserved milestones remain absent.

Fault action completed 2373.603 ms after orchestration began (measured with the monotonic runtime clock).

No primary promotion is required. Original owners and replica assignments must remain unchanged across the all-stopped barrier; frozen data and post-validation diagnostics are evaluated separately.

## Workload

| Phase | Attempts | Success rate | Errors | Throughput (ops/s) | Successful p50/p95/p99 (ms) |
|---|---:|---:|---:|---:|---|
| baseline | 828 | 100.00% | 0 | 199.76 | 0.807 / 1.449 / 1.761 |

Acknowledged writes: 432. Ambiguous SET outcomes: 0.

### Before-baseline persistence and command evidence

Persistence preparation contains 6 node observations. Raw CONFIG, INFO and data-file replies are retained in JSON; these observations are separate from frozen-ledger verification.

| Node | Original Redis Cluster ID | Observed at | Observed Redis Cluster ID | Redis PONG | Error |
|---|---|---|---|---|---|
| node-1 | 5916df9eafe137c0376dd486df77530bdd77420b | 2026-10-11T20:01:52.158305+08:00 | 5916df9eafe137c0376dd486df77530bdd77420b | true |  |
| node-2 | 853e5e21713a2064722581beb031d65523f67fd4 | 2026-10-11T20:01:53.238398+08:00 | 853e5e21713a2064722581beb031d65523f67fd4 | true |  |
| node-3 | f5406ebf3bfb71c867b7c3e7a2ffcbcba9e1adaf | 2026-10-11T20:01:54.312886+08:00 | f5406ebf3bfb71c867b7c3e7a2ffcbcba9e1adaf | true |  |
| node-4 | a4a87e8cb9be45ac2396b44bd85a634bb84972dc | 2026-10-11T20:01:55.383203+08:00 | a4a87e8cb9be45ac2396b44bd85a634bb84972dc | true |  |
| node-5 | e7212df5cdc1ccda9b79dc18b0f40fa89dbb888e | 2026-10-11T20:01:56.432121+08:00 | e7212df5cdc1ccda9b79dc18b0f40fa89dbb888e | true |  |
| node-6 | 201c79da66f32e6bcab3b61fc22f451dac3705e0 | 2026-10-11T20:01:57.486234+08:00 | 201c79da66f32e6bcab3b61fc22f451dac3705e0 | true |  |

Before-baseline `set` policy probe at 2026-10-11T20:01:57.504544+08:00; all shards successful: true.

| Original shard index | SET acknowledged |
|---|---|
| 0 | true |
| 1 | true |
| 2 | true |

Write policy: `set`. Diagnostic stage requests are excluded from logical workload counts.

| Phase | SET acknowledged | SET errors |
|---|---:|---:|
| baseline | 432 | 0 |

| Phase | Measured path | Count | p50 / p95 / p99, ms |
|---|---|---:|---|
| baseline | Logical write completion | 432 | 1.081 / 1.521 / 1.942 |
| baseline | set | 432 | 1.030 / 1.521 / 1.942 |

| Phase | Successful logical writes | Successful writes/s over phase wall time |
|---|---:|---:|
| baseline | 432 | 104.225 |

Global pacing: offered 828; started 828; completed 828; dropped 0. These counts include all workload phases and exclude validation and probes.

Offered requests are ideal period slots from workload Start until the dispatcher observes Stop or parent cancellation; the first slot occurs after one period. The period is one second divided by the configured aggregate rate, truncated to whole nanoseconds. A central dispatcher offers only the latest due slot over an unbuffered channel; missed slots, busy workers, stopped tokens, and tokens with no eligible operation are dropped, without catch-up requests. Started requests count actual logical workload GET or write executions; a SET+WAIT/WAITAOF write counts once. Completed requests count their terminal logical metrics attempts. After Stop, offered = started + dropped and started = completed. Validation and ordinary/acknowledgement-policy probes are excluded. These global counters are not attributed to phases.

Validation attempted: true; expected: 432; checked: 432; missing: 0; corrupt: 0; unreadable: 0; unverified: 0. Validation complete: true.

### Terminal workload errors

| Phase | Error class | Count |
|---|---|---:|

Latencies use 512 bounded geometric histogram buckets, starting at 1 microsecond and increasing by 5%; quantiles are nearest-rank bucket upper bounds. The last bucket covers the remaining duration range. All terminal client attempts, successful attempts, and failed attempts have separate histograms. Throughput is completed attempts divided by phase wall-clock seconds. Operations are attributed to the phase in which they start. Redirect counts include only terminal MOVED/ASK errors; redirects handled by the client are not observable here.

## Measurement methodology

- Quiet administrative process, CONFIG, persistence INFO, keyspace and bounded data-file preparation occurs before baseline traffic; it issues no SAVE, BGSAVE, BGREWRITEAOF or explicit durability barrier.
- The workload fully stops and joins in-flight acknowledgements before freezing its immutable ledger and counters. All later topology observations are read-only until every frozen acknowledged value has been checked. SET-error outcomes remain ambiguous, excluded from acknowledgement guarantees.
- Original replicas are SIGKILLed before original primaries. Every fixed owned container must produce ErrProcessStopped administrative evidence with restart policy no before any restart. Original primaries restart before replicas in the same containers and retained volumes; original Redis Cluster identities and slot ownership must survive.
- The model is sequential process SIGKILL while Docker VM, host and storage remain running, followed by same-container starts. It does not simulate power loss, host/page-cache loss or disk loss. Drain, kill and inspection intervals are reported because they permit background fsync progress.
- Topology restoration requires all six original identities, endpoints, primary slot owners and replica assignments synchronized for stable_for, without forced Redis topology commands. Physical receipts retain early raw evidence, which can be transient during full sync. Six fresh quiet administrative runtime/configuration/file observations after topology stability prove the final persistence mode on those same restarted processes, within the shared repair budget and before frozen-value validation. Samples crossing restoration or diagnostic deadlines are retained but excluded from successful milestones.
- Frozen-ledger GET validation happens exactly once before diagnostic SET/GET or configured replica-acknowledgement probes. Process/slot readiness and later diagnostic service are independent from frozen-value preservation; missing or corrupt values retain a partial data verdict even after service recovers.
- Memory mode has RDB/AOF disabled, rdb-del-sync-files=yes to remove replication-created RDB files, and observed absence of value persistence files. Its persistence-recovery event is not applicable and remains absent; its independent persistence dimension is false. AOF modes use the RDB base preamble required by the pinned image's bundled modules plus incremental AOF records. AOF recovery requires actual matching healthy runtime configuration, loading=0 and complete frozen acknowledged-value preservation; this observation establishes no loss-free or power-loss guarantee.
- No workload demand is offered after draining, so absent fault/recovery traffic does not measure zero availability or throughput. Post-validation probes are separate diagnostics and never enter workload metrics or the frozen ledger. Poll intervals follow sample completion; observations are sampled and non-atomic.
- All AOF modes and write policies use six-node quiet runtime preparation followed by exactly three all-shard policy SET/GET warmup writes before baseline starts. Warmup writes are excluded from the workload ledger and metrics; no WAITAOF compatibility command is issued after baseline to alter crash-trial durability.

The JSON report contains effective configuration, environment metadata, raw topology replies, per-operation metrics, validation samples, and lifecycle timestamps. Effective configuration SHA-256: `5f3362a0bdd93bf4a884c5958983a2e641eef0c9e963ba05b2dc59469d6b507f`.
