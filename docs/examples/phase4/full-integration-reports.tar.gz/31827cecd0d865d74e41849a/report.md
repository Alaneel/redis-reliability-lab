# Redis Reliability Lab — primary-failure

Run: `31827cecd0d865d74e41849a`  
Outcome: **recovered**  
Started: 2026-10-11T19:55:10.362428+08:00  
Finished: 2026-10-11T19:55:41.810356+08:00

## Recovery

| Condition | Observed |
|---|---|
| Surviving topology converged | true |
| All-shard client recovery sustained | true |
| Topology and client recovery jointly sustained | true |
| All acknowledged writes verified | true |
| Target process restarted | true |
| Original replication redundancy restored | true |
| Recovery deadline expired | false |
| Cleanup verified | true |


## Managed node lifecycle

Target: replica `node-5` (Redis ID `504bd417ea7751d33ca080a9ca9b758732a95d2a`). Repair: `restart`.

Repair action completed: true. Repair or synchronization deadline expired: false.
Repair action duration: 2430.866 ms.
Stable redundancy first observed 4291.161 ms after repair action completed.

A completed restart or reconnect does not establish topology or replication recovery. Link-up and completed initial synchronization are sampled readiness conditions, not zero lag or durability guarantees.

| Lifecycle observation | Since fault orchestration began, ms |
|---|---:|
| Target failure detected | 1566.206 |
| Replication interruption observed | 536.738 |
| Target reachable after repair | 6179.577 |
| Membership rejoined | 6179.577 |
| Replica link up | 9174.726 |
| Synchronization in progress | unobserved |
| Synchronization complete | 9174.726 |
| Primary full-sync counter increased | 6179.577 |
| Primary partial-sync counter increased | unobserved |
| Replication redundancy sustained | 10458.308 |

Resynchronization evidence: `full_sync_counter_increased`; primary Redis ID `452498b025d5efc281bcea746ddfa7e9b3c07135`. Counters are server-wide primary deltas, not an exact target transfer or byte-loss measurement.

## Independent recovery dimensions

Target observed role: `slave`.

| Independent condition | Observed |
|---|---|
| Target process live | true |
| Cluster membership healthy | true |
| Full usable slot coverage | true |
| All shard leaders available | true |
| Client reads available | true |
| Client writes available | true |
| Acknowledged data verified | true |
| Configured write policy available | true |
| Replication redundancy restored | true |
| Persistence recovery verified | unobserved |

## Timing

Milestones are first sampled observations, not Redis event timestamps. Orchestration includes ownership checks and fault execution. The action-completion column separates that overhead; neither anchor identifies the exact Redis event time. Unobserved milestones remain absent.

Fault action completed 505.459 ms after orchestration began (measured with the monotonic runtime clock).

| Observation | Since orchestration began, ms | Since action completed, ms |
|---|---:|---:|
| Failure flagged in gossip | 1566.21 | 1060.75 |
| Original replica owns failed primary slots | unobserved | unobserved |
| Full usable slot coverage | 536.74 | 31.28 |
| Surviving views converge | 536.74 | 31.28 |
| First all-shard SET/GET probe succeeds | 724.74 | 219.28 |
| Client probes sustain recovery | 2192.91 | 1687.45 |
| Topology and clients sustain recovery | 2192.91 | 1687.45 |

## Workload

| Phase | Attempts | Success rate | Errors | Throughput (ops/s) | Successful p50/p95/p99 (ms) |
|---|---:|---:|---:|---:|---|
| baseline | 425 | 100.00% | 0 | 198.37 | 0.807 / 4.451 / 10.711 |
| fault | 724 | 100.00% | 0 | 193.78 | 0.807 / 5.152 / 15.072 |
| repair | 484 | 100.00% | 0 | 199.09 | 0.847 / 2.602 / 6.263 |
| reconciliation | 898 | 100.00% | 0 | 199.37 | 0.732 / 2.732 / 17.448 |
| post_recovery | 200 | 100.00% | 0 | 199.66 | 0.632 / 1.677 / 3.487 |

Acknowledged writes: 1395. Ambiguous SET outcomes: 0.

Write policy: `set`. Diagnostic stage requests are excluded from logical workload counts.

| Phase | SET acknowledged | SET errors |
|---|---:|---:|
| baseline | 222 | 0 |
| fault | 362 | 0 |
| repair | 243 | 0 |
| reconciliation | 456 | 0 |
| post_recovery | 112 | 0 |

| Phase | Measured path | Count | p50 / p95 / p99, ms |
|---|---|---:|---|
| baseline | Logical write completion | 222 | 0.768 / 4.239 / 11.809 |
| baseline | set | 222 | 0.768 / 3.845 / 11.247 |
| fault | Logical write completion | 362 | 0.807 / 7.993 / 15.825 |
| fault | set | 362 | 0.768 / 7.612 / 15.825 |
| repair | Logical write completion | 243 | 0.890 / 2.869 / 7.250 |
| repair | set | 243 | 0.807 / 2.869 / 6.905 |
| reconciliation | Logical write completion | 456 | 0.732 / 2.869 / 29.841 |
| reconciliation | set | 456 | 0.697 / 2.732 / 29.841 |
| post_recovery | Logical write completion | 112 | 0.664 / 1.761 / 3.845 |
| post_recovery | set | 112 | 0.632 / 1.677 / 3.845 |

| Phase | Successful logical writes | Successful writes/s over phase wall time |
|---|---:|---:|
| baseline | 222 | 103.617 |
| fault | 362 | 96.890 |
| repair | 243 | 99.958 |
| reconciliation | 456 | 101.241 |
| post_recovery | 112 | 111.809 |

Global pacing: offered 2763; started 2731; completed 2731; dropped 32. These counts include all workload phases and exclude validation and probes.

Offered requests are ideal period slots from workload Start until the dispatcher observes Stop or parent cancellation; the first slot occurs after one period. The period is one second divided by the configured aggregate rate, truncated to whole nanoseconds. A central dispatcher offers only the latest due slot over an unbuffered channel; missed slots, busy workers, stopped tokens, and tokens with no eligible operation are dropped, without catch-up requests. Started requests count actual logical workload GET or write executions; a SET+WAIT/WAITAOF write counts once. Completed requests count their terminal logical metrics attempts. After Stop, offered = started + dropped and started = completed. Validation and ordinary/acknowledgement-policy probes are excluded. These global counters are not attributed to phases.

Validation attempted: true; expected: 1395; checked: 1395; missing: 0; corrupt: 0; unreadable: 0; unverified: 0. Validation complete: true.

### Terminal workload errors

| Phase | Error class | Count |
|---|---|---:|

Latencies use 512 bounded geometric histogram buckets, starting at 1 microsecond and increasing by 5%; quantiles are nearest-rank bucket upper bounds. The last bucket covers the remaining duration range. All terminal client attempts, successful attempts, and failed attempts have separate histograms. Throughput is completed attempts divided by phase wall-clock seconds. Operations are attributed to the phase in which they start. Redirect counts include only terminal MOVED/ASK errors; redirects handled by the client are not observable here.

## Measurement methodology

- Fault selection preserves the initial primary and its replica. The destructive target is the selected replica; only strictly owned local Docker resources are affected.
- Replica faults preserve all original slot owners and do not require promotion. down_duration is a minimum hold from successful fault action completion, bounded by the recovery observation budget. Client service, failure gossip and replication interruption are separately sampled.
- Replica network isolation removes its complete bidirectional Docker bridge connectivity while Redis remains running. It is not a selective replication-only partition. Restoration uses the same owned endpoint and unchanged live process identity.
- Administrative endpoint-disconnection evidence is separate from Redis INFO link or connected-replica indicators. A short disconnection can finish before TCP/link failure detection; absent interruption or synchronization-counter milestones remain unobserved and are not invented from the Docker interface state.
- Crash repair starts the same stopped owned container with its bounded disposable data volume. Redis Cluster identity must match the pre-fault identity. Restart changes the process; it does not simulate power loss, host/storage failure or persistence durability.
- The repair deadline covers the restart/reconnect action and subsequent synchronization. Redis's current membership is inspected without issuing CLUSTER REPLICATE or forcing slot ownership. Replica repair preserves original assignments; former-primary repair requires the original replica to retain promoted ownership and the old primary to rejoin as its replica.
- Fresh stability after repair requires all six original identities and endpoints, healthy equal slot maps, exactly one synchronized replica per primary, and all-shard client probes. Historical service recovery remains separate from final redundancy and configured acknowledgement-policy availability.
- Replication link-up and master_sync_in_progress=0 are sampled indicators, not exact zero lag, bytes preserved, or identification of partial versus full resynchronization. Raw replication INFO is retained for inspection; unobserved milestones remain absent.
- Traffic drains before validating every acknowledged immutable SET, including short/error WAIT/WAITAOF outcomes. Ambiguous SET errors remain separate. Cancellation skips unsupported recovery/data claims and still uses fresh bounded restoration and cleanup contexts, including managed volumes.

The JSON report contains effective configuration, environment metadata, raw topology replies, per-operation metrics, validation samples, and lifecycle timestamps. Effective configuration SHA-256: `3b13d98713125809f4730f1041b2d6ad83c5c30c7457042a17d4041038a39eaa`.
