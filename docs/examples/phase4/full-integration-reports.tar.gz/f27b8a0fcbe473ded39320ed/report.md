# Redis Reliability Lab — primary-failure

Run: `f27b8a0fcbe473ded39320ed`  
Outcome: **aborted**  
Started: 2026-10-11T20:03:33.917207+08:00  
Finished: 2026-10-11T20:04:04.084356+08:00

## Recovery

| Condition | Observed |
|---|---|
| Original six-node topology recovered | false |
| Post-validation diagnostic service sustained | false |
| Topology and diagnostic service jointly sustained | false |
| Frozen acknowledged writes verified | false |
| All managed processes restarted | false |
| Original replication redundancy restored | false |
| Restoration deadline expired | false |
| Diagnostic deadline expired | false |
| Cleanup verified | true |


## Frozen-ledger process restart

Configured persistence mode: `aof-always`. Failure model: `sequential SIGKILL of all six Redis processes, same-container restart; host and storage remain running`.

Workload traffic stops and drains before the sequential SIGKILL actions. No workload requests are offered during fault or restart observation; these phases do not measure zero availability or recovery throughput. Read-only frozen-ledger validation precedes separate diagnostic writes.

Frozen acknowledged SETs: 433. Frozen ambiguous SET outcomes: 0.

Restoration deadline expired: false.

| Evidence anchor | Observed time |
|---|---|
| Traffic fully drained | 2026-10-11T20:03:56.807734+08:00 |
| Immutable ledger frozen | 2026-10-11T20:03:56.807899+08:00 |
| All six stopped verified before restart | 2026-10-11T20:03:59.195268+08:00 |
| First restart requested | 2026-10-11T20:04:00.197031+08:00 |
| Restart sequence completed | unobserved |
| Frozen-ledger validation completed | unobserved |
| Post-validation diagnostics requested | unobserved |

Drain to first kill request: 0.198 ms (runtime monotonic clock).

Drain to last kill completion: 1623.845 ms (runtime monotonic clock).

All-stopped barrier to first restart request: 1001.754 ms (runtime monotonic clock).

| Restart observation | Since fault orchestration began, ms |
|---|---:|
| Original six-node replication ready | unobserved |
| Original topology sustained | unobserved |
| Replication redundancy sustained | unobserved |
| Post-validation diagnostic service sustained | unobserved |
| AOF frozen-value recovery observed | unobserved |

AOF frozen-value recovery observed: unobserved. This criterion requires actual loading/configuration evidence and complete frozen-value preservation; restart or topology readiness alone cannot establish it.

Frozen-ledger validation unobserved; 433 acknowledged values remain unchecked.

### Kill action order

| Order | Managed node | Requested | Completed | Error |
|---:|---|---|---|---|
| 1 | node-4 | 2026-10-11T20:03:56.807932+08:00 | 2026-10-11T20:03:57.065895+08:00 |  |
| 2 | node-5 | 2026-10-11T20:03:57.065914+08:00 | 2026-10-11T20:03:57.332503+08:00 |  |
| 3 | node-6 | 2026-10-11T20:03:57.332515+08:00 | 2026-10-11T20:03:57.637551+08:00 |  |
| 4 | node-1 | 2026-10-11T20:03:57.637563+08:00 | 2026-10-11T20:03:57.906119+08:00 |  |
| 5 | node-2 | 2026-10-11T20:03:57.906127+08:00 | 2026-10-11T20:03:58.17236+08:00 |  |
| 6 | node-3 | 2026-10-11T20:03:58.172375+08:00 | 2026-10-11T20:03:58.431594+08:00 |  |

### Restart action order

| Order | Managed node | Requested | Completed | Error |
|---:|---|---|---|---|
| 1 | node-1 | 2026-10-11T20:04:00.197031+08:00 | unobserved | context canceled |

### Stopped administrative observations

| Managed node | Original Redis Cluster ID | Observed | Container running | Restart policy | Status/error |
|---|---|---|---|---|---|
| node-4 | b3a13f045a453217b7f2a116a01943aec923480b | 2026-10-11T20:03:58.567464+08:00 | false | no | managed Redis process is stopped |
| node-5 | 2964d9dd1439da2d67131eeb8fbca6a2d50768c9 | 2026-10-11T20:03:58.694217+08:00 | false | no | managed Redis process is stopped |
| node-6 | dde1dfc637e58c0bddfe4913e084a2a1cfe86c97 | 2026-10-11T20:03:58.819054+08:00 | false | no | managed Redis process is stopped |
| node-1 | a323ca378aea681053113925a05c8aee6ac58175 | 2026-10-11T20:03:58.944236+08:00 | false | no | managed Redis process is stopped |
| node-2 | 29f435c47864f9607ed2b8cf86177196efc5b78f | 2026-10-11T20:03:59.070348+08:00 | false | no | managed Redis process is stopped |
| node-3 | 16e95097748b6fdd5ba5aff32ce8dd98e1f5e384 | 2026-10-11T20:03:59.195239+08:00 | false | no | managed Redis process is stopped |

### Prepared node-1

Original Redis Cluster ID: `a323ca378aea681053113925a05c8aee6ac58175`. Process run ID: `952914c0c2158bd60e92bbcef965253523aaae4e`. Observed: 2026-10-11T20:03:47.329781+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `a323ca378aea681053113925a05c8aee6ac58175`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
no-appendfsync-on-rewrite
no
appendonly
yes
repl-diskless-sync
yes
appendfsync
always
aof-use-rdb-preamble
yes
auto-aof-rewrite-percentage
0
save

rdb-del-sync-files
yes
maxmemory
134217728
maxmemory-policy
noeviction
aof-load-truncated
yes
repl-diskless-load
swapdb
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720217
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:462848
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:0
aof_base_size:0
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Prepared node-2

Original Redis Cluster ID: `29f435c47864f9607ed2b8cf86177196efc5b78f`. Process run ID: `4d03a877cce47c005d442f5ffe5724b1e5c31425`. Observed: 2026-10-11T20:03:48.394491+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `29f435c47864f9607ed2b8cf86177196efc5b78f`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
maxmemory-policy
noeviction
aof-use-rdb-preamble
yes
maxmemory
134217728
repl-diskless-sync
yes
repl-diskless-load
swapdb
aof-load-truncated
yes
auto-aof-rewrite-percentage
0
no-appendfsync-on-rewrite
no
rdb-del-sync-files
yes
save

appendonly
yes
appendfsync
always
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720217
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:561152
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:0
aof_base_size:0
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Prepared node-3

Original Redis Cluster ID: `16e95097748b6fdd5ba5aff32ce8dd98e1f5e384`. Process run ID: `3fcb434b7d110d465ef459de7df95bf171d2992b`. Observed: 2026-10-11T20:03:49.447264+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `16e95097748b6fdd5ba5aff32ce8dd98e1f5e384`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
appendfsync
always
auto-aof-rewrite-percentage
0
maxmemory
134217728
maxmemory-policy
noeviction
appendonly
yes
rdb-del-sync-files
yes
repl-diskless-load
swapdb
save

aof-load-truncated
yes
no-appendfsync-on-rewrite
no
repl-diskless-sync
yes
aof-use-rdb-preamble
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720217
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:479232
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:0
aof_base_size:0
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Prepared node-4

Original Redis Cluster ID: `b3a13f045a453217b7f2a116a01943aec923480b`. Process run ID: `35fc7bd2f7c051ae75abc72d5d2ed39d53b0db47`. Observed: 2026-10-11T20:03:50.496761+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `b3a13f045a453217b7f2a116a01943aec923480b`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
appendonly
yes
rdb-del-sync-files
yes
maxmemory
134217728
aof-load-truncated
yes
repl-diskless-load
swapdb
maxmemory-policy
noeviction
auto-aof-rewrite-percentage
0
no-appendfsync-on-rewrite
no
appendfsync
always
repl-diskless-sync
yes
aof-use-rdb-preamble
yes
save

```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720218
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:389120
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:108
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof

```

### Prepared node-5

Original Redis Cluster ID: `2964d9dd1439da2d67131eeb8fbca6a2d50768c9`. Process run ID: `d9f2ab41e3128f4ae8504b090493dab92c818db3`. Observed: 2026-10-11T20:03:51.565756+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `2964d9dd1439da2d67131eeb8fbca6a2d50768c9`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
rdb-del-sync-files
yes
aof-use-rdb-preamble
yes
appendfsync
always
appendonly
yes
no-appendfsync-on-rewrite
no
maxmemory-policy
noeviction
save

aof-load-truncated
yes
repl-diskless-load
swapdb
repl-diskless-sync
yes
auto-aof-rewrite-percentage
0
maxmemory
134217728
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720218
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:393216
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:108
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof

```

### Prepared node-6

Original Redis Cluster ID: `dde1dfc637e58c0bddfe4913e084a2a1cfe86c97`. Process run ID: `3c5f694272a1355858c6834f855b97fe20c925d2`. Observed: 2026-10-11T20:03:52.642793+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `dde1dfc637e58c0bddfe4913e084a2a1cfe86c97`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
rdb-del-sync-files
yes
appendfsync
always
save

appendonly
yes
maxmemory-policy
noeviction
maxmemory
134217728
aof-use-rdb-preamble
yes
aof-load-truncated
yes
no-appendfsync-on-rewrite
no
repl-diskless-load
swapdb
repl-diskless-sync
yes
auto-aof-rewrite-percentage
0
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720218
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:389120
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:108
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof

```

### Restart receipt 1: node-1

Original Redis Cluster ID: `a323ca378aea681053113925a05c8aee6ac58175`. Observed after restart: 2026-10-11T20:04:01.790671+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `a323ca378aea681053113925a05c8aee6ac58175`. Restart policy: `no`. `/data` usage: 56 KiB.

Observed persistence configuration:

```text
save

aof-load-truncated
yes
maxmemory
134217728
repl-diskless-load
swapdb
auto-aof-rewrite-percentage
0
repl-diskless-sync
yes
appendonly
yes
rdb-del-sync-files
yes
appendfsync
always
maxmemory-policy
noeviction
no-appendfsync-on-rewrite
no
aof-use-rdb-preamble
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:146
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720240
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31952
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=146,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

Post-synchronization administrative runtime observations: unobserved.

This is a sequential process crash and same-container restart with retained managed volumes. It does not remove Docker VM/host page cache or simulate power loss, storage loss, or a graceful shutdown. Draining and sequential kill/inspection time allow background fsync to progress, so everysec preservation does not establish a one-second-loss guarantee or equivalence to always.

Persistence experiment error: restart node-1: context canceled

## Timing

Milestones are first sampled observations, not Redis event timestamps. Orchestration includes ownership checks and fault execution. The action-completion column separates that overhead; neither anchor identifies the exact Redis event time. Unobserved milestones remain absent.

Fault action completed 2387.320 ms after orchestration began (measured with the monotonic runtime clock).

No primary promotion is required. Original owners and replica assignments must remain unchanged across the all-stopped barrier; frozen data and post-validation diagnostics are evaluated separately.

## Workload

| Phase | Attempts | Success rate | Errors | Throughput (ops/s) | Successful p50/p95/p99 (ms) |
|---|---:|---:|---:|---:|---|
| baseline | 829 | 100.00% | 0 | 199.88 | 0.768 / 1.449 / 2.478 |

Acknowledged writes: 433. Ambiguous SET outcomes: 0.

### Before-baseline persistence and command evidence

Persistence preparation contains 6 node observations. Raw CONFIG, INFO and data-file replies are retained in JSON; these observations are separate from frozen-ledger verification.

| Node | Original Redis Cluster ID | Observed at | Observed Redis Cluster ID | Redis PONG | Error |
|---|---|---|---|---|---|
| node-1 | a323ca378aea681053113925a05c8aee6ac58175 | 2026-10-11T20:03:47.329781+08:00 | a323ca378aea681053113925a05c8aee6ac58175 | true |  |
| node-2 | 29f435c47864f9607ed2b8cf86177196efc5b78f | 2026-10-11T20:03:48.394491+08:00 | 29f435c47864f9607ed2b8cf86177196efc5b78f | true |  |
| node-3 | 16e95097748b6fdd5ba5aff32ce8dd98e1f5e384 | 2026-10-11T20:03:49.447264+08:00 | 16e95097748b6fdd5ba5aff32ce8dd98e1f5e384 | true |  |
| node-4 | b3a13f045a453217b7f2a116a01943aec923480b | 2026-10-11T20:03:50.496761+08:00 | b3a13f045a453217b7f2a116a01943aec923480b | true |  |
| node-5 | 2964d9dd1439da2d67131eeb8fbca6a2d50768c9 | 2026-10-11T20:03:51.565756+08:00 | 2964d9dd1439da2d67131eeb8fbca6a2d50768c9 | true |  |
| node-6 | dde1dfc637e58c0bddfe4913e084a2a1cfe86c97 | 2026-10-11T20:03:52.642793+08:00 | dde1dfc637e58c0bddfe4913e084a2a1cfe86c97 | true |  |

Before-baseline `set` policy probe at 2026-10-11T20:03:52.660179+08:00; all shards successful: true.

| Original shard index | SET acknowledged |
|---|---|
| 0 | true |
| 1 | true |
| 2 | true |

Write policy: `set`. Diagnostic stage requests are excluded from logical workload counts.

| Phase | SET acknowledged | SET errors |
|---|---:|---:|
| baseline | 433 | 0 |

| Phase | Measured path | Count | p50 / p95 / p99, ms |
|---|---|---:|---|
| baseline | Logical write completion | 433 | 1.030 / 1.598 / 2.602 |
| baseline | set | 433 | 1.030 / 1.521 / 2.602 |

| Phase | Successful logical writes | Successful writes/s over phase wall time |
|---|---:|---:|
| baseline | 433 | 104.402 |

Global pacing: offered 829; started 829; completed 829; dropped 0. These counts include all workload phases and exclude validation and probes.

Offered requests are ideal period slots from workload Start until the dispatcher observes Stop or parent cancellation; the first slot occurs after one period. The period is one second divided by the configured aggregate rate, truncated to whole nanoseconds. A central dispatcher offers only the latest due slot over an unbuffered channel; missed slots, busy workers, stopped tokens, and tokens with no eligible operation are dropped, without catch-up requests. Started requests count actual logical workload GET or write executions; a SET+WAIT/WAITAOF write counts once. Completed requests count their terminal logical metrics attempts. After Stop, offered = started + dropped and started = completed. Validation and ordinary/acknowledgement-policy probes are excluded. These global counters are not attributed to phases.

Validation attempted: false; expected: 0; checked: 0; missing: 0; corrupt: 0; unreadable: 0; unverified: 0. Validation complete: false.
Validation was not attempted; 433 acknowledged writes remain unchecked.

### Terminal workload errors

| Phase | Error class | Count |
|---|---|---:|

Latencies use 512 bounded geometric histogram buckets, starting at 1 microsecond and increasing by 5%; quantiles are nearest-rank bucket upper bounds. The last bucket covers the remaining duration range. All terminal client attempts, successful attempts, and failed attempts have separate histograms. Throughput is completed attempts divided by phase wall-clock seconds. Operations are attributed to the phase in which they start. Redirect counts include only terminal MOVED/ASK errors; redirects handled by the client are not observable here.

## Errors

- restart node-1: context canceled

## Measurement methodology

- Quiet administrative process, CONFIG, persistence INFO, keyspace and bounded data-file preparation occurs before baseline traffic; it issues no SAVE, BGSAVE, BGREWRITEAOF or explicit durability barrier.
- The workload fully stops and joins in-flight acknowledgements before freezing its immutable ledger and counters. All later topology observations are read-only until every frozen acknowledged value has been checked. SET-error outcomes remain ambiguous, excluded from acknowledgement guarantees.
- Original replicas are SIGKILLed before original primaries. Every fixed owned container must produce ErrProcessStopped administrative evidence with restart policy no before any restart. Original primaries restart before replicas in the same containers and retained volumes; original Redis Cluster identities and slot ownership must survive.
- The model is sequential process SIGKILL while Docker VM, host and storage remain running, followed by same-container starts. It does not simulate power loss, host/page-cache loss or disk loss. Drain, kill and inspection intervals are reported because they permit background fsync progress.
- Topology restoration requires all six original identities, endpoints, primary slot owners and replica assignments synchronized for stable_for, without forced Redis topology commands. Physical receipts retain early raw evidence, which can be transient during full sync. Six fresh quiet administrative runtime/configuration/file observations after topology stability prove the final persistence mode on those same restarted processes, within the shared repair budget and before frozen-value validation. Samples crossing restoration or diagnostic deadlines are retained but excluded from successful milestones.
- Frozen-ledger GET validation happens exactly once before diagnostic SET/GET or configured replica-acknowledgement probes. Process/slot readiness and later diagnostic service are independent from frozen-value preservation; missing or corrupt values retain a partial data verdict even after service recovers.
- Memory mode has RDB/AOF disabled, rdb-del-sync-files=yes to remove replication-created RDB files, and observed absence of value persistence files. Its persistence-recovery event is not applicable and remains absent; its independent persistence dimension is false. AOF modes use the RDB base preamble required by the pinned image's bundled modules plus incremental AOF records. AOF recovery requires actual matching healthy runtime configuration, loading=0 and complete frozen acknowledged-value preservation; this observation establishes no loss-free or power-loss guarantee.
- No workload demand is offered after draining, so absent fault/recovery traffic does not measure zero availability or throughput. Post-validation probes are separate diagnostics and never enter workload metrics or the frozen ledger. Poll intervals follow sample completion; observations are sampled and non-atomic.
- All AOF modes and write policies use six-node quiet runtime preparation followed by exactly three all-shard policy SET/GET warmup writes before baseline starts. Warmup writes are excluded from the workload ledger and metrics; no WAITAOF compatibility command is issued after baseline to alter crash-trial durability.

The JSON report contains effective configuration, environment metadata, raw topology replies, per-operation metrics, validation samples, and lifecycle timestamps. Effective configuration SHA-256: `5f3362a0bdd93bf4a884c5958983a2e641eef0c9e963ba05b2dc59469d6b507f`.
