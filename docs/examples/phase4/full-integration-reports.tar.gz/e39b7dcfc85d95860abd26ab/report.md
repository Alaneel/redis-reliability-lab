# Redis Reliability Lab — primary-network-isolation

Run: `e39b7dcfc85d95860abd26ab`  
Outcome: **recovered**  
Started: 2026-10-11T19:57:57.738782+08:00  
Finished: 2026-10-11T19:58:33.283501+08:00

## Recovery

| Condition | Observed |
|---|---|
| Surviving topology converged | true |
| All-shard client recovery sustained | true |
| Topology and client recovery jointly sustained | true |
| All acknowledged writes verified | true |
| Target process restarted | false |
| Original replication redundancy restored | true |
| Recovery deadline expired | false |
| Cleanup verified | true |

The primary remains running during whole-node bidirectional network isolation. Connectivity restoration, topology reconciliation and replication redundancy are evaluated separately. Redis replication is asynchronous; acknowledged SETs are not durability guarantees.

## Network restoration

| Condition | Observed |
|---|---|
| Original endpoints and process restored | true |
| Topology and clients jointly reconciled | true |
| Reconciliation deadline expired | false |

Restoration action duration: 1324.160 ms.
Stable reconciliation first observed 5719.651 ms after restoration completed.

| Process probe time | Redis PONG | Container running | Network attached | Container PID | Redis run ID | Error |
|---|---|---|---|---:|---|---|
| 2026-10-11T19:58:13.285306+08:00 | true | true | false | 87747 | dceb8a1a96a99dad30bfbfb6a2c64c03e2eefc15 |  |
| 2026-10-11T19:58:15.931872+08:00 | true | true | false | 87747 | dceb8a1a96a99dad30bfbfb6a2c64c03e2eefc15 |  |
| 2026-10-11T19:58:18.472683+08:00 | true | true | false | 87747 | dceb8a1a96a99dad30bfbfb6a2c64c03e2eefc15 |  |
| 2026-10-11T19:58:21.04723+08:00 | true | true | false | 87747 | dceb8a1a96a99dad30bfbfb6a2c64c03e2eefc15 |  |
| 2026-10-11T19:58:29.130299+08:00 | true | true | true | 87747 | dceb8a1a96a99dad30bfbfb6a2c64c03e2eefc15 |  |

## Timing

Milestones are first sampled observations, not Redis event timestamps. Orchestration includes ownership checks and fault execution. The action-completion column separates that overhead; neither anchor identifies the exact Redis event time. Unobserved milestones remain absent.

Fault action completed 1527.458 ms after orchestration began (measured with the monotonic runtime clock).

| Observation | Since orchestration began, ms | Since action completed, ms |
|---|---:|---:|
| Failure flagged in gossip | 2048.45 | 520.99 |
| Original replica owns failed primary slots | 3705.57 | 2178.11 |
| Full usable slot coverage | 3705.57 | 2178.11 |
| Surviving views converge | 3705.57 | 2178.11 |
| First all-shard SET/GET probe succeeds | 3954.90 | 2427.44 |
| Client probes sustain recovery | 5150.13 | 3622.68 |
| Topology and clients sustain recovery | 5150.13 | 3622.68 |

## Workload

| Phase | Attempts | Success rate | Errors | Throughput (ops/s) | Successful p50/p95/p99 (ms) |
|---|---:|---:|---:|---:|---|
| baseline | 420 | 100.00% | 0 | 199.66 | 0.602 / 1.849 / 4.239 |
| fault | 1959 | 95.30% | 92 | 170.89 | 0.546 / 1.081 / 3.163 |
| reconciliation | 1284 | 100.00% | 0 | 199.97 | 0.495 / 0.768 / 1.314 |
| post_recovery | 400 | 100.00% | 0 | 199.96 | 0.520 / 0.847 / 2.732 |

Acknowledged writes: 2010. Ambiguous SET outcomes: 54.

Write policy: `set`. Diagnostic stage requests are excluded from logical workload counts.

| Phase | SET acknowledged | SET errors |
|---|---:|---:|
| baseline | 221 | 0 |
| fault | 928 | 54 |
| reconciliation | 648 | 0 |
| post_recovery | 213 | 0 |

| Phase | Measured path | Count | p50 / p95 / p99, ms |
|---|---|---:|---|
| baseline | Logical write completion | 221 | 0.632 / 2.248 / 4.037 |
| baseline | set | 221 | 0.602 / 2.248 / 4.037 |
| fault | Logical write completion | 982 | 0.573 / 1.081 / 2.039 |
| fault | set | 982 | 0.546 / 1.030 / 1.849 |
| reconciliation | Logical write completion | 648 | 0.520 / 0.807 / 1.677 |
| reconciliation | set | 648 | 0.495 / 0.807 / 1.314 |
| post_recovery | Logical write completion | 213 | 0.546 / 0.890 / 1.521 |
| post_recovery | set | 213 | 0.546 / 0.890 / 1.449 |

| Phase | Successful logical writes | Successful writes/s over phase wall time |
|---|---:|---:|
| baseline | 221 | 105.062 |
| fault | 928 | 80.953 |
| reconciliation | 648 | 100.918 |
| post_recovery | 213 | 106.480 |

Global pacing: offered 4397; started 4063; completed 4063; dropped 334. These counts include all workload phases and exclude validation and probes.

Offered requests are ideal period slots from workload Start until the dispatcher observes Stop or parent cancellation; the first slot occurs after one period. The period is one second divided by the configured aggregate rate, truncated to whole nanoseconds. A central dispatcher offers only the latest due slot over an unbuffered channel; missed slots, busy workers, stopped tokens, and tokens with no eligible operation are dropped, without catch-up requests. Started requests count actual logical workload GET or write executions; a SET+WAIT/WAITAOF write counts once. Completed requests count their terminal logical metrics attempts. After Stop, offered = started + dropped and started = completed. Validation and ordinary/acknowledgement-policy probes are excluded. These global counters are not attributed to phases.

Validation attempted: true; expected: 2010; checked: 2010; missing: 0; corrupt: 0; unreadable: 0; unverified: 0. Validation complete: true.

### Terminal workload errors

| Phase | Error class | Count |
|---|---|---:|
| fault | CLUSTERDOWN | 7 |
| fault | network | 47 |
| fault | timeout | 38 |

Latencies use 512 bounded geometric histogram buckets, starting at 1 microsecond and increasing by 5%; quantiles are nearest-rank bucket upper bounds. The last bucket covers the remaining duration range. All terminal client attempts, successful attempts, and failed attempts have separate histograms. Throughput is completed attempts divided by phase wall-clock seconds. Operations are attributed to the phase in which they start. Redirect counts include only terminal MOVED/ASK errors; redirects handled by the client are not observable here.

## Measurement methodology

- Fault is a complete bidirectional Docker bridge disconnection of the deterministic primary owning the lowest initial slot. Redis remains running. All peer and published client connectivity is removed; this is not a selective or one-way partition.
- The orchestration and action-completion anchors are recorded separately using monotonic runtime durations. isolation_duration is a minimum hold from successful action completion, bounded by the recovery deadline; samples and bounded process probes can extend the hold. Actual restoration timestamps record the observed duration.
- During isolation, recovery requires the five surviving nodes to converge on healthy usable slot ownership, the original replica to own the selected primary slots, unchanged unaffected ownership, and successful all-shard SET/GET probes over stable_for. A stable milestone is retained while observation continues until restoration.
- Docker exec runs fixed Redis liveness and topology commands independent of the disconnected data plane. PONG and unchanged container PID, start time and Redis run ID prove sampled process survival, not cluster health. Isolation success requires at least one such disconnected observation.
- Restoration reconnects only the same owned node to the same owned network with its original private IP and loopback port. Process identity and endpoint identity must remain unchanged. Cancellation uses a fresh bounded restoration attempt before independent cleanup; safe cleanup can directly remove an owned detached node.
- After restoration, fresh stability tracking requires all six original identities and endpoints, three healthy primaries with synchronized replicas, the promoted replica retaining shard ownership, former-primary demotion, unchanged unaffected shards, and all-shard client probes. Service recovery, connectivity restoration and replication redundancy have separate evidence.
- Poll intervals are delays after sample completion; concurrent views are not atomic snapshots. Probes do not prove continuous availability. Workload metrics include terminal client errors separately from probe results. At most 1200 topology samples and 64 process samples are retained.
- Traffic drains before validating every successfully acknowledged immutable SET. Missing, corrupt, unreadable or unverified records prevent full recovery. Error-returning SET outcomes remain ambiguous. No client can write to the disconnected minority, so this experiment does not exercise minority-side write conflicts or establish loss-free asynchronous replication.

The JSON report contains effective configuration, environment metadata, raw topology replies, per-operation metrics, validation samples, and lifecycle timestamps. Effective configuration SHA-256: `632fd6e15ee31c12f6294b809b225cb4d117eaea1fe7b85670572de0d8bed374`.
