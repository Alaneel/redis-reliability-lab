# Redis Reliability Lab — waitaof-primary-repair

Run: `1a239cb87f2df1de0022e821`  
Outcome: **recovered**  
Started: 2026-10-11T20:04:53.694675+08:00  
Finished: 2026-10-11T20:05:32.467585+08:00

## Recovery

| Condition | Observed |
|---|---|
| Surviving topology converged | true |
| All-shard client recovery sustained | true |
| Topology and client recovery jointly sustained | true |
| All acknowledged writes verified | true |
| Target process restarted | true |
| Original replication redundancy restored | true |
| Recovery deadline expired | false |
| Cleanup verified | true |


## Managed node lifecycle

Target: primary `node-1` (Redis ID `6a0f598d3a12d7ae0931d88eea12585f06aca637`). Repair: `restart`.

Repair action completed: true. Repair or synchronization deadline expired: false.
Repair action duration: 1635.483 ms.
Stable redundancy first observed 5245.602 ms after repair action completed.

A completed restart or reconnect does not establish topology or replication recovery. Link-up and completed initial synchronization are sampled readiness conditions, not zero lag or durability guarantees.

| Lifecycle observation | Since fault orchestration began, ms |
|---|---:|
| Target failure detected | 2026.652 |
| Replication interruption observed | 2901.488 |
| Target reachable after repair | 6256.664 |
| Membership rejoined | 6256.664 |
| Replica link up | 10251.050 |
| Synchronization in progress | unobserved |
| Synchronization complete | 10251.050 |
| Primary full-sync counter increased | 6256.664 |
| Primary partial-sync counter increased | unobserved |
| Replication redundancy sustained | 11492.169 |

Resynchronization evidence: `full_sync_counter_increased`; primary Redis ID `8accf743d1b9e14171ce502c3ef69504b1ce7e3e`. Counters are server-wide primary deltas, not an exact target transfer or byte-loss measurement.

## Independent recovery dimensions

Target observed role: `slave`.

| Independent condition | Observed |
|---|---|
| Target process live | true |
| Cluster membership healthy | true |
| Full usable slot coverage | true |
| All shard leaders available | true |
| Client reads available | true |
| Client writes available | true |
| Acknowledged data verified | true |
| Configured write policy available | true |
| Replication redundancy restored | true |
| Persistence recovery verified | unobserved |

## Timing

Milestones are first sampled observations, not Redis event timestamps. Orchestration includes ownership checks and fault execution. The action-completion column separates that overhead; neither anchor identifies the exact Redis event time. Unobserved milestones remain absent.

Fault action completed 261.391 ms after orchestration began (measured with the monotonic runtime clock).

| Observation | Since orchestration began, ms | Since action completed, ms |
|---|---:|---:|
| Failure flagged in gossip | 2026.65 | 1765.26 |
| Original replica owns failed primary slots | 2901.49 | 2640.10 |
| Full usable slot coverage | 2901.49 | 2640.10 |
| Surviving views converge | 2901.49 | 2640.10 |
| First all-shard SET/GET probe succeeds | 3031.91 | 2770.52 |
| Client probes sustain recovery | 4473.18 | 4211.79 |
| Topology and clients sustain recovery | 4473.18 | 4211.79 |

## Workload

| Phase | Attempts | Success rate | Errors | Throughput (ops/s) | Successful p50/p95/p99 (ms) |
|---|---:|---:|---:|---:|---|
| baseline | 820 | 100.00% | 0 | 199.97 | 1.252 / 2.732 / 3.487 |
| fault | 534 | 75.84% | 129 | 115.81 | 0.602 / 3.163 / 48.608 |
| repair | 327 | 82.87% | 56 | 199.93 | 0.664 / 2.869 / 3.845 |
| reconciliation | 1089 | 89.07% | 119 | 199.95 | 0.546 / 2.478 / 4.239 |
| post_recovery | 400 | 100.00% | 0 | 199.95 | 0.495 / 2.732 / 3.662 |

Acknowledged writes: 1581. Ambiguous SET outcomes: 32.

### Before-baseline persistence and command evidence

Persistence preparation contains 6 node observations. Raw CONFIG, INFO and data-file replies are retained in JSON; these observations are separate from frozen-ledger verification.

| Node | Original Redis Cluster ID | Observed at | Observed Redis Cluster ID | Redis PONG | Error |
|---|---|---|---|---|---|
| node-1 | 6a0f598d3a12d7ae0931d88eea12585f06aca637 | 2026-10-11T20:05:06.190957+08:00 | 6a0f598d3a12d7ae0931d88eea12585f06aca637 | true |  |
| node-2 | 024f4dfceb62316c7bb7e9441446cdaea7e68e86 | 2026-10-11T20:05:07.248081+08:00 | 024f4dfceb62316c7bb7e9441446cdaea7e68e86 | true |  |
| node-3 | 223fd6e5ff852b41d8d15e3bd5aab17e98f3c38d | 2026-10-11T20:05:08.303079+08:00 | 223fd6e5ff852b41d8d15e3bd5aab17e98f3c38d | true |  |
| node-4 | cecd2e7b937ba0e0823ec1637e7dad7f820cc91d | 2026-10-11T20:05:09.354675+08:00 | cecd2e7b937ba0e0823ec1637e7dad7f820cc91d | true |  |
| node-5 | 8accf743d1b9e14171ce502c3ef69504b1ce7e3e | 2026-10-11T20:05:10.430186+08:00 | 8accf743d1b9e14171ce502c3ef69504b1ce7e3e | true |  |
| node-6 | 078970283daaa370b5231e37d1300bc8d10b1eb3 | 2026-10-11T20:05:11.486985+08:00 | 078970283daaa370b5231e37d1300bc8d10b1eb3 | true |  |

Before-baseline `waitaof` policy probe at 2026-10-11T20:05:11.505354+08:00; all shards successful: true.
requested local/replica AOF counts: 1/1.

| Original shard index | SET acknowledged | WAITAOF attempted | Local / replica AOF reply |
|---|---|---|---|
| 0 | true | true | 1/1 |
| 1 | true | true | 1/1 |
| 2 | true | true | 1/1 |

Write policy: `waitaof`. Diagnostic stage requests are excluded from logical workload counts.
Logical write latency includes SET and WAITAOF on the same physical connection. WAITAOF policy success requires both requested local and replica AOF acknowledgement counts. These disk acknowledgements are separate from WAIT replica-memory acknowledgements; they do not establish strong consistency or a power-loss guarantee from this process-crash experiment.

| Phase | SET acknowledged | SET errors | WAITAOF attempted | Both satisfied | Short pair | Command errors | Client timeouts | Local satisfied | Replica satisfied |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| baseline | 425 | 0 | 425 | 425 | 0 | 0 | 0 | 425 | 425 |
| fault | 225 | 32 | 225 | 168 | 57 | 0 | 0 | 225 | 168 |
| repair | 168 | 0 | 168 | 112 | 56 | 0 | 0 | 168 | 112 |
| reconciliation | 575 | 0 | 575 | 456 | 119 | 0 | 0 | 575 | 456 |
| post_recovery | 188 | 0 | 188 | 188 | 0 | 0 | 0 | 188 | 188 |

WAITAOF reply distribution preserves the local/replica pair. Only valid two-integer replies are counted; command errors and unattempted calls have no observed pair. `0/0` is an observed short reply. Local/replica satisfied counts can overlap and must not be added.

| Phase | Local / replica AOF acknowledgements | Replies |
|---|---|---:|
| baseline | 1/1 | 425 |
| fault | 1/0 | 57 |
| fault | 1/1 | 168 |
| repair | 1/0 | 56 |
| repair | 1/1 | 112 |
| reconciliation | 1/0 | 119 |
| reconciliation | 1/1 | 456 |
| post_recovery | 1/1 | 188 |

| Phase | Measured path | Count | p50 / p95 / p99, ms |
|---|---|---:|---|
| baseline | Logical write completion | 425 | 1.677 / 3.012 / 4.673 |
| baseline | set | 425 | 0.981 / 1.677 / 3.163 |
| baseline | waitaof | 425 | 0.602 / 1.849 / 2.039 |
| fault | Logical write completion | 257 | 1.849 / 116.982 / 122.831 |
| fault | set | 257 | 0.981 / 2.039 / 3.321 |
| fault | waitaof | 225 | 0.732 / 116.982 / 122.831 |
| repair | Logical write completion | 168 | 2.141 / 122.831 / 140.470 |
| repair | set | 168 | 1.081 / 2.141 / 3.012 |
| repair | waitaof | 168 | 0.732 / 122.831 / 136.608 |
| reconciliation | Logical write completion | 575 | 1.598 / 116.982 / 135.421 |
| reconciliation | set | 575 | 0.934 / 1.380 / 2.869 |
| reconciliation | waitaof | 575 | 0.602 / 116.982 / 135.421 |
| post_recovery | Logical write completion | 188 | 1.449 / 3.163 / 6.263 |
| post_recovery | set | 188 | 0.847 / 1.314 / 2.732 |
| post_recovery | waitaof | 188 | 0.573 / 2.141 / 2.360 |

| Phase | Successful logical writes | Successful writes/s over phase wall time |
|---|---:|---:|
| baseline | 425 | 103.641 |
| fault | 168 | 36.434 |
| repair | 112 | 68.478 |
| reconciliation | 456 | 83.727 |
| post_recovery | 188 | 93.979 |

SET acknowledgements without a subsequent WAITAOF attempt: 0; client timeouts among those: 0. WAITAOF command errors and WAITAOF client timeouts above count attempted WAITAOF client calls only. A short integer pair is separate from a client timeout.

Configured write policy recovered for the stable interval: true. This criterion is independent of ordinary SET/GET service recovery.

Global pacing: offered 3558; started 3170; completed 3170; dropped 388. These counts include all workload phases and exclude validation and probes.

Offered requests are ideal period slots from workload Start until the dispatcher observes Stop or parent cancellation; the first slot occurs after one period. The period is one second divided by the configured aggregate rate, truncated to whole nanoseconds. A central dispatcher offers only the latest due slot over an unbuffered channel; missed slots, busy workers, stopped tokens, and tokens with no eligible operation are dropped, without catch-up requests. Started requests count actual logical workload GET or write executions; a SET+WAIT/WAITAOF write counts once. Completed requests count their terminal logical metrics attempts. After Stop, offered = started + dropped and started = completed. Validation and ordinary/acknowledgement-policy probes are excluded. These global counters are not attributed to phases.

Validation attempted: true; expected: 1581; checked: 1581; missing: 0; corrupt: 0; unreadable: 0; unverified: 0. Validation complete: true.

WAITAOF-satisfied subset: expected 1349; checked 1349; missing 0; corrupt 0; unreadable 0; unverified 0; complete true. The main ledger also includes every successful SET followed by incomplete WAITAOF.

### Terminal workload errors

| Phase | Error class | Count |
|---|---|---:|
| fault | CLUSTERDOWN | 9 |
| fault | network | 23 |
| fault | timeout | 40 |
| fault | waitaof_short | 57 |
| reconciliation | waitaof_short | 119 |
| repair | waitaof_short | 56 |

Latencies use 512 bounded geometric histogram buckets, starting at 1 microsecond and increasing by 5%; quantiles are nearest-rank bucket upper bounds. The last bucket covers the remaining duration range. All terminal client attempts, successful attempts, and failed attempts have separate histograms. Throughput is completed attempts divided by phase wall-clock seconds. Operations are attributed to the phase in which they start. Redirect counts include only terminal MOVED/ASK errors; redirects handled by the client are not observable here.

## Measurement methodology

- Fault selection preserves the initial primary and its replica. The destructive target is the selected primary after stable five-survivor service recovery; only strictly owned local Docker resources are affected.
- Replica faults preserve all original slot owners and do not require promotion. down_duration is a minimum hold from successful fault action completion, bounded by the recovery observation budget. Client service, failure gossip and replication interruption are separately sampled.
- Replica network isolation removes its complete bidirectional Docker bridge connectivity while Redis remains running. It is not a selective replication-only partition. Restoration uses the same owned endpoint and unchanged live process identity.
- Administrative endpoint-disconnection evidence is separate from Redis INFO link or connected-replica indicators. A short disconnection can finish before TCP/link failure detection; absent interruption or synchronization-counter milestones remain unobserved and are not invented from the Docker interface state.
- Crash repair starts the same stopped owned container with its bounded disposable data volume. Redis Cluster identity must match the pre-fault identity. Restart changes the process; it does not simulate power loss, host/storage failure or persistence durability.
- The repair deadline covers the restart/reconnect action and subsequent synchronization. Redis's current membership is inspected without issuing CLUSTER REPLICATE or forcing slot ownership. Replica repair preserves original assignments; former-primary repair requires the original replica to retain promoted ownership and the old primary to rejoin as its replica.
- Fresh stability after repair requires all six original identities and endpoints, healthy equal slot maps, exactly one synchronized replica per primary, and all-shard client probes. Historical service recovery remains separate from final redundancy and configured acknowledgement-policy availability.
- Replication link-up and master_sync_in_progress=0 are sampled indicators, not exact zero lag, bytes preserved, or identification of partial versus full resynchronization. Raw replication INFO is retained for inspection; unobserved milestones remain absent.
- Traffic drains before validating every acknowledged immutable SET, including short/error WAIT/WAITAOF outcomes. Ambiguous SET errors remain separate. Cancellation skips unsupported recovery/data claims and still uses fresh bounded restoration and cleanup contexts, including managed volumes.
- All AOF modes and write policies use six-node quiet runtime preparation followed by exactly three all-shard policy SET/GET warmup writes before baseline starts. Warmup writes are excluded from the workload ledger and metrics; no WAITAOF compatibility command is issued after baseline to alter crash-trial durability.
- Configured acknowledgement policy is a separate current condition, measured through all-three-shard SET plus WAIT/WAITAOF on one physical connection. A stable policy milestone is historical; a later unsuccessful probe resets the current condition.

The JSON report contains effective configuration, environment metadata, raw topology replies, per-operation metrics, validation samples, and lifecycle timestamps. Effective configuration SHA-256: `16129c715b8bb4fc8500deba1798c58bd23396c979bcde66e1e1b094f4492a76`.
