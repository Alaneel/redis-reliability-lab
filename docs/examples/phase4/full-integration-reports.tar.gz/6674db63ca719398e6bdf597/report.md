# Redis Reliability Lab — waitaof-frozen-persistence

Run: `6674db63ca719398e6bdf597`  
Outcome: **recovered**  
Started: 2026-10-11T20:05:33.853781+08:00  
Finished: 2026-10-11T20:06:28.384157+08:00

## Recovery

| Condition | Observed |
|---|---|
| Original six-node topology recovered | true |
| Post-validation diagnostic service sustained | true |
| Topology and diagnostic service jointly sustained | true |
| Frozen acknowledged writes verified | true |
| All managed processes restarted | true |
| Original replication redundancy restored | true |
| Restoration deadline expired | false |
| Diagnostic deadline expired | false |
| Cleanup verified | true |


## Frozen-ledger process restart

Configured persistence mode: `aof-always`. Failure model: `sequential SIGKILL of all six Redis processes, same-container restart; host and storage remain running`.

Workload traffic stops and drains before the sequential SIGKILL actions. No workload requests are offered during fault or restart observation; these phases do not measure zero availability or recovery throughput. Read-only frozen-ledger validation precedes separate diagnostic writes.

Frozen acknowledged SETs: 432. Frozen ambiguous SET outcomes: 0.

Restoration deadline expired: false.

| Evidence anchor | Observed time |
|---|---|
| Traffic fully drained | 2026-10-11T20:05:56.75187+08:00 |
| Immutable ledger frozen | 2026-10-11T20:05:56.752118+08:00 |
| All six stopped verified before restart | 2026-10-11T20:05:59.105902+08:00 |
| First restart requested | 2026-10-11T20:06:00.107134+08:00 |
| Restart sequence completed | 2026-10-11T20:06:10.215887+08:00 |
| Frozen-ledger validation completed | 2026-10-11T20:06:21.488071+08:00 |
| Post-validation diagnostics requested | 2026-10-11T20:06:21.488398+08:00 |

Drain to first kill request: 0.292 ms (runtime monotonic clock).

Drain to last kill completion: 1573.492 ms (runtime monotonic clock).

All-stopped barrier to first restart request: 1001.223 ms (runtime monotonic clock).

| Restart observation | Since fault orchestration began, ms |
|---|---:|
| Original six-node replication ready | 16474.728 |
| Original topology sustained | 17958.820 |
| Replication redundancy sustained | 17958.820 |
| Post-validation diagnostic service sustained | 26222.456 |
| AOF frozen-value recovery observed | 24735.695 |

AOF frozen-value recovery observed: true. This criterion requires actual loading/configuration evidence and complete frozen-value preservation; restart or topology readiness alone cannot establish it.

Frozen-ledger validation: expected 432; checked 432; missing 0; corrupt 0; unreadable 0; unverified 0; complete true. Completion describes verification coverage; observed loss remains a data failure.

### Kill action order

| Order | Managed node | Requested | Completed | Error |
|---:|---|---|---|---|
| 1 | node-4 | 2026-10-11T20:05:56.752163+08:00 | 2026-10-11T20:05:57.010409+08:00 |  |
| 2 | node-5 | 2026-10-11T20:05:57.010423+08:00 | 2026-10-11T20:05:57.29156+08:00 |  |
| 3 | node-6 | 2026-10-11T20:05:57.291576+08:00 | 2026-10-11T20:05:57.541247+08:00 |  |
| 4 | node-1 | 2026-10-11T20:05:57.541262+08:00 | 2026-10-11T20:05:57.806578+08:00 |  |
| 5 | node-2 | 2026-10-11T20:05:57.806585+08:00 | 2026-10-11T20:05:58.074055+08:00 |  |
| 6 | node-3 | 2026-10-11T20:05:58.074069+08:00 | 2026-10-11T20:05:58.325376+08:00 |  |

### Restart action order

| Order | Managed node | Requested | Completed | Error |
|---:|---|---|---|---|
| 1 | node-1 | 2026-10-11T20:06:00.107134+08:00 | 2026-10-11T20:06:01.784282+08:00 |  |
| 2 | node-2 | 2026-10-11T20:06:01.784286+08:00 | 2026-10-11T20:06:03.470541+08:00 |  |
| 3 | node-3 | 2026-10-11T20:06:03.470553+08:00 | 2026-10-11T20:06:05.159547+08:00 |  |
| 4 | node-4 | 2026-10-11T20:06:05.159558+08:00 | 2026-10-11T20:06:06.837312+08:00 |  |
| 5 | node-5 | 2026-10-11T20:06:06.837315+08:00 | 2026-10-11T20:06:08.533675+08:00 |  |
| 6 | node-6 | 2026-10-11T20:06:08.533684+08:00 | 2026-10-11T20:06:10.215884+08:00 |  |

### Stopped administrative observations

| Managed node | Original Redis Cluster ID | Observed | Container running | Restart policy | Status/error |
|---|---|---|---|---|---|
| node-4 | 250fcb00f3f0bb5e8118a94d52d58dccc95c8199 | 2026-10-11T20:05:58.462568+08:00 | false | no | managed Redis process is stopped |
| node-5 | a55997ddbd75bd8507dbcb6fd8beef52b065ed34 | 2026-10-11T20:05:58.589372+08:00 | false | no | managed Redis process is stopped |
| node-6 | dc941b40a52d0be8c9609bf352f5b84ba54f2288 | 2026-10-11T20:05:58.718806+08:00 | false | no | managed Redis process is stopped |
| node-1 | b6f3a1f5ac46872d158717c86ea72f3dff60d90b | 2026-10-11T20:05:58.846551+08:00 | false | no | managed Redis process is stopped |
| node-2 | 65bc92f93ea1ddfba0d19488791099f44898be55 | 2026-10-11T20:05:58.976039+08:00 | false | no | managed Redis process is stopped |
| node-3 | b90d4b8da3ff155e601e06d78cf30e4f0dbf3a7b | 2026-10-11T20:05:59.105861+08:00 | false | no | managed Redis process is stopped |

### Prepared node-1

Original Redis Cluster ID: `b6f3a1f5ac46872d158717c86ea72f3dff60d90b`. Process run ID: `3d8a09b615b3a7e7b3dbcd006d5810981e0f2af0`. Observed: 2026-10-11T20:05:47.187824+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `b6f3a1f5ac46872d158717c86ea72f3dff60d90b`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
maxmemory
134217728
repl-diskless-load
swapdb
maxmemory-policy
noeviction
aof-use-rdb-preamble
yes
repl-diskless-sync
yes
appendonly
yes
auto-aof-rewrite-percentage
0
rdb-del-sync-files
yes
no-appendfsync-on-rewrite
no
appendfsync
always
aof-load-truncated
yes
save

```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720336
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:552960
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:0
aof_base_size:0
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Prepared node-2

Original Redis Cluster ID: `65bc92f93ea1ddfba0d19488791099f44898be55`. Process run ID: `bb17a3065e0e6bf2c1774728c2c0b247afd1f66b`. Observed: 2026-10-11T20:05:48.237349+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `65bc92f93ea1ddfba0d19488791099f44898be55`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
auto-aof-rewrite-percentage
0
repl-diskless-load
swapdb
save

repl-diskless-sync
yes
maxmemory
134217728
appendfsync
always
appendonly
yes
maxmemory-policy
noeviction
rdb-del-sync-files
yes
no-appendfsync-on-rewrite
no
aof-load-truncated
yes
aof-use-rdb-preamble
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720337
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:450560
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:0
aof_base_size:0
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Prepared node-3

Original Redis Cluster ID: `b90d4b8da3ff155e601e06d78cf30e4f0dbf3a7b`. Process run ID: `8045820520ee281e7a70d96ec89725deee3992d6`. Observed: 2026-10-11T20:05:49.296103+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `b90d4b8da3ff155e601e06d78cf30e4f0dbf3a7b`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
rdb-del-sync-files
yes
auto-aof-rewrite-percentage
0
no-appendfsync-on-rewrite
no
repl-diskless-load
swapdb
save

appendonly
yes
repl-diskless-sync
yes
maxmemory
134217728
aof-load-truncated
yes
appendfsync
always
maxmemory-policy
noeviction
aof-use-rdb-preamble
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720337
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:471040
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:0
aof_base_size:0
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Prepared node-4

Original Redis Cluster ID: `250fcb00f3f0bb5e8118a94d52d58dccc95c8199`. Process run ID: `7230286de3594dfad8d729c3b1bca75f0e5fd3cb`. Observed: 2026-10-11T20:05:50.38134+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `250fcb00f3f0bb5e8118a94d52d58dccc95c8199`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
repl-diskless-sync
yes
auto-aof-rewrite-percentage
0
maxmemory
134217728
maxmemory-policy
noeviction
rdb-del-sync-files
yes
appendonly
yes
aof-load-truncated
yes
no-appendfsync-on-rewrite
no
repl-diskless-load
swapdb
aof-use-rdb-preamble
yes
appendfsync
always
save

```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720337
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:385024
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:108
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof

```

### Prepared node-5

Original Redis Cluster ID: `a55997ddbd75bd8507dbcb6fd8beef52b065ed34`. Process run ID: `95377c8567c06a607314083f7d84680ef542bc8f`. Observed: 2026-10-11T20:05:51.502717+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `a55997ddbd75bd8507dbcb6fd8beef52b065ed34`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
repl-diskless-load
swapdb
maxmemory
134217728
aof-load-truncated
yes
repl-diskless-sync
yes
rdb-del-sync-files
yes
no-appendfsync-on-rewrite
no
auto-aof-rewrite-percentage
0
appendfsync
always
aof-use-rdb-preamble
yes
appendonly
yes
save

maxmemory-policy
noeviction
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720338
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:393216
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:108
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof

```

### Prepared node-6

Original Redis Cluster ID: `dc941b40a52d0be8c9609bf352f5b84ba54f2288`. Process run ID: `200c9daf29ee7555a8f3005f3d0a0b1fdc7bfc17`. Observed: 2026-10-11T20:05:52.58579+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `dc941b40a52d0be8c9609bf352f5b84ba54f2288`. Restart policy: `no`. `/data` usage: 20 KiB.

Observed persistence configuration:

```text
appendfsync
always
repl-diskless-sync
yes
no-appendfsync-on-rewrite
no
save

auto-aof-rewrite-percentage
0
rdb-del-sync-files
yes
appendonly
yes
repl-diskless-load
swapdb
maxmemory-policy
noeviction
aof-load-truncated
yes
maxmemory
134217728
aof-use-rdb-preamble
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:0
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720338
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:765952
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:108
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof

```

### Restart receipt 1: node-1

Original Redis Cluster ID: `b6f3a1f5ac46872d158717c86ea72f3dff60d90b`. Observed after restart: 2026-10-11T20:06:01.656566+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `b6f3a1f5ac46872d158717c86ea72f3dff60d90b`. Restart policy: `no`. `/data` usage: 56 KiB.

Observed persistence configuration:

```text
aof-load-truncated
yes
appendfsync
always
repl-diskless-sync
yes
repl-diskless-load
swapdb
rdb-del-sync-files
yes
auto-aof-rewrite-percentage
0
appendonly
yes
save

maxmemory
134217728
maxmemory-policy
noeviction
aof-use-rdb-preamble
yes
no-appendfsync-on-rewrite
no
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720360
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31733
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Restart receipt 2: node-2

Original Redis Cluster ID: `65bc92f93ea1ddfba0d19488791099f44898be55`. Observed after restart: 2026-10-11T20:06:03.340388+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `65bc92f93ea1ddfba0d19488791099f44898be55`. Restart policy: `no`. `/data` usage: 56 KiB.

Observed persistence configuration:

```text
repl-diskless-load
swapdb
rdb-del-sync-files
yes
repl-diskless-sync
yes
aof-load-truncated
yes
appendfsync
always
appendonly
yes
maxmemory-policy
noeviction
save

maxmemory
134217728
no-appendfsync-on-rewrite
no
auto-aof-rewrite-percentage
0
aof-use-rdb-preamble
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720362
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31735
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Restart receipt 3: node-3

Original Redis Cluster ID: `b90d4b8da3ff155e601e06d78cf30e4f0dbf3a7b`. Observed after restart: 2026-10-11T20:06:05.030859+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `b90d4b8da3ff155e601e06d78cf30e4f0dbf3a7b`. Restart policy: `no`. `/data` usage: 56 KiB.

Observed persistence configuration:

```text
no-appendfsync-on-rewrite
no
aof-use-rdb-preamble
yes
maxmemory
134217728
aof-load-truncated
yes
repl-diskless-load
swapdb
rdb-del-sync-files
yes
maxmemory-policy
noeviction
auto-aof-rewrite-percentage
0
appendfsync
always
appendonly
yes
repl-diskless-sync
yes
save

```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720363
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31735
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

### Restart receipt 4: node-4

Original Redis Cluster ID: `250fcb00f3f0bb5e8118a94d52d58dccc95c8199`. Observed after restart: 2026-10-11T20:06:06.707507+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `250fcb00f3f0bb5e8118a94d52d58dccc95c8199`. Restart policy: `no`. `/data` usage: 56 KiB.

Observed persistence configuration:

```text
aof-load-truncated
yes
maxmemory
134217728
maxmemory-policy
noeviction
no-appendfsync-on-rewrite
no
appendonly
yes
auto-aof-rewrite-percentage
0
appendfsync
always
repl-diskless-sync
yes
save

aof-use-rdb-preamble
yes
repl-diskless-load
swapdb
rdb-del-sync-files
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720365
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31735
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof
/data/temp-1791720365.1.rdb

```

### Restart receipt 5: node-5

Original Redis Cluster ID: `a55997ddbd75bd8507dbcb6fd8beef52b065ed34`. Observed after restart: 2026-10-11T20:06:08.406498+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `a55997ddbd75bd8507dbcb6fd8beef52b065ed34`. Restart policy: `no`. `/data` usage: 56 KiB.

Observed persistence configuration:

```text
maxmemory-policy
noeviction
appendfsync
always
appendonly
yes
rdb-del-sync-files
yes
save

auto-aof-rewrite-percentage
0
repl-diskless-load
swapdb
aof-load-truncated
yes
no-appendfsync-on-rewrite
no
repl-diskless-sync
yes
maxmemory
134217728
aof-use-rdb-preamble
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720367
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31733
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/temp-1791720367.1.rdb
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof

```

### Restart receipt 6: node-6

Original Redis Cluster ID: `dc941b40a52d0be8c9609bf352f5b84ba54f2288`. Observed after restart: 2026-10-11T20:06:10.087022+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `dc941b40a52d0be8c9609bf352f5b84ba54f2288`. Restart policy: `no`. `/data` usage: 52 KiB.

Observed persistence configuration:

```text
aof-load-truncated
yes
repl-diskless-sync
yes
maxmemory
134217728
no-appendfsync-on-rewrite
no
repl-diskless-load
swapdb
aof-use-rdb-preamble
yes
appendfsync
always
rdb-del-sync-files
yes
appendonly
yes
maxmemory-policy
noeviction
save

auto-aof-rewrite-percentage
0
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720368
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31735
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/temp-1791720368.1.rdb
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.2.base.rdb
/data/appendonlydir/appendonly.aof.2.incr.aof

```

### Post-synchronization runtime evidence

These fresh read-only administrative observations follow topology stability and precede frozen-ledger validation. They establish the sampled persistence configuration, loading status and data files; the earlier physical restart receipts remain unchanged.

#### Restored node-1

Original Redis Cluster ID: `b6f3a1f5ac46872d158717c86ea72f3dff60d90b`. Process run ID: `2315b3c2d66df6ec4a8abe8ac0830d5bde7e1d99`. Observed: 2026-10-11T20:06:16.041274+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `b6f3a1f5ac46872d158717c86ea72f3dff60d90b`. Restart policy: `no`. `/data` usage: 56 KiB.

Observed persistence configuration:

```text
aof-load-truncated
yes
appendfsync
always
repl-diskless-sync
yes
repl-diskless-load
swapdb
rdb-del-sync-files
yes
auto-aof-rewrite-percentage
0
appendonly
yes
save

maxmemory
134217728
maxmemory-policy
noeviction
aof-use-rdb-preamble
yes
no-appendfsync-on-rewrite
no
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720360
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:905216
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31733
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

#### Restored node-2

Original Redis Cluster ID: `65bc92f93ea1ddfba0d19488791099f44898be55`. Process run ID: `2ab1ab8221f59c25c8216b526eb417ddb05eefc7`. Observed: 2026-10-11T20:06:17.067853+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `65bc92f93ea1ddfba0d19488791099f44898be55`. Restart policy: `no`. `/data` usage: 56 KiB.

Observed persistence configuration:

```text
repl-diskless-load
swapdb
rdb-del-sync-files
yes
repl-diskless-sync
yes
aof-load-truncated
yes
appendfsync
always
appendonly
yes
maxmemory-policy
noeviction
save

maxmemory
134217728
no-appendfsync-on-rewrite
no
auto-aof-rewrite-percentage
0
aof-use-rdb-preamble
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720362
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:950272
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31735
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

#### Restored node-3

Original Redis Cluster ID: `b90d4b8da3ff155e601e06d78cf30e4f0dbf3a7b`. Process run ID: `cfc415fd0b9d4ec80e8225098316a23b3f429542`. Observed: 2026-10-11T20:06:18.125249+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `b90d4b8da3ff155e601e06d78cf30e4f0dbf3a7b`. Restart policy: `no`. `/data` usage: 56 KiB.

Observed persistence configuration:

```text
no-appendfsync-on-rewrite
no
aof-use-rdb-preamble
yes
maxmemory
134217728
aof-load-truncated
yes
repl-diskless-load
swapdb
rdb-del-sync-files
yes
maxmemory-policy
noeviction
auto-aof-rewrite-percentage
0
appendfsync
always
appendonly
yes
repl-diskless-sync
yes
save

```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720363
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:0
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:917504
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:0
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:-1
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:0
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:0
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:31735
aof_base_size:108
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.1.incr.aof
/data/appendonlydir/appendonly.aof.1.base.rdb

```

#### Restored node-4

Original Redis Cluster ID: `250fcb00f3f0bb5e8118a94d52d58dccc95c8199`. Process run ID: `627861210205b2351108e011b36cc299f5b208ad`. Observed: 2026-10-11T20:06:19.178452+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `250fcb00f3f0bb5e8118a94d52d58dccc95c8199`. Restart policy: `no`. `/data` usage: 40 KiB.

Observed persistence configuration:

```text
aof-load-truncated
yes
maxmemory
134217728
maxmemory-policy
noeviction
no-appendfsync-on-rewrite
no
appendonly
yes
auto-aof-rewrite-percentage
0
appendfsync
always
repl-diskless-sync
yes
save

aof-use-rdb-preamble
yes
repl-diskless-load
swapdb
rdb-del-sync-files
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720365
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:145
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:716800
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:20852
aof_base_size:20852
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.3.incr.aof
/data/appendonlydir/appendonly.aof.3.base.rdb

```

#### Restored node-5

Original Redis Cluster ID: `a55997ddbd75bd8507dbcb6fd8beef52b065ed34`. Process run ID: `de89d007dcf86c01ce715c884423cb49cc3d1e21`. Observed: 2026-10-11T20:06:20.281016+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `a55997ddbd75bd8507dbcb6fd8beef52b065ed34`. Restart policy: `no`. `/data` usage: 40 KiB.

Observed persistence configuration:

```text
maxmemory-policy
noeviction
appendfsync
always
appendonly
yes
rdb-del-sync-files
yes
save

auto-aof-rewrite-percentage
0
repl-diskless-load
swapdb
aof-load-truncated
yes
no-appendfsync-on-rewrite
no
repl-diskless-sync
yes
maxmemory
134217728
aof-use-rdb-preamble
yes
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720367
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:145
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:700416
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:20843
aof_base_size:20843
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.3.incr.aof
/data/appendonlydir/appendonly.aof.3.base.rdb

```

#### Restored node-6

Original Redis Cluster ID: `dc941b40a52d0be8c9609bf352f5b84ba54f2288`. Process run ID: `a03667aa8dfec522c931be71a168867d8dadc5a7`. Observed: 2026-10-11T20:06:21.338963+08:00.

Container running: true. Redis PONG: true. Redis Cluster ID: `dc941b40a52d0be8c9609bf352f5b84ba54f2288`. Restart policy: `no`. `/data` usage: 40 KiB.

Observed persistence configuration:

```text
aof-load-truncated
yes
repl-diskless-sync
yes
maxmemory
134217728
no-appendfsync-on-rewrite
no
repl-diskless-load
swapdb
aof-use-rdb-preamble
yes
appendfsync
always
rdb-del-sync-files
yes
appendonly
yes
maxmemory-policy
noeviction
save

auto-aof-rewrite-percentage
0
```

Observed INFO persistence:

```text
# Persistence
loading:0
async_loading:0
current_cow_peak:0
current_cow_size:0
current_cow_size_age:0
current_fork_perc:0.00
current_save_keys_processed:0
current_save_keys_total:0
rdb_changes_since_last_save:145
rdb_bgsave_in_progress:0
rdb_last_save_time:1791720368
rdb_last_bgsave_status:ok
rdb_last_bgsave_time_sec:-1
rdb_current_bgsave_time_sec:-1
rdb_saves:0
rdb_saves_consecutive_failures:0
rdb_last_cow_size:0
rdb_last_load_keys_expired:0
rdb_last_load_keys_loaded:145
aof_enabled:1
aof_rewrite_in_progress:0
aof_rewrite_scheduled:0
aof_last_rewrite_time_sec:0
aof_current_rewrite_time_sec:-1
aof_last_bgrewrite_status:ok
aof_rewrites:1
aof_rewrites_consecutive_failures:0
aof_last_write_status:ok
aof_last_cow_size:724992
backup_in_progress:0
module_fork_in_progress:0
module_fork_last_cow_size:0
aof_current_size:20835
aof_base_size:20835
aof_pending_rewrite:0
aof_buffer_length:0
aof_pending_bio_fsync:0
aof_delayed_fsync:0
```

Observed INFO keyspace:

```text
# Keyspace
db0:keys=145,expires=0,avg_ttl=0,subexpiry=0
```

Observed managed data files:

```text
/data/nodes.conf
/data/appendonlydir/appendonly.aof.manifest
/data/appendonlydir/appendonly.aof.3.incr.aof
/data/appendonlydir/appendonly.aof.3.base.rdb

```

This is a sequential process crash and same-container restart with retained managed volumes. It does not remove Docker VM/host page cache or simulate power loss, storage loss, or a graceful shutdown. Draining and sequential kill/inspection time allow background fsync to progress, so everysec preservation does not establish a one-second-loss guarantee or equivalence to always.

## Independent recovery dimensions

Target observed role: `unobserved`.

| Independent condition | Observed |
|---|---|
| Target process live | true |
| Cluster membership healthy | true |
| Full usable slot coverage | true |
| All shard leaders available | true |
| Client reads available | true |
| Client writes available | true |
| Acknowledged data verified | true |
| Configured write policy available | true |
| Replication redundancy restored | true |
| Persistence recovery verified | true |

## Timing

Milestones are first sampled observations, not Redis event timestamps. Orchestration includes ownership checks and fault execution. The action-completion column separates that overhead; neither anchor identifies the exact Redis event time. Unobserved milestones remain absent.

Fault action completed 2353.725 ms after orchestration began (measured with the monotonic runtime clock).

No primary promotion is required. Original owners and replica assignments must remain unchanged across the all-stopped barrier; frozen data and post-validation diagnostics are evaluated separately.

## Workload

| Phase | Attempts | Success rate | Errors | Throughput (ops/s) | Successful p50/p95/p99 (ms) |
|---|---:|---:|---:|---:|---|
| baseline | 828 | 100.00% | 0 | 199.76 | 1.192 / 2.602 / 3.012 |

Acknowledged writes: 432. Ambiguous SET outcomes: 0.

### Before-baseline persistence and command evidence

Persistence preparation contains 6 node observations. Raw CONFIG, INFO and data-file replies are retained in JSON; these observations are separate from frozen-ledger verification.

| Node | Original Redis Cluster ID | Observed at | Observed Redis Cluster ID | Redis PONG | Error |
|---|---|---|---|---|---|
| node-1 | b6f3a1f5ac46872d158717c86ea72f3dff60d90b | 2026-10-11T20:05:47.187824+08:00 | b6f3a1f5ac46872d158717c86ea72f3dff60d90b | true |  |
| node-2 | 65bc92f93ea1ddfba0d19488791099f44898be55 | 2026-10-11T20:05:48.237349+08:00 | 65bc92f93ea1ddfba0d19488791099f44898be55 | true |  |
| node-3 | b90d4b8da3ff155e601e06d78cf30e4f0dbf3a7b | 2026-10-11T20:05:49.296103+08:00 | b90d4b8da3ff155e601e06d78cf30e4f0dbf3a7b | true |  |
| node-4 | 250fcb00f3f0bb5e8118a94d52d58dccc95c8199 | 2026-10-11T20:05:50.38134+08:00 | 250fcb00f3f0bb5e8118a94d52d58dccc95c8199 | true |  |
| node-5 | a55997ddbd75bd8507dbcb6fd8beef52b065ed34 | 2026-10-11T20:05:51.502717+08:00 | a55997ddbd75bd8507dbcb6fd8beef52b065ed34 | true |  |
| node-6 | dc941b40a52d0be8c9609bf352f5b84ba54f2288 | 2026-10-11T20:05:52.58579+08:00 | dc941b40a52d0be8c9609bf352f5b84ba54f2288 | true |  |

Before-baseline `waitaof` policy probe at 2026-10-11T20:05:52.60666+08:00; all shards successful: true.
requested local/replica AOF counts: 1/1.

| Original shard index | SET acknowledged | WAITAOF attempted | Local / replica AOF reply |
|---|---|---|---|
| 0 | true | true | 1/1 |
| 1 | true | true | 1/1 |
| 2 | true | true | 1/1 |

Write policy: `waitaof`. Diagnostic stage requests are excluded from logical workload counts.
Logical write latency includes SET and WAITAOF on the same physical connection. WAITAOF policy success requires both requested local and replica AOF acknowledgement counts. These disk acknowledgements are separate from WAIT replica-memory acknowledgements; they do not establish strong consistency or a power-loss guarantee from this process-crash experiment.

| Phase | SET acknowledged | SET errors | WAITAOF attempted | Both satisfied | Short pair | Command errors | Client timeouts | Local satisfied | Replica satisfied |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| baseline | 432 | 0 | 432 | 432 | 0 | 0 | 0 | 432 | 432 |

WAITAOF reply distribution preserves the local/replica pair. Only valid two-integer replies are counted; command errors and unattempted calls have no observed pair. `0/0` is an observed short reply. Local/replica satisfied counts can overlap and must not be added.

| Phase | Local / replica AOF acknowledgements | Replies |
|---|---|---:|
| baseline | 1/1 | 432 |

| Phase | Measured path | Count | p50 / p95 / p99, ms |
|---|---|---:|---|
| baseline | Logical write completion | 432 | 1.521 / 2.869 / 3.012 |
| baseline | set | 432 | 0.890 / 1.314 / 2.360 |
| baseline | waitaof | 432 | 0.573 / 1.761 / 2.039 |

| Phase | Successful logical writes | Successful writes/s over phase wall time |
|---|---:|---:|
| baseline | 432 | 104.222 |

SET acknowledgements without a subsequent WAITAOF attempt: 0; client timeouts among those: 0. WAITAOF command errors and WAITAOF client timeouts above count attempted WAITAOF client calls only. A short integer pair is separate from a client timeout.

Configured write policy recovered for the stable interval: true. This criterion is independent of ordinary SET/GET service recovery.

Global pacing: offered 828; started 828; completed 828; dropped 0. These counts include all workload phases and exclude validation and probes.

Offered requests are ideal period slots from workload Start until the dispatcher observes Stop or parent cancellation; the first slot occurs after one period. The period is one second divided by the configured aggregate rate, truncated to whole nanoseconds. A central dispatcher offers only the latest due slot over an unbuffered channel; missed slots, busy workers, stopped tokens, and tokens with no eligible operation are dropped, without catch-up requests. Started requests count actual logical workload GET or write executions; a SET+WAIT/WAITAOF write counts once. Completed requests count their terminal logical metrics attempts. After Stop, offered = started + dropped and started = completed. Validation and ordinary/acknowledgement-policy probes are excluded. These global counters are not attributed to phases.

Validation attempted: true; expected: 432; checked: 432; missing: 0; corrupt: 0; unreadable: 0; unverified: 0. Validation complete: true.

WAITAOF-satisfied subset: expected 432; checked 432; missing 0; corrupt 0; unreadable 0; unverified 0; complete true. The main ledger also includes every successful SET followed by incomplete WAITAOF.

### Terminal workload errors

| Phase | Error class | Count |
|---|---|---:|

Latencies use 512 bounded geometric histogram buckets, starting at 1 microsecond and increasing by 5%; quantiles are nearest-rank bucket upper bounds. The last bucket covers the remaining duration range. All terminal client attempts, successful attempts, and failed attempts have separate histograms. Throughput is completed attempts divided by phase wall-clock seconds. Operations are attributed to the phase in which they start. Redirect counts include only terminal MOVED/ASK errors; redirects handled by the client are not observable here.

## Measurement methodology

- Quiet administrative process, CONFIG, persistence INFO, keyspace and bounded data-file preparation occurs before baseline traffic; it issues no SAVE, BGSAVE, BGREWRITEAOF or explicit durability barrier.
- The workload fully stops and joins in-flight acknowledgements before freezing its immutable ledger and counters. All later topology observations are read-only until every frozen acknowledged value has been checked. SET-error outcomes remain ambiguous, excluded from acknowledgement guarantees.
- Original replicas are SIGKILLed before original primaries. Every fixed owned container must produce ErrProcessStopped administrative evidence with restart policy no before any restart. Original primaries restart before replicas in the same containers and retained volumes; original Redis Cluster identities and slot ownership must survive.
- The model is sequential process SIGKILL while Docker VM, host and storage remain running, followed by same-container starts. It does not simulate power loss, host/page-cache loss or disk loss. Drain, kill and inspection intervals are reported because they permit background fsync progress.
- Topology restoration requires all six original identities, endpoints, primary slot owners and replica assignments synchronized for stable_for, without forced Redis topology commands. Physical receipts retain early raw evidence, which can be transient during full sync. Six fresh quiet administrative runtime/configuration/file observations after topology stability prove the final persistence mode on those same restarted processes, within the shared repair budget and before frozen-value validation. Samples crossing restoration or diagnostic deadlines are retained but excluded from successful milestones.
- Frozen-ledger GET validation happens exactly once before diagnostic SET/GET or configured replica-acknowledgement probes. Process/slot readiness and later diagnostic service are independent from frozen-value preservation; missing or corrupt values retain a partial data verdict even after service recovers.
- Memory mode has RDB/AOF disabled, rdb-del-sync-files=yes to remove replication-created RDB files, and observed absence of value persistence files. Its persistence-recovery event is not applicable and remains absent; its independent persistence dimension is false. AOF modes use the RDB base preamble required by the pinned image's bundled modules plus incremental AOF records. AOF recovery requires actual matching healthy runtime configuration, loading=0 and complete frozen acknowledged-value preservation; this observation establishes no loss-free or power-loss guarantee.
- No workload demand is offered after draining, so absent fault/recovery traffic does not measure zero availability or throughput. Post-validation probes are separate diagnostics and never enter workload metrics or the frozen ledger. Poll intervals follow sample completion; observations are sampled and non-atomic.
- All AOF modes and write policies use six-node quiet runtime preparation followed by exactly three all-shard policy SET/GET warmup writes before baseline starts. Warmup writes are excluded from the workload ledger and metrics; no WAITAOF compatibility command is issued after baseline to alter crash-trial durability.
- Configured acknowledgement policy is a separate current condition, measured through all-three-shard SET plus WAIT/WAITAOF on one physical connection. A stable policy milestone is historical; a later unsuccessful probe resets the current condition.

The JSON report contains effective configuration, environment metadata, raw topology replies, per-operation metrics, validation samples, and lifecycle timestamps. Effective configuration SHA-256: `88ab3f40ee8f36409a06c243810114981f4c932dee7444c9720c4846e2de28bc`.
