# Redis Reliability Lab — primary-failure

Run: `1e6f3072ca6edd99be6febc3`  
Outcome: **recovered**  
Started: 2026-10-11T19:55:43.113326+08:00  
Finished: 2026-10-11T19:56:09.233686+08:00

## Recovery

| Condition | Observed |
|---|---|
| Surviving topology converged | true |
| All-shard client recovery sustained | true |
| Topology and client recovery jointly sustained | true |
| All acknowledged writes verified | true |
| Target process restarted | false |
| Original replication redundancy restored | true |
| Recovery deadline expired | false |
| Cleanup verified | true |

The replica remains running during whole-node bidirectional network isolation. Connectivity restoration, topology reconciliation and replication redundancy are evaluated separately. Redis replication is asynchronous; acknowledged SETs are not durability guarantees.

## Network restoration

| Condition | Observed |
|---|---|
| Original endpoints and process restored | true |
| Topology and clients jointly reconciled | true |
| Reconciliation deadline expired | false |

Restoration action duration: 1409.183 ms.
Stable reconciliation first observed 1806.592 ms after restoration completed.

| Process probe time | Redis PONG | Container running | Network attached | Container PID | Redis run ID | Error |
|---|---|---|---|---:|---|---|
| 2026-10-11T19:55:59.307071+08:00 | true | true | false | 68702 | 0eaf63d17b864db6a20843d1948d15ddc6bf093b |  |
| 2026-10-11T19:56:02.305141+08:00 | true | true | false | 68702 | 0eaf63d17b864db6a20843d1948d15ddc6bf093b |  |

## Managed node lifecycle

Target: replica `node-5` (Redis ID `4692e3373b6221aa62f9cbe8abf777de27631ac9`). Repair: `reconnect`.

Repair action completed: true. Repair or synchronization deadline expired: false.
Repair action duration: 1409.187 ms.
Stable redundancy first observed 1806.589 ms after repair action completed.

A completed restart or reconnect does not establish topology or replication recovery. Link-up and completed initial synchronization are sampled readiness conditions, not zero lag or durability guarantees.

| Lifecycle observation | Since fault orchestration began, ms |
|---|---:|
| Target failure detected | 2018.495 |
| Replication interruption observed | unobserved |
| Target reachable after repair | 6894.724 |
| Membership rejoined | 7443.797 |
| Replica link up | 6894.724 |
| Synchronization in progress | unobserved |
| Synchronization complete | 6894.724 |
| Primary full-sync counter increased | unobserved |
| Primary partial-sync counter increased | unobserved |
| Replication redundancy sustained | 8691.077 |

Resynchronization evidence: `no_counter_increase_observed`; primary Redis ID `ad684da96bd11decf864638a54bc3f744e526ee1`. Counters are server-wide primary deltas, not an exact target transfer or byte-loss measurement.

## Independent recovery dimensions

Target observed role: `slave`.

| Independent condition | Observed |
|---|---|
| Target process live | true |
| Cluster membership healthy | true |
| Full usable slot coverage | true |
| All shard leaders available | true |
| Client reads available | true |
| Client writes available | true |
| Acknowledged data verified | true |
| Configured write policy available | true |
| Replication redundancy restored | true |
| Persistence recovery verified | unobserved |

## Timing

Milestones are first sampled observations, not Redis event timestamps. Orchestration includes ownership checks and fault execution. The action-completion column separates that overhead; neither anchor identifies the exact Redis event time. Unobserved milestones remain absent.

Fault action completed 1469.471 ms after orchestration began (measured with the monotonic runtime clock).

| Observation | Since orchestration began, ms | Since action completed, ms |
|---|---:|---:|
| Failure flagged in gossip | 2018.49 | 549.02 |
| Original replica owns failed primary slots | unobserved | unobserved |
| Full usable slot coverage | 2018.49 | 549.02 |
| Surviving views converge | 2018.49 | 549.02 |
| First all-shard SET/GET probe succeeds | 2140.80 | 671.33 |
| Client probes sustain recovery | 3488.29 | 2018.82 |
| Topology and clients sustain recovery | 3488.29 | 2018.82 |

## Workload

| Phase | Attempts | Success rate | Errors | Throughput (ops/s) | Successful p50/p95/p99 (ms) |
|---|---:|---:|---:|---:|---|
| baseline | 419 | 100.00% | 0 | 199.59 | 0.546 / 1.849 / 4.907 |
| fault | 1092 | 100.00% | 0 | 199.44 | 0.664 / 1.761 / 5.964 |
| repair | 282 | 100.00% | 0 | 200.10 | 0.732 / 1.521 / 3.012 |
| reconciliation | 402 | 100.00% | 0 | 200.24 | 0.573 / 0.890 / 2.478 |
| post_recovery | 200 | 100.00% | 0 | 199.96 | 0.520 / 0.732 / 1.030 |

Acknowledged writes: 1210. Ambiguous SET outcomes: 0.

Write policy: `set`. Diagnostic stage requests are excluded from logical workload counts.

| Phase | SET acknowledged | SET errors |
|---|---:|---:|
| baseline | 221 | 0 |
| fault | 532 | 0 |
| repair | 149 | 0 |
| reconciliation | 207 | 0 |
| post_recovery | 101 | 0 |

| Phase | Measured path | Count | p50 / p95 / p99, ms |
|---|---|---:|---|
| baseline | Logical write completion | 221 | 0.573 / 1.252 / 4.037 |
| baseline | set | 221 | 0.546 / 1.192 / 3.845 |
| fault | Logical write completion | 532 | 0.664 / 1.761 / 5.410 |
| fault | set | 532 | 0.632 / 1.677 / 5.410 |
| repair | Logical write completion | 149 | 0.768 / 1.521 / 3.012 |
| repair | set | 149 | 0.732 / 1.449 / 3.012 |
| reconciliation | Logical write completion | 207 | 0.573 / 0.890 / 2.248 |
| reconciliation | set | 207 | 0.573 / 0.890 / 2.141 |
| post_recovery | Logical write completion | 101 | 0.546 / 0.732 / 1.081 |
| post_recovery | set | 101 | 0.520 / 0.732 / 1.030 |

| Phase | Successful logical writes | Successful writes/s over phase wall time |
|---|---:|---:|
| baseline | 221 | 105.273 |
| fault | 532 | 97.164 |
| repair | 149 | 105.726 |
| reconciliation | 207 | 103.111 |
| post_recovery | 101 | 100.980 |

Global pacing: offered 2398; started 2395; completed 2395; dropped 3. These counts include all workload phases and exclude validation and probes.

Offered requests are ideal period slots from workload Start until the dispatcher observes Stop or parent cancellation; the first slot occurs after one period. The period is one second divided by the configured aggregate rate, truncated to whole nanoseconds. A central dispatcher offers only the latest due slot over an unbuffered channel; missed slots, busy workers, stopped tokens, and tokens with no eligible operation are dropped, without catch-up requests. Started requests count actual logical workload GET or write executions; a SET+WAIT/WAITAOF write counts once. Completed requests count their terminal logical metrics attempts. After Stop, offered = started + dropped and started = completed. Validation and ordinary/acknowledgement-policy probes are excluded. These global counters are not attributed to phases.

Validation attempted: true; expected: 1210; checked: 1210; missing: 0; corrupt: 0; unreadable: 0; unverified: 0. Validation complete: true.

### Terminal workload errors

| Phase | Error class | Count |
|---|---|---:|

Latencies use 512 bounded geometric histogram buckets, starting at 1 microsecond and increasing by 5%; quantiles are nearest-rank bucket upper bounds. The last bucket covers the remaining duration range. All terminal client attempts, successful attempts, and failed attempts have separate histograms. Throughput is completed attempts divided by phase wall-clock seconds. Operations are attributed to the phase in which they start. Redirect counts include only terminal MOVED/ASK errors; redirects handled by the client are not observable here.

## Measurement methodology

- Fault selection preserves the initial primary and its replica. The destructive target is the selected replica; only strictly owned local Docker resources are affected.
- Replica faults preserve all original slot owners and do not require promotion. down_duration is a minimum hold from successful fault action completion, bounded by the recovery observation budget. Client service, failure gossip and replication interruption are separately sampled.
- Replica network isolation removes its complete bidirectional Docker bridge connectivity while Redis remains running. It is not a selective replication-only partition. Restoration uses the same owned endpoint and unchanged live process identity.
- Administrative endpoint-disconnection evidence is separate from Redis INFO link or connected-replica indicators. A short disconnection can finish before TCP/link failure detection; absent interruption or synchronization-counter milestones remain unobserved and are not invented from the Docker interface state.
- Crash repair starts the same stopped owned container with its bounded disposable data volume. Redis Cluster identity must match the pre-fault identity. Restart changes the process; it does not simulate power loss, host/storage failure or persistence durability.
- The repair deadline covers the restart/reconnect action and subsequent synchronization. Redis's current membership is inspected without issuing CLUSTER REPLICATE or forcing slot ownership. Replica repair preserves original assignments; former-primary repair requires the original replica to retain promoted ownership and the old primary to rejoin as its replica.
- Fresh stability after repair requires all six original identities and endpoints, healthy equal slot maps, exactly one synchronized replica per primary, and all-shard client probes. Historical service recovery remains separate from final redundancy and configured acknowledgement-policy availability.
- Replication link-up and master_sync_in_progress=0 are sampled indicators, not exact zero lag, bytes preserved, or identification of partial versus full resynchronization. Raw replication INFO is retained for inspection; unobserved milestones remain absent.
- Traffic drains before validating every acknowledged immutable SET, including short/error WAIT/WAITAOF outcomes. Ambiguous SET errors remain separate. Cancellation skips unsupported recovery/data claims and still uses fresh bounded restoration and cleanup contexts, including managed volumes.

The JSON report contains effective configuration, environment metadata, raw topology replies, per-operation metrics, validation samples, and lifecycle timestamps. Effective configuration SHA-256: `d65a48ea2bbb0df5827bb0ab7c7e7aadb132e643b1f0438979f3bf8f99da1f59`.
